export const TEMPLATE_ORDER_CONFIRMATION_PATH = "./src/content/report-templates/order-confirmation.html";
export const OUTPUT_ORDER_CONFIRMATION_HTML_PATH = "./src/content/reports/OrderConfirmation.html";
export const OUTPUT_ORDER_CONFIRMATION_PDF_PATH = "./src/content/reports/OrderConfirmation.pdf";

export const getMergeFieldMappingOrderConfirmation = (data) => {
    return [
        { key: "orderId", type: "number", value: data.orderId },
        { key: "clientName", type: "string", value: data.clientName },
        { key: "referenceId", type: "number", value: data.referenceId },
        { key: "requestApptDate", type: "date", value: data.requestApptDate },
        { key: "packageTo", type: "string", value: data.packageTo },
        { key: "fullName", type: "string", value: data.fullName },
        { key: "branchName", type: "string", value: data.branchName },
        { key: "branchAddr", type: "string", value: data.branchAddr },
        { key: "branchCity", type: "string", value: data.branchCity },
        { key: "branchState", type: "string", value: data.branchState },
        { key: "branchZip", type: "string", value: data.branchZip },
        { key: "fax", type: "string", value: data.fax },
        { key: "phone", type: "string", value: data.phone },
        { key: "brokerId", type: "number", value: data.brokerId },
        { key: "username", type: "string", value: data.username },
        { key: "vendorName", type: "string", value: data.vendorName },
        { key: "vendorCell", type: "string", value: data.vendorCell },
        { key: "vendorWork", type: "string", value: data.vendorWork },
        { key: "vendorHome", type: "string", value: data.vendorHome },
        { key: "vendorAddr", type: "string", value: data.vendorAddr },
        { key: "vendorCity", type: "string", value: data.vendorCity },
        { key: "vendorState", type: "string", value: data.vendorState },
        { key: "vendorZip", type: "string", value: data.vendorZip },
        { key: "vendorEmail", type: "string", value: data.vendorEmail }
        // missing fees
    ];
};
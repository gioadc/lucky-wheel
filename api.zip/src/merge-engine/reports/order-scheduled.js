export const TEMPLATE_ORDER_SCHEDULED_PATH = "./src/content/report-templates/order-scheduled.html";
export const OUTPUT_ORDER_SCHEDULED_HTML_PATH = "./src/content/reports/OrderScheduled.html";
export const OUTPUT_ORDER_SCHEDULED_PDF_PATH = "./src/content/reports/OrderScheduled.pdf";

export const getMergeFieldMappingOrderScheduled = (data) => {
    return [
        { key: "fullName", type: "string", value: data.fullName },
        { key: "fax", type: "string", value: data.fax },
        { key: "company", type: "string", value: data.company },
        { key: "orderId", type: "string", value: data.orderId },
        { key: "brokerIdNum", type: "string", value: data.brokerIdNum },
        { key: "signerId", type: "string", value: data.signerId },
        { key: "brokerFees", type: "string", value: data.brokerFees },
        { key: "aptDateTime", type: "date", value: data.aptDateTime }
    ];
};
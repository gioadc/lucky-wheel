export const TEMPLATE_ORDER_CLOSED_PATH = "./src/content/report-templates/order-closed.html";
export const OUTPUT_ORDER_CLOSED_HTML_PATH = "./src/content/reports/OrderClosed.html";
export const OUTPUT_ORDER_CLOSED_PDF_PATH = "./src/content/reports/OrderClosed.pdf";

export const getMergeFieldMappingOrderClosed = (data) => {
    return [
        { key: "fullName", type: "string", value: data.fullName },
        { key: "fax", type: "string", value: data.fax },
        { key: "company", type: "string", value: data.company },
        { key: "orderId", type: "string", value: data.orderId },
        { key: "brokerIdNum", type: "string", value: data.brokerIdNum },
        { key: "signerId", type: "string", value: data.signerId },
        { key: "brokerFees", type: "string", value: data.brokerFees },
        { key: "courier", type: "string", value: data.courier },
        { key: "trackingNumber", type: "string", value: data.trackingNumber }
    ];
};
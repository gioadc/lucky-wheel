export default {
	production: {
		port: process.env.PORT,
		secretKey: "AT595r768gqHdSLqzew746hNp5VrpN7a"
	},
	development: {
		host: "localhost",
		port: 3001,
		secretKey: "lF7ioZHOa4iafmUfhcWwkUFRb7P7F09K"
	},
	test: {
		port: process.env.PORT,
		secretKey: "UdeyPg9xXlXVFZc6HZ4yLZcnuNlAV8Ag"
	}
};

import dbConfig from "./db.config";
import envConfig from "./env.config";
import mailConfig from "./mail.config";
import braintreeConfig from "./braintree.config";
import fileConfig from "./file.config";
const env = process.env.ENV || "development";

module.exports = {
	application: {
		host: envConfig[env].host,
		port: envConfig[env].port,
		secretKey: envConfig[env].secretKey
	},
	database: {
		host: dbConfig[env].host,
		user: dbConfig[env].user,
		password: dbConfig[env].password,
		database: dbConfig[env].database
	},
	server: {
		defaultHost: "http://localhost:8001"
	},
	mail: {
		host: mailConfig[env].host,
		port: mailConfig[env].port,
		timeout: mailConfig[env].timeout,
		user: mailConfig[env].user,
		pass: mailConfig[env].pass,
		form: mailConfig[env].form
	},
	braintree: braintreeConfig[env],
	file: {
		serverPath: fileConfig[env].serverPath
	}
};

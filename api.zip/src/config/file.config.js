export default {
    production: {
        serverPath: "./src/content"
    },
    development: {
        serverPath: "./src/content"
    },
    test: {
        serverPath: "./src/content"
    }
};
const Braintree = require("braintree");

export default {
    production: {
        environment: Braintree.Environment.Sandbox,
        merchantId: "jx4xv6ybnbwp62cd",
        publicKey: "qgppm2smpn2t452s",
        privateKey: "8c581c0e01f8a14773b156feb888c5d9"
    },
    development: {
        environment: Braintree.Environment.Sandbox,
        merchantId: "jx4xv6ybnbwp62cd",
        publicKey: "qgppm2smpn2t452s",
        privateKey: "8c581c0e01f8a14773b156feb888c5d9"
    },
    test: {
        environment: Braintree.Environment.Sandbox,
        merchantId: "jx4xv6ybnbwp62cd",
        publicKey: "qgppm2smpn2t452s",
        privateKey: "8c581c0e01f8a14773b156feb888c5d9"
    }
};

import fs from "fs";
import fsPath from "path";
import config from "../config/config";

export const UPLOAD_PATH = `${config.file.serverPath}/upload`;
export const SEPARATER = "/";

const fileFilter = function (fileName) {
    if (!fileName.match(/\.(doc|docx|pdf|jpg|jpeg|png|gif|xls|tiff)$/)) {
        return false;
    }

    return true;
};

export const rmkdir = (targetDir) => {
    if (fs.existsSync(targetDir)) {
        return;
    }

    targetDir.split(SEPARATER).reduce((parentDir, childDir) => {
        const curDir = fsPath.resolve(parentDir, childDir);
        if (!fs.existsSync(curDir)) {
            fs.mkdirSync(curDir);
        }

        return curDir;
    });
};

export const _fileHandler = function (file, options) {
    if (!file) throw new Error("No file(s)");

    const filename = file.hapi.filename;
    const path = `${options.dest}${filename}`;
    const fileStream = fs.createWriteStream(path);

    return new Promise((resolve, reject) => {
        file.on("error", (err) => {
            reject(err);
        });

        file.pipe(fileStream);

        file.on("end", () => {
            const fileDetails = {
                filename, // change to filename to use uuid genarate file name
                path,
                originalName: file.hapi.filename,
                mimeType: file.hapi.headers["content-type"],
                destination: `${options.dest}`,
                size: fs.statSync(path).size
            };

            resolve(fileDetails);
        });
    });
};

export const uploader = function (file, options) {
    if (!file) throw new Error("No file(s)");

    // apply filter if exists
    if (options.fileFilter && !options.fileFilter(file.hapi.filename)) {
        throw new Error("File type is not allowed");
    }

    // check and add custom path
    if (options.path && options.path.length > 0) {
        options.dest += options.path.indexOf("/") === 0 ? options.path.substring(1) : options.path;
        options.dest += options.dest.lastIndexOf("/") === options.dest.length - 1 ? "" : "/";
    }

    // create folder for upload if not exist and check again
    if (!fs.existsSync(options.dest)) rmkdir(options.dest, config.file.serverPath);
    if (!fs.existsSync(options.dest)) {
        throw new Error("Upload path does not exist. Create path denied!");
    }

    return _fileHandler(file, options);
};

export const fileOptions = { dest: `${UPLOAD_PATH}/`, fileFilter };
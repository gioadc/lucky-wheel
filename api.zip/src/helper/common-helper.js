import fs from "fs";
import moment from "moment";

export const bufferToBoolean = (input) => {
    // eslint-disable-next-line
    if (Buffer.isBuffer(input)) {
        const values = input.values();

        for (const value of values) {
            return value === 1;
        }
    }

    return false;
};

export const isBuffer = (input) => {
    // eslint-disable-next-line
    return Buffer.isBuffer(input);
};

export const handleSingleQuote = (input) => {
    return input.replace(/\\/g, "\\\\\\\\\\\\\\\\").replace(/'/g, "\\\'\\\'").replace(/%/g, "\\%").replace(/_/g, "\\_").replace(/\[/g, "\\\[").replace(/\]/g, "\\]");
};

export const hasStringValue = (input) => {
    return input !== null && input !== undefined && input !== "";
};

export const hasValue = (input) => {
    return input !== null && input !== undefined;
};

export const bookshelfError = (err) => {
    return `${err.code}: ${err.sqlMessage}`;
};

export const handleBreakLine = (input) => {
    return input.replace(/\n/g, "<br />").replace("&", "&amp;");
};

export const mergeFieldString = (fieldName, input, value) => {
    if (value) {
        return input.replace(fieldName, value);
    } else return input.replace(fieldName, "&nbsp;");
};

export const mergeFieldNumber = (fieldName, input, value) => {
    if (value) {
        return input.replace(fieldName, value);
    } else return input.replace(fieldName, "&nbsp;");
};

export const mergeFieldBool = (fieldName, input, value) => {
    if (value.data.length > 0) {
        if (value.data[0] === 1) {
            return input.replace(fieldName, "Yes");
        }
        return input.replace(fieldName, "No");
    } else return input.replace(fieldName, "&nbsp;");
};

export const mergeFieldDateTime = (fieldName, input, value) => {
    if (value) {
        return input.replace(fieldName, moment(value).format("MM/DD/YYYY hh:mm:ss A"));
    } else return input.replace(fieldName, "&nbsp;");
};

export const mergeItemsHtmlContent = (content, input) => {
    return input.replace("<!--[itemsGoHere]-->", content);
};

export const mergeInstructionsHtmlContent = (content, input) => {
    return input.replace("<!--[instructionsGoHere]-->", content);
};

// Test Array List Content
export const mergeArrayListContent = (content, input) => {
    return input.replace("<!--orderFeeListGoesHere-->", content);
};

export const readFileToString = (path) => {
    return fs.readFileSync(path, "utf8").toString();
};

export const writeFileToHTML = (path, content) => {
    return fs.writeFileSync(path, content, "utf8");
};

export const mergeDataField = (template, data) => {
    let itemsHtmlContent = "";
    let instructionsHtmlContent = "";
    let orderFeeListHtmlContent = "";

    for (const field in data) {
        switch (data[field].type) {
            case "number":
            template = mergeFieldNumber(`[${data[field].key}]`, template, data[field].value);
                break;
            case "date":
            template = mergeFieldDateTime(`[${data[field].key}]`, template, data[field].value);
                break;
            case "string":
            template = mergeFieldString(`[${data[field].key}]`, template, data[field].value);
                break;
            case "bool":
            template = mergeFieldBool(`[${data[field].key}]`, template, data[field].value);
                break;
            case "items":
                if (data[field].value !== null && data[field].value !== undefined) {
                    const itemContent = `<tr>
                        <td width="20%" style="padding: 0 2px; border-bottom: 1px #000 solid;"><strong>Item #${data[field].index}:</strong></td>
                        <td width="80%" style="padding: 0 2px; border-left: 1px #000 solid; border-bottom: 1px #000 solid;">${data[field].value}</td>
                    </tr>`;

                    itemsHtmlContent = itemsHtmlContent.concat(itemContent);
                }
                break;
            case "instructions":
                if (data[field].value !== null && data[field].value !== undefined) {
                    const instructionContent = `<tr>
                        <td width="30%" style="padding: 0 2px; border-bottom: 1px #000 solid;"><strong>Instruction #${data[field].index}:</strong></td>
						<td width="70%" style="padding: 0 2px; border-left: 1px #000 solid; border-bottom: 1px #000 solid;">${data[field].value}</td>
                    </tr>`;

                    instructionsHtmlContent = instructionsHtmlContent.concat(instructionContent);
                }
                break;
            case "array":
                if (data[field].value.length > 0) {
                    const arrayList = data[field].value;
                    for (const key in arrayList) {
                        //console.log(arrayList[key]);
                        const orderFeeListContent = `<tr>
                            <td>${arrayList[key].Description}</td>
                            <td>${arrayList[key].BrokerFee}</td>
                            <td>${arrayList[key].SignerFee}</td>
                        </tr>`;

                        orderFeeListHtmlContent = orderFeeListHtmlContent.concat(orderFeeListContent);
                    }
                    //console.log(orderFeeListHtmlContent);
                }
                break;
        }
    }

    if (itemsHtmlContent.length > 0) {
        if (instructionsHtmlContent.length > 0) {
            template = mergeItemsHtmlContent(itemsHtmlContent, template);
            template = mergeInstructionsHtmlContent(instructionsHtmlContent, template);

            // Test array List
            template = mergeArrayListContent(orderFeeListHtmlContent, template);
        } else {
            template = mergeItemsHtmlContent(itemsHtmlContent, template);
        }
    }

    return template;
};

export const convertRowDataPackage = (dataInput) => {
    return JSON.parse(JSON.stringify(dataInput));
};
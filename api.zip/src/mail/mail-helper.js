import NodeMailer from "nodemailer";
import config from "../config/config";

const sendMailCore = (mailOptions, callback) => {
    const transporter = NodeMailer.createTransport({
        host: config.mail.host,
        port: config.mail.port,
        secure: false, // true for 465, false for other ports
        auth: {
            user: config.mail.user, // generated ethereal user
            pass: config.mail.pass // generated ethereal password
        }
    });

    // send mail with defined transport object
    transporter.sendMail(mailOptions, (error, info) => {
        // if (error) {
        //     return console.log(error);
        // }
        // console.log(`Message sent: ${info.messageId}`);
        // // Preview only available when sending through an Ethereal account
        //console.log(`Preview URL: ${NodeMailer.getTestMessageUrl(info)}`);
        const result = {
            error,
            message: `Preview URL: ${NodeMailer.getTestMessageUrl(info)}`
        };

        return callback(result);
    });
};

export default sendMailCore;
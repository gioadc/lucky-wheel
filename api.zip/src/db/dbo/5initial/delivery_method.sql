INSERT INTO `delivery_method` (`DelMethodDescription`) VALUES('Client Upload');
INSERT INTO `delivery_method` (`DelMethodDescription`) VALUES('Emailed directly to Vendor - Client');
INSERT INTO `delivery_method` (`DelMethodDescription`) VALUES('Overnight - To Customer');
INSERT INTO `delivery_method` (`DelMethodDescription`) VALUES('Overnight - To Vendor');
INSERT INTO `delivery_method` (`DelMethodDescription`) VALUES('Overnight/Courier to Closing Location');
INSERT INTO `delivery_method` (`DelMethodDescription`) VALUES('Printed at Closing Location');
INSERT INTO `delivery_method` (`DelMethodDescription`) VALUES('Customer has Documents');
INSERT INTO `delivery_method` (`DelMethodDescription`) VALUES('E-sign');
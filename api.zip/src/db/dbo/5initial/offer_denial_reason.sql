INSERT INTO offer_denial_reason(DenialReasonID, DenialReason) VALUES
(1, 'I’m not available at that time'),
(2, 'Location is too far away'),
(3, 'I need more fee'),
(4, 'I no longer do mobile signings'),
(5, 'I am out of town'),
(6, 'I do not do that product type'),
(7, 'Other')
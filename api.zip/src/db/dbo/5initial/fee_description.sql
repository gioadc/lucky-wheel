insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Additional Email', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Additional Sets', 432, 123, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Additional Trip', 444, 333, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Addnl. Sets-Attorney', 111, 222, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Attorney Request', 234, 345, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Automotive Signing', 178, 289, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Bilingual Vendor', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Borrower Interview', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Cancellation Fee', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Cash Purchase', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Commercial', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Copy Package', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Courier Service', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Deed Only', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Disclosure Reverse', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Disclosures', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Drive-By Inspection', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Drop Off/Pick Up', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Email Document Set', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('E-Signing', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Express Signing', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Fax Document Set', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('HELOC', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('HELOC Attorney', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Inspection', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Licensed Title Prod', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Medical', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Misc Fees', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('No Sign', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Nominal Package', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Note Modification', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Other', 444, 555, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Phone Closing', 100, 200, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Re-Sign', 120, 308, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Reverse Mortgage', 170, 407, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Seller package', 255, 321, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Signing', 400, 540, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Single Doc and Travel', 200, 300, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Structured Settlement', 180, 210, 80, 50, 1, NOW());
insert into fee_description(Description, DefaultBrokerFee, DefaultSignerFee, Gold, Platinum, Active, LastUpdate)
values('Timeshare', 150, 180, 80, 50, 1, NOW());

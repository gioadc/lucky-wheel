INSERT INTO `problem_status` (`Description`) VALUES('Open');
INSERT INTO `problem_status` (`Description`) VALUES('Acknowledged');
INSERT INTO `problem_status` (`Description`) VALUES('Resolved');
INSERT INTO `problem_status` (`Description`) VALUES('Approved');
INSERT INTO `problem_status` (`Description`) VALUES('Rejected');
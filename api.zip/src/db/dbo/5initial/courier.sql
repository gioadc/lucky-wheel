INSERT INTO `courier` (`CourierID`, `Courier`, `TenantId`) VALUES ('1', 'FedEx', NULL, '1');
INSERT INTO `courier` (`CourierID`, `Courier`, `TenantId`) VALUES ('2', 'UPS', '1');
INSERT INTO `courier` (`CourierID`, `Courier`, `TenantId`) VALUES ('3', 'US Mail', '1');
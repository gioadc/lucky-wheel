DELETE FROM `order_fee_approve_reason` WHERE `ReasonCode` <> 0;

ALTER TABLE `order_fee_approve_reason` AUTO_INCREMENT = 1;

-- default data
INSERT INTO `order_fee_approve_reason`(`ReasonDescription`, `Type`) VALUES ('Best Option Available', 'S');
INSERT INTO `order_fee_approve_reason`(`ReasonDescription`, `Type`) VALUES ('Location/Distance', 'S');
INSERT INTO `order_fee_approve_reason`(`ReasonDescription`, `Type`) VALUES ('SA Backout', 'S');
INSERT INTO `order_fee_approve_reason`(`ReasonDescription`, `Type`) VALUES ('SLA Deadline', 'S');
INSERT INTO `order_fee_approve_reason`(`ReasonDescription`, `Type`) VALUES ('Holiday', 'S');
INSERT INTO `order_fee_approve_reason`(`ReasonDescription`, `Type`) VALUES ('Same Day Signing', 'S');
INSERT INTO `order_fee_approve_reason`(`ReasonDescription`, `Type`) VALUES ('Other (Must add comments)', 'S');
INSERT INTO `order_fee_approve_reason` (`ReasonDescription`, `Type`) VALUES ('Location is too far away', 'V');
INSERT INTO `order_fee_approve_reason` (`ReasonDescription`, `Type`) VALUES ('I need more fee', 'V');

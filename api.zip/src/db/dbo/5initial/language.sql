insert into `language` (Language) values ('English'),
('French'),
('German'),
('Spanish'),
('Portuguese'),
('Japanese'),
('Chinese'),
('Vietnamese')
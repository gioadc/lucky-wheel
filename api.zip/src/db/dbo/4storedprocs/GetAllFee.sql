DROP PROCEDURE IF EXISTS `GetAllFee`;

DELIMITER $$
CREATE PROCEDURE `GetAllFee` (
)
BEGIN
    SELECT FeeDescriptionId as FeeId, Description, DefaultBrokerFee, DefaultSignerFee
	FROM fee_description
    WHERE Active = 1;
END$$

DELIMITER ;
DROP PROCEDURE IF EXISTS `GetOrderCollectById`;

DELIMITER $$
CREATE PROCEDURE `GetOrderCollectById` (
IN orderId INT(11)
)
BEGIN
	SELECT oc.Item1 as `1`, oc.Item2 as `2`, oc.Item3 as `3`, oc.Item4 as `4`, oc.Item5 as `5`
	FROM `order_collect` AS oc
	LEFT JOIN `order` AS o ON o.CollectID = oc.CollectID AND o.TenantID = oc.TenantID
	WHERE o.OrderID = orderId;
END$$

DELIMITER ;
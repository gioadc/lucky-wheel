DROP PROCEDURE IF EXISTS `ViewOrders`;

DELIMITER $$
CREATE PROCEDURE `ViewOrders`(
	IN orderID int(11), 
	IN vendorLastName varchar(255), 
	IN borrLastName varchar(255),
	IN companyBranch varchar(255),
	IN apptDate datetime,
	IN fromDate datetime,
	IN toDate datetime,
	IN loanAgent varchar(255),
	IN statusOrder varchar(255),
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(5000);  
    
    IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY `Order Date`';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;
    
    SET whereQuery = ' WHERE 1=1 AND IsActive = true ';
    IF (orderID IS NOT NULL AND orderID >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Order ID` = ', orderId);
	END IF;
    IF (vendorLastName IS NOT NULL AND vendorLastName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Vendor Last` LIKE ''%', vendorLastName, '%''');
	END IF;
    IF (borrLastName IS NOT NULL AND borrLastName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Client Last` LIKE ''%', borrLastName, '%''');
	END IF;
    IF (companyBranch IS NOT NULL AND companyBranch <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Company/Branch` like "%', companyBranch ,'%"');
	END IF;
    IF (apptDate IS NOT NULL AND apptDate <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND date(`Appt. Date`) = date("', apptDate,'")');
	END IF;
    IF (fromDate IS NOT NULL AND fromDate <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND date(`Order Date`) >= date("', fromDate,'")');
	END IF;
    IF (toDate IS NOT NULL AND toDate <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND date(`Order Date`) <= date("', toDate,'")');
	END IF;
    IF (loanAgent IS NOT NULL AND loanAgent <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Loan Agent` LIKE ''%', loanAgent, '%''');
	END IF;
    IF (statusOrder IS NOT NULL AND statusOrder <> '')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND `Status` like "%', statusOrder,'%"');
	END IF;
    
    
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
    
    set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS `#`, t1.* from (select `order`.OrderId as `Order ID`,
                                    `borrower`.LastName as `Client Last`,
                                    `signer`.LastName as `Vendor Last`,
                                    if(`branches`.BranchName != null, `branches`.BranchName, `broker`.Company) as `Company/Branch`,
                                    `progress`.ProgressDescription as `Status`,
                                    `order`.OrderDate as `Order Date`,
                                    `order`.AptDateTime as `Appt. Date`,
                                    `order`.LocalAptDateTime as `Local Time`,
                                    `order`.State as `ST`,
                                    `employees`.LastName as `Rep`,
                                    `agent`.FullName as `Loan Agent`,
                                    TIMESTAMPDIFF(MINUTE,`order`.OrderDate,`order`.FilledDate) as `TCE Fill`,
									TIMESTAMPDIFF(MINUTE,`order`.RepAssignDate,`order`.FilledDate) as `Fill`,
                                    if(`order`.DocsToNot = true, "Y", "N") as `Docs`,
                                    if(`order`.FaxBackReq = true, "Y", "N") as `FB`,
                                    if(`order`.FaxBackAcceptDate > now(), "Y", "N") as `FB Docs`,
                                    `order`.CommentDate,
                                    `order`.IsActive
							from `order` 
								LEFT JOIN `signer` on `order`.SignerId = `signer`.SignerId  
                                LEFT JOIN `borrower` on `order`.BorrowerId = `borrower`.BorrowerId 
                                LEFT JOIN `agent` on `order`.AgentId = `agent`.AgentId 
                                LEFT JOIN `broker` on `agent`.BrokerId = `broker`.BrokerID 
                                LEFT JOIN `branches` on `agent`.BranchID = `branches`.BranchID 
                                LEFT JOIN `progress` on `order`.ProgressId = `progress`.ProgressId
                                LEFT JOIN `employees` on `order`.RepId = `employees`.RepId) t1, (SELECT @rownum := 0) r ',
                                whereQuery, orderQuery, limitQuery
    );
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

    SELECT FOUND_ROWS() as TotalRecords;
END
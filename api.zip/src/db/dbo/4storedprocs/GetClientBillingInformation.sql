DROP PROCEDURE IF EXISTS `GetClientBillingInformation`;

DELIMITER $$
CREATE PROCEDURE `GetClientBillingInformation`(IN user_id INT)
BEGIN
	SELECT b.BrokerID, b.DefaultCourierAcnt, b.DefaultCourierID, 
		bd.APContactEmail, bd.APContactFax, bd.APContactPhone, bd.APEmail,
		bd.APExt, bd.APFax, bd.APFirst, bd.APLast, bd.APRep, bd.APRepPhone,
		bd.APTerms, bd.Inv, 
        p.PaymentId, p.MaskedNumber, p.ExpirationMonth, p.ExpirationYear, p.NameOnCard
	FROM broker b
	LEFT JOIN broker_detail bd ON b.BrokerID = bd.BrokerId
	LEFT JOIN payment p ON bd.PaymentMethodId = p.PaymentId
	WHERE b.BrokerID = user_id;
    
    SELECT CourierID, Courier FROM Courier;
END$$
DELIMITER ;

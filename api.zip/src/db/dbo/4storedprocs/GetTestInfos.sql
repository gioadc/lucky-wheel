DROP PROCEDURE IF EXISTS `GetTestInfos`;

DELIMITER $$
CREATE PROCEDURE `GetTestInfos`(
IN testName varchar(150),
IN active int,
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
    
	IF (active <> 0)
    THEN
		IF(active = 1)
		   THEN SET whereQuery = CONCAT(whereQuery, ' AND active = 1 ');
		ELSE SET whereQuery = CONCAT(whereQuery, ' AND (active IS NULL OR active = 0) ');
        END IF;
	END IF;
    
    IF (testName IS NOT NULL AND testName <> '')
		THEN SET whereQuery = CONCAT(whereQuery, ' AND testName LIKE  ''%', testName, '%''');
	END IF;
   
	SET @querySql= concat('
    SELECT 
    SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			ti.testId,
			ti.testName,
            ti.testDesc,
			CASE tp.isActive
			WHEN 1 THEN  ''Y''										
			ELSE ''N'' END as isProgramActive,
            CASE ti.active
			WHEN 1 THEN  ''Y''										
			ELSE ''N'' END as isActive,
			CASE tp.isPublished
			WHEN 1 THEN  ''Y''										
			ELSE ''N'' END as published
            FROM test_info ti
            LEFT JOIN training_programs tp ON tp.programId = (
			SELECT tpi.programId
			FROM training_program_test tpi 
            LEFT JOIN training_programs tp2 on tp2.programId=tpi.programId
			WHERE tpi.testId = ti.testId and tp2.isPublished = 1
			LIMIT 1 )
            , (SELECT @rownum := 0) r ',
            whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END
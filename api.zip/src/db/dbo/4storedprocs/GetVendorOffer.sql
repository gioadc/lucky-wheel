DROP PROCEDURE IF EXISTS `GetVendorOffer`;

DELIMITER $$
CREATE PROCEDURE `GetVendorOffer`(
	IN signerId int,
	IN sortColumn varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN orderID int,
    IN daysBack int,
    IN offerStatus varchar(3)
)
BEGIN	
    DECLARE orderQuery varchar(255);
	DECLARE sortDirectionQuery varchar(255);
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortColumn IS NULL OR sortColumn = '')
       THEN SET orderQuery = ' ORDER BY `OrderID`, AptDateTime ASC, OfferStatus ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortColumn, sortDirectionQuery);        
    END IF; 
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

	CASE daysBack
	  WHEN 365 THEN SET whereQuery = CONCAT(' WHERE `signer_offer`.`SentDate` >= NOW() - INTERVAL ', '1 YEAR');
	  WHEN 730 THEN SET whereQuery = CONCAT(' WHERE `signer_offer`.`SentDate` >= NOW() - INTERVAL ', '2 YEAR');
	  ELSE SET whereQuery = CONCAT(' WHERE `signer_offer`.`SentDate` >= NOW() - INTERVAL ', daysBack, ' DAY');
	END CASE;
        
	IF (orderID <> 0 )
    THEN SET whereQuery = CONCAT(whereQuery, ' AND `signer_offer`.`OrderID` = ', orderID);
    END IF;
    
    IF( offerStatus <> '0')
    THEN SET whereQuery = CONCAT(whereQuery, ' AND `signer_offer`.`OfferStatus` = \'', offerStatus, '\'');
    END IF;

    SET whereQuery = CONCAT(whereQuery, ' AND `signer_offer`.`SignerId` = ', signerId);
    
	SET @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* 
    FROM (
		SELECT `signer_offer`.`OrderID` AS `OrderID`,
				`loan_type`.`LoanType` AS `LoanType`,
				`order`.`AptDateTime` AS `AptDateTime`,
				`order`.`City` AS `City`,
				`order`.`Zip` AS `Zip`,
                 69.1*sqrt(POWER((`signer`.`Lat` - `order`.`Lat`), 2) + 0.6*POWER((`signer`.`Long` - `order`.`Long`), 2)) AS `Distance`,
                `signer_offer`.`OfferAmount` AS `OfferAmount`,
				`signer_offer`.`OfferStatus` AS `OfferStatus`
        FROM `signer_offer`
		INNER JOIN `order` ON `signer_offer`.`OrderID` = `order`.`OrderID`
        INNER JOIN `loan_type` ON `order`.`LoanType` = `loan_type`.`LoanTypeID`
		INNER JOIN `signer` ON `signer_offer`.`SignerId` = `signer`.`SignerId` ',
        whereQuery, orderQuery,
        ') AS t1, (SELECT @rownum := 0) r ' ,limitQuery);
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$

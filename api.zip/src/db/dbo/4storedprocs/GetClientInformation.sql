DROP PROCEDURE IF EXISTS `GetClientInformation`;

DELIMITER $$
CREATE PROCEDURE `GetClientInformation`(
IN client_id INT(11)
)
BEGIN
	-- client info
    SELECT
		-- company
		b.Company,
        b.Phone,
        b.Address,
        b.Suite,
        b.City,
        b.State,
        b.Zip,
        b.AdministratorFirst,
        b.AdministratorLast,
        b.Administratorext,
        b.AdministratorEmail,
        bd.AfterHoursPhone,
        b.DefaultCourierID,
        -- contact
        b.DefaultCourierAcnt,
        b.PrimaryContactFirst,
        b.PrimaryContactLast,
        b.Email,
        b.PrimaryContactext,
        b.PrimaryContactFax,
        b.EmailOpt,
        b.TextOpt,
        bd.Cell,
        b.AdditionalContact,
        b.AdditionalContactEmail,
        b.AdditionalContactPhone,
        b.AdditionalContactExt        
    FROM `broker` AS b
    LEFT JOIN `broker_detail` AS bd ON bd.BrokerId = b.BrokerID
    WHERE b.BrokerID = client_id;
    
    -- return address
    SELECT 
		RaId,
		BrokerId,
		CONCAT(case when r.Department is null then '' else concat(r.Department, ', ') end,
			case when r.Address is null then '' else concat(r.Address, ', ') end,
            case when r.Suite is null then '' else concat(r.Suite, ', ') end,
            case when r.City is null then '' else concat(r.City, ', ') end,
            case when r.State is null then '' else concat(r.State, ' ') end,
            case when r.Zip is null then '' else concat(r.Zip) end) 
		AS FullAddress,
		r.Department,
		r.Address,
		r.Suite,
		r.City,
		r.Zip,
		CASE DefaultAddr WHEN 'Y' THEN TRUE ELSE FALSE END AS DefaultAddr,
		BranchId
	FROM `return_addr` AS r
    WHERE r.BrokerID = client_id;
    
    -- cc invoice email list
    SELECT
		BrokerEmailId,
		BrokerID,
		EName,
		Email,
		case when EmailFor='I' OR EmailFor='B' THEN 1 ELSE 0 END AS ForInvoice,
        case when EmailFor='S' OR EmailFor='B' THEN 1 ELSE 0 END AS ForStatus
	FROM `broker_emails` AS b
    WHERE b.BrokerID = client_id
	ORDER BY b.BrokerEmailId DESC;
        
	-- couriers
    SELECT 
		CourierID,
		Courier
	FROM `courier`;

END$$
DELIMITER ;

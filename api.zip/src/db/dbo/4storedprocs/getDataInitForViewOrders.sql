DROP PROCEDURE IF EXISTS `getDataInitForViewOrders`;
DELIMITER $$
CREATE PROCEDURE `getDataInitForViewOrders`()
BEGIN
	select b.Company from broker b UNION select br.BranchName from branches br;
	select p.ProgressId, p.ProgressDescription from progress p;
END$$
DELIMITER ;
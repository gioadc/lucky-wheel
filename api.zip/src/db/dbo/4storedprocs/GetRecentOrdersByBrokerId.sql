DROP PROCEDURE IF EXISTS `GetRecentOrdersByBrokerId`;

DELIMITER $$
CREATE PROCEDURE `GetRecentOrdersByBrokerId`(
	IN `sortBy` VARCHAR(255),
	IN `sortDirection` BIT,
	IN `pageNumber` INT,
	IN `pageSize` INT,
	IN `recentDay` INT,
	IN `brokerId` INT

)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN

    DECLARE orderQuery varchar(255);  
	 DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  

	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE o.OrderDate >= DATE(NOW()) - INTERVAL ',recentDay,' DAY AND o.brokerId =', brokerId);
         
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
				o.OrderId, b.LastName as ClientLast, s.LastName as VendorLast, c.Company, p.ProgressDescription, o.OrderDate, o.AptDateTime
            FROM 
					`order` o
					LEFT JOIN `borrower` b ON
						o.BorrowerId = b.BorrowerId
					LEFT JOIN `signer` s ON 
						o.SignerId = s.SignerId
					LEFT JOIN `broker` c ON
						o.BrokerId = c.BrokerID
					LEFT JOIN `progress` p ON
						o.ProgressId = p.ProgressId
				, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);
   PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;

END
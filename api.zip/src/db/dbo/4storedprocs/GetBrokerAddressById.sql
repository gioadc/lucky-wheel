DROP PROCEDURE IF EXISTS `GetBrokerAddressById`;

DELIMITER $$
CREATE PROCEDURE `GetBrokerAddressById` (
IN brokerId INT(11)
)
BEGIN    
	SELECT `broker.Address`, `broker.City`, `broker.State`, `broker.Zip`
    FROM `broker`
    WHERE BrokerID = brokerId;
END$$

DELIMITER ;
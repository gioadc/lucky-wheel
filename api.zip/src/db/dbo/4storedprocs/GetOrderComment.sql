CREATE DEFINER=`tce`@`%` PROCEDURE `GetOrderComment`(
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 and TypeID=1';
    
	set @querySql = CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, t1.* from ( select `comment`.CommentID as `CommentID`,
									`comment`.CreatedDate as `CreatedDate`,         
									`comment`.Description as `Description`,                                     
									`comment`.OwnerID as `OwnerID`,                                     
									`comment`.TypeID as `TypeID`,                                    
									`comment`.TenantID as `TenantID`,                                     
									`role_permission`.Type as Type,                                
									CONCAT(`employees`.LastName, `employees`.FirstName) as `FirstName`,                                     
									CONCAT(`broker`.PrimaryContactFirst,`broker`.PrimaryContactLast) as PrimaryContact,                                     
									CONCAT(`signer`.FirstName, `signer`.LastName) as `CreateBySigner`                                            
                        FROM `comment`                             
									LEFT JOIN `users` on `comment`.CreatedBy = `users`.UsersId 
                                    LEFT JOIN `user_roles` on `users`.UsersId = `user_roles`.UsersId   
									LEFT JOIN `role_permission` on `user_roles`.RoleId = `role_permission`.RoleId                           
									LEFT JOIN `employees` on `users`.MappingUserId = `employees`.RepId                             
									LEFT JOIN `broker` on `users`.MappingUserId = `broker`.BrokerID        
									LEFT JOIN `signer` on `users`.MappingUserId = `signer`.SignerId) t1, (SELECT @rownum := 0) r', whereQuery, orderQuery, limitQuery );

	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END
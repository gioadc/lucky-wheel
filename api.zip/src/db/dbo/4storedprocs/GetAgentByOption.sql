DROP PROCEDURE IF EXISTS `GetAgentByOption`;

DELIMITER $$

CREATE DEFINER=`tce`@`%` PROCEDURE `GetAgentByOption`(
IN brokerId int,
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN agentId int,
IN agentName varchar(255),
IN agentEmail varchar(255)
)
BEGIN

    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);

    SET whereQuery = CONCAT(' WHERE 1=1 AND (a.BrokerId = ', brokerId, ' ', 'OR b.GID = ', brokerId, ' )');

    IF (agentId IS NOT NULL AND agentId > 0)
        THEN SET whereQuery = CONCAT(whereQuery, ' AND agentID = ', agentId , ' ');
    END IF;

    IF (agentName IS NOT NULL AND agentName <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND FullName LIKE "%', agentName, '%" ');
    END IF;

    IF (agentEmail IS NOT NULL AND agentEmail <> '')
        THEN SET whereQuery = CONCAT(whereQuery, ' AND a.Email LIKE "%', agentEmail, '%" ');
    END IF;

    SET @querySql= CONCAT('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber, 
        a.AgentId, b.Company, a.FullName, a.Ext, a.Email, a.Fax, u.UserName, a.Inactive
		from agent as a
		INNER JOIN broker AS b ON b.brokerid = a.brokerid
		LEFT JOIN users AS u on u.MappingUserId = a.AgentId,
        (SELECT @rownum := 0) r ', 
        whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;

END$$
DELIMITER ;
DROP PROCEDURE IF EXISTS `spGetOrderIssue`;
DROP PROCEDURE IF EXISTS `GetOrderIssuesByOrderId`;

DELIMITER $$
CREATE PROCEDURE `GetOrderIssuesByOrderId` (
	IN orderId int,
	IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int
)
BEGIN	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE 
		SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE 
		SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);        
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = CONCAT(' WHERE op.OrderID = ',orderId);
     
     set @querySql = CONCAT('select SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
									op.ProblemID as ProblemId,
									pt.Description as Type,
                                    op.Date as Date,
                                    op.EnteredBy as EnteredBy, 
									u.UserName as UserName,                                     
                                    CASE op.Mistake
										WHEN 1 THEN  ''Y''										
										ELSE ''N''
									END as Mistake,
                                    op.OrderID as OrderID,
                                    ps.Description as Status
							FROM order_problem op
                            left join users u on u.UsersId = op.EnteredBy 
                            left join problem_types pt on op.type=pt.id
							left join problem_status ps on ps.Id = op.Status, 
                            (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    END$$

DELIMITER ;
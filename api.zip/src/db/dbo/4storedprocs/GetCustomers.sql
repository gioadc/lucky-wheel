DROP PROCEDURE IF EXISTS `GetCustomers`;

DELIMITER $$
CREATE PROCEDURE `GetCustomers` (
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN customerID varchar(100),
IN customerName varchar(500),
IN brokerId varchar(100)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = CONCAT(' WHERE c.brokerId=', brokerId, ' AND (c.IsActive = 1 or c.IsActive is null)');
	IF (customerID IS NOT NULL AND customerID <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND c.CustomerId = ', customerID);
	END IF;
    IF (customerName IS NOT NULL AND customerName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND c.Name LIKE ''%', customerName, '%''');
	END IF;
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			c.CustomerId,
			c.Name,
            c.Email, t.ProductType
            FROM customers c inner join 
            (SELECT cpt.CustomerId, group_concat(l.LoanType SEPARATOR '', '') as ProductType
			from customer_product_type cpt
            inner join loan_type l on cpt.ProductType=l.LoanTypeId
			GROUP BY CustomerId 
            order by l.LoanType) t on c.CustomerId = t.CustomerId
            , (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$

DELIMITER ;
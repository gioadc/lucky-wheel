DROP PROCEDURE IF EXISTS `getOrderStatusDropDownData`;

DELIMITER $$
CREATE PROCEDURE `getOrderStatusDropDownData`()
BEGIN
	select * from progress;
	SELECT * FROM delivery_method;
	select e.RepId, concat(e.FirstName, ' ', e.LastName) as `RepID` from employees e where Active;
	select * from loan_type;
    select p.ProgressId as `defaultProgressSelect` from progress p where p.ProgressDescription = "Open";
END
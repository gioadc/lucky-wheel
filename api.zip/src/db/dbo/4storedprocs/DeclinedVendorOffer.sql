DROP PROCEDURE IF EXISTS `DeclinedVendorOffer`;

DELIMITER $$
PROCEDURE `DeclinedVendorOffer`(
	IN orderId int,
    IN signerId int,
    IN userId int,
    IN selectedReasonOptions int, 
    IN altTime datetime,
    IN feeAmount decimal(19,4),
    IN returnTime datetime,
    IN notDoProduct varchar(100),
    IN additionalInfo varchar(250)
)
BEGIN
    IF (selectedReasonOptions = 2 OR selectedReasonOptions = 3)
    THEN
		IF(selectedReasonOptions = 2)
        THEN SET selectedReasonOptions = 8;
        END IF;
        
        IF(selectedReasonOptions = 3)
        THEN SET selectedReasonOptions = 9;
        END IF;
        
		UPDATE `signer_offer`
        SET `DenialReasonID` = selectedReasonOptions,
			`OfferStatus` = 'P'
		WHERE `signer_offer`.`OrderId` = orderId AND `signer_offer`.`SignerId` = signerId;
        
        INSERT INTO `order_fee_approve`(`OrderId`,`UsersId`,`ReasonCode`,`FeeAmount`,`FeeApproved`,`DateStamp`)
        VALUES (orderId,userId,selectedReasonOptions,feeAmount,'Open', NOW());
	ELSE       
		UPDATE `signer_offer`
        SET `DenialReasonID` = selectedReasonOptions,
			`AltTime` = altTime,
            `ReturnTime` = returnTime,
            `NotDoProduct` = notDoProduct,
            `AdditionalInfo` = additionalInfo,
            `OfferStatus` = 'D'
		WHERE `signer_offer`.`OrderId` = orderId AND `signer_offer`.`SignerId` = signerId;
	END IF;
		
END$$

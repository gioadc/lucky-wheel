DROP PROCEDURE IF EXISTS `GetUserRolePermissions`;

DELIMITER $$
CREATE PROCEDURE `GetUserRolePermissions` (
IN user_Id int
)
BEGIN  
	SELECT rp.* FROM user_roles ur
    JOIN role_permission rp ON ur.RoleId = rp.RoleId
    WHERE ur.UsersId = user_Id;
END$$

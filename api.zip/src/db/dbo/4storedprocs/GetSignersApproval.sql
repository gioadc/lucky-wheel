CREATE DEFINER=`tce`@`%` PROCEDURE `GetSignersApproval`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN searchOrderID int,
IN searchStatus varchar(255),
IN searchRequestBy varchar(255)
)
BEGIN
    DECLARE orderIDWhereSql varchar(255);
    DECLARE statusWhereSql varchar(255);
    DECLARE signersApprovalTableSql varchar(255);
    
    DECLARE requestByWhereSql varchar(255);
    DECLARE employeesTableSql varchar(255);
    
    DECLARE searchedTableSql varchar(1000);
    DECLARE resultTableSql varchar(1000);
    
	DECLARE orderSql varchar(255);
	DECLARE sortDirectionSql varchar(255);
    DECLARE limitSql varchar(255);
    
    -- search condition for OrderID and Status
    IF (searchOrderID IS NULL)
       THEN SET orderIDWhereSql = '';
	ELSE SET orderIDWhereSql = CONCAT(' AND OrderId = ', searchOrderID);
    END IF;
    IF (searchStatus IS NULL OR searchStatus = '' OR searchStatus = 'All')
       THEN SET statusWhereSql = '';
	ELSE SET statusWhereSql = CONCAT(' AND Status = ''', searchStatus,'''');
    END IF;

    -- query that return all search rows of table SIGNER APPROVAL
    SET signersApprovalTableSql = CONCAT('SELECT * FROM signers_approval WHERE TRUE' , orderIDWhereSql, statusWhereSql);

	-- search condition for RequestBy
	IF (searchRequestBy IS NULL OR searchRequestBy = '')
       THEN SET requestByWhereSql = '';
	ELSE SET requestByWhereSql = CONCAT(' AND CONCAT_WS(" ",FirstName, LastName) LIKE ''%', searchRequestBy,'%''');
    END IF;
    
    
	-- query that return all search rows of table EMPLOYEES
    SET employeesTableSql = CONCAT('SELECT RepId, FirstName, LastName FROM employees WHERE TRUE', requestByWhereSql);
    
    -- join two table to get search result
    SET searchedTableSql = CONCAT('SELECT SA.*, CONCAT_WS(" ",E.FirstName, E.LastName) AS RequesterName FROM (', signersApprovalTableSql, ') SA JOIN (', employeesTableSql, ') E ON E.RepId = SA.RequestBy');
    
	-- limit searchResult
    SET limitSql = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ', ', pageSize);
        
    -- sort
	IF (sortDirection = 1) 
		THEN SET sortDirectionSql = ' ASC';
	ELSE SET sortDirectionSql = ' DESC';
    END IF;
	-- SELECT sortDirectionQuery;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderSql = ' ORDER BY OrderId ';
	ELSE SET orderSql = CONCAT(' ORDER BY ', sortBy, sortDirectionSql);
    END IF;
    
    -- join order and signer table to get more information -> sort
    SET resultTableSql = CONCAT('SELECT SQL_CALC_FOUND_ROWS SA.*, CONCAT_WS(" ",S.FirstName, S.LastName) AS VendorName FROM (', searchedTableSql, ') SA LEFT JOIN signer S ON S.SignerId = SA.SignerId', orderSql, limitSql,';');
    
	SET @querySql= resultTableSql;
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    SELECT COUNT(*) AS CountOpen FROM signers_approval WHERE Status='Open';
END
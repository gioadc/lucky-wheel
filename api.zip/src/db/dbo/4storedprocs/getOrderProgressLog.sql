DROP PROCEDURE IF EXISTS `getOrderProgressLog`;

DELIMITER $$

CREATE PROCEDURE `getOrderProgressLog`(
	IN OrderId int(11),
    IN sortBy varchar(255),
	IN sortDirection bit,
	IN pageNumber int,
	IN pageSize int,
    IN accountId int(11)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY opl.DateLog ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
    IF (OrderId IS NOT NULL AND OrderId >= 0)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND opl.OrderId = ', OrderId);
	END IF;
    
    SET whereQuery = CONCAT(whereQuery,' AND (opl.IsPrivate = 0 or opl.UsersId = ',accountId,'  or "Vendor" IN (select distinct rp.Type from user_roles ur join role_permission rp on ur.RoleId = rp.RoleId where ur.UsersId = opl.UsersId )) ');
    
    SET @querySql = concat('select  SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,opl.ProgressLogId, opl.DateLog as Date, opl.Activity, u.UserName as Actor
									from order_progress_log opl
									left join users u on u.UsersId = opl.UsersId
                                    ,(SELECT @rownum := 0) r ',
						  whereQuery, orderQuery, limitQuery);
                          
	PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$
DELIMITER $$
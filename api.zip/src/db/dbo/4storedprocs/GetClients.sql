DROP PROCEDURE IF EXISTS `GetClients`;

DELIMITER $$
CREATE PROCEDURE `GetClients` (
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN clientID varchar(100),
IN clientName varchar(500),
IN address varchar(500),
IN city varchar(200),
IN state varchar(100),
IN inactive bit
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = ' WHERE IsAvailable =1';
	IF (clientID IS NOT NULL AND clientID <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND BrokerID = ', clientID);
	END IF;
    IF (clientName IS NOT NULL AND clientName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Company LIKE ''%', clientName, '%''');
	END IF;
    IF (address IS NOT NULL AND address <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Address LIKE ''%', address, '%''');
	END IF;
    IF (city IS NOT NULL AND city <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND City LIKE ''%', city, '%''');
	END IF;
    IF (state IS NOT NULL AND state <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND State = ', '''', state, '''');
	END IF;
    IF (inactive)
		THEN SET whereQuery = CONCAT(whereQuery ,' AND Inactive = 1');
	ELSE
		SET whereQuery = CONCAT(whereQuery ,' AND (Inactive = 0', ' OR Inactive IS NULL)');
	END IF;
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			BrokerID,
			Company,
            Address,
            City,
            State,
			Inactive
            FROM broker, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$

DELIMITER ;
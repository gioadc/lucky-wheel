DELIMITER $$
CREATE PROCEDURE `GetOrderFeeApproveGridView`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN orderId int,
IN feeApproved varchar(100)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = '';
	IF (orderId IS NOT NULL)
		THEN SET whereQuery = CONCAT(whereQuery ,' WHERE f.OrderId = ', orderId);
	END IF;
    IF (feeApproved IS NOT NULL AND feeApproved <>'')
		THEN
			IF (whereQuery <> '')
				THEN
					SET whereQuery = CONCAT(whereQuery ,' AND');
				ELSE
					SET whereQuery = CONCAT(whereQuery ,' WHERE');
			END IF;
			SET whereQuery = CONCAT(whereQuery ,' f.FeeApproved = ''', feeApproved, '''');
	END IF;

	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS 
			f.FeeApprovalId,
			f.DateStamp AS RequestDate,
			u.UserName,
            u.UsersId,
			f.OriginalAmount AS OriginalFee,
			f.FeeAmount AS ProposedFee,
			r.ReasonDescription,
			f.FeeApproved as Status,
			f.FeeDescripId,
			f.OrderId,
			f.FeeReason,
            CASE WHEN IsUserVendor(u.UsersId) = 1 THEN \'Vendor\' ELSE \'\' END AS Type,
			fd.Description AS FeeDescription,
			of.BrokerFee AS ClientFee
		FROM `order_fee_approve` AS f
		INNER JOIN `fee_description` AS fd ON fd.FeeDescriptionId = f.FeeDescripId
		LEFT JOIN `order_fee` AS of ON of.OrderID=f.OrderId AND of.FeeDescripID=f.FeeDescripId
		LEFT JOIN `order_fee_approve_reason` AS r ON f.ReasonCode = r.ReasonCode
		LEFT JOIN `users` AS u ON u.UsersId = f.UsersId
            ', whereQuery, orderQuery, limitQuery);
    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$
DELIMITER ;

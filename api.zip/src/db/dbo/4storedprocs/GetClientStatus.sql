DROP procedure IF EXISTS `GetClientStatus`;

DELIMITER $$
CREATE PROCEDURE `GetClientStatus` ()
BEGIN
    SELECT 
    o.OrderID,
    o.BrokerIDNum,
    b.Company,
    a.FullName,
    o.LastName,
    o.OrderDate,
    o.AptDateTime,
    o.FilledDate,
    concat(s.FirstName , ' ' , s.LastName) as Signer,
    concat(e.FirstName, ' ', e.LastName) as SaleRep,
    o.closeddate,
    p.ProgressDescription
FROM
    `order` o
        INNER JOIN
    Signer s ON o.SignerID = s.SignerID
        INNER JOIN
    Employees e ON o.RepID = e.RepID
        INNER JOIN
    Progress p ON o.ProgressID = p.ProgressID
        INNER JOIN
    Broker b ON o.BrokerID = b.BrokerID
        INNER JOIN
    Agent a ON o.AgentID = a.agentid
    WHERE   (DATE(o.Orderdate) BETWEEN DATE(DATE_ADD(NOW(), INTERVAL -1 DAY)) AND DATE(NOW())) OR
			(DATE(o.closeddate) BETWEEN DATE(DATE_ADD(NOW(), INTERVAL -1 DAY)) AND DATE(NOW()));
END$$

DELIMITER ;
DROP PROCEDURE IF EXISTS `GetTrainingCourses`;

DELIMITER $$
CREATE PROCEDURE `GetTrainingCourses` (
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int,
IN courseName varchar(150),
IN courseStatus varchar(2)
)
BEGIN
	DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);
	DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY title ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
     
	SET whereQuery = CONCAT(' WHERE 1=1');
	IF (courseStatus IS NOT NULL AND courseStatus <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND c.IsActive = ', courseStatus);
	END IF;
    IF (courseName IS NOT NULL AND courseName <>'')
		THEN SET whereQuery = CONCAT(whereQuery ,' AND c.Title LIKE ''%', courseName, '%''');
	END IF;
	SET @querySql= concat('select
			c.courseId,
			c.title,
            c.description, 
            SUBSTRING_INDEX(c.videoFile, ''_'', -1) as videoFile,
            SUBSTRING_INDEX(c.document, ''_'', -1) as document,
            c.isActive,
            IsActiveProgram(c.courseId) as isActiveProgram,
            IsPublishedProgram(c.courseId) as isPublishedProgram
            FROM training_courses c 
            , (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
END$$

DELIMITER ;
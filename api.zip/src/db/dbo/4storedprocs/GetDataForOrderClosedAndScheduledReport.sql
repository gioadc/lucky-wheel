DROP PROCEDURE IF EXISTS `GetDataForOrderClosedAndScheduledReport`;

DELIMITER $$
CREATE PROCEDURE `GetDataForOrderClosedAndScheduledReport` (

)
BEGIN
	IF (inputOrderId IS NOT NULL AND inputOrderId >= 0)
		THEN 
		SELECT O.orderId, O.toEmail, O.alwaysCC, O.emailCC, O.fullName, O.fax, O.company, O.brokerIdNum, O.signerId, O.trackingNumber, O.courier, O.aptDateTime, O.brokerId, SUM(BF.BrokerFee) AS brokerFees
        FROM
			(
			SELECT
				O.OrderId AS orderId, A.Email AS toEmail, B.CCEmail as alwaysCC, GROUP_CONCAT(BE.Email SEPARATOR '; ') AS emailCC, 
				A.fullName, A.fax, B.company, O.brokerIdNum, O.signerId, O.trackingNumber, C.courier, O.aptDateTime, O.brokerID
			FROM
				(SELECT * from `order` WHERE `orderId` = inputOrderId) O LEFT JOIN
				`agent` A ON O.AgentId = A.AgentId LEFT JOIN
				`broker` B ON O.BrokerID = B.BrokerID LEFT JOIN
				(SELECT * FROM `broker_emails` WHERE EmailFor <> 'I') BE ON O.BrokerID = BE.BrokerID LEFT JOIN
				`courier` C ON C.CourierID = O.CourierID
				GROUP BY O.OrderId
			) O LEFT JOIN
            `broker_fee` BF ON BF.BrokerID = O.BrokerID
		;
	END IF;
END$$

DELIMITER ;
DROP PROCEDURE IF EXISTS `GetAllState`;

DELIMITER $$
CREATE PROCEDURE `GetAllState`()
BEGIN
    SELECT `Code`, `Description` 
	FROM `state`
    ORDER BY Code;
END$$
DELIMITER ;

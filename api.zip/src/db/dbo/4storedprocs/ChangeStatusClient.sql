DROP procedure IF EXISTS `ChangeStatusClient`;

DELIMITER $$
CREATE PROCEDURE `ChangeStatusClient` (IN clientId int)
BEGIN
    declare brokerStatus bit;
    declare cancelProgressId int;
    declare	closeProgressId int;
    set brokerStatus = (select Inactive from broker where brokerid = clientId);
    set cancelProgressId = (select ProgressId from progress where ProgressDescription = "Canceled");
    set closeProgressId = (select ProgressId from progress where ProgressDescription = "Closing Completed");

    UPDATE broker 
    SET 
        Inactive = !brokerStatus
    WHERE
        brokerid = clientId;
    if(brokerStatus = 0) then
    UPDATE broker 
    SET 
        Inactive = 1
    WHERE
        GID = clientId;
    update agent set Inactive = 1 where brokerid = clientId;
    UPDATE `order` 
    SET 
        ProgressId = cancelProgressId
    WHERE
        brokerid = clientId
            AND ProgressId NOT IN (cancelProgressId, closeProgressId);
    end if;
END$$

DELIMITER ;
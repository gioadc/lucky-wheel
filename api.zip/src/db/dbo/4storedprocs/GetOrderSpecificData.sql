DROP PROCEDURE IF EXISTS `GetOrderSpecificData`;

DELIMITER $$
CREATE PROCEDURE `GetOrderSpecificData`(
IN order_Id INT(11)
)
BEGIN    
	-- order data
	SELECT
		AlwaysCC,
        EmailCC,
        CCInvEmail,
        Collect1,
        Collect2,
        Collect3,
        Collect4,
        Collect5,
        Collect6,
        Collect7,
        Collect8,
        Collect9,
        Collect10,
        ReturnAddress,
        BrokerId,
        OrderId
    FROM `order` AS o
    WHERE o.OrderID = order_Id;
    
    -- lender Specific from broker
    SELECT
        b.LenderSpecific
    FROM `order` AS o
    INNER JOIN `broker` AS b ON b.BrokerID = o.BrokerId
    WHERE OrderID = order_Id;
    
    -- order special instructions list
    SELECT
		`Instructions1`,
		`Permanently1`,
		`Instructions2`,
		`Permanently2`,
		`Instructions3`,
		`Permanently3`,
		`Instructions4`,
		`Permanently4`,
		`Instructions5`,
		`Permanently5`,
		`Instructions6`,
		`Permanently6`,
		`Instructions7`,
		`Permanently7`,
		`Instructions8`,
		`Permanently8`,
		`Instructions9`,
		`Permanently9`,
		`Instructions10`,
		`Permanently10`
	FROM `order_special_instructions`
    WHERE OrderID = order_Id;
    
    -- cc email list
    SELECT
		b.Email
	FROM `broker_emails` AS b
    INNER JOIN `order` AS o ON b.BrokerID = o.BrokerId
    WHERE o.OrderId = order_Id
		AND (EmailFor='S' OR EmailFor='B')
	ORDER BY b.Email;
    
    -- cc invoice email list
    SELECT
		b.Email
	FROM `broker_emails` AS b
    INNER JOIN `order` AS o ON b.BrokerID = o.BrokerId
    WHERE o.OrderId = order_Id
		AND (EmailFor='I' OR EmailFor='B')
	ORDER BY b.Email;
    
    -- return address list
    select  
		CONCAT(case when r.Department is null then '' else concat(r.Department, ', ') end,
			case when r.Address is null then '' else concat(r.Address, ', ') end,
            case when r.Suite is null then '' else concat(r.Suite, ', ') end,
            case when r.City is null then '' else concat(r.City, ', ') end,
            case when r.State is null then '' else concat(r.State, ' ') end,
            case when r.Zip is null then '' else concat(r.Zip) end) 
		AS ReturnAddr,
		r.Department,
		r.Address,
		r.Suite,
		r.City,
		r.Zip
    from `return_addr` as r
    inner join `broker` as b on b.BrokerID = r.BrokerID
    inner join `order` as o on b.BrokerID = o.BrokerId
    WHERE o.OrderId = order_Id
    ORDER BY ReturnAddr;
END$$
DELIMITER ;

DROP procedure IF EXISTS `GetOrderDatesById`;

DELIMITER $$
CREATE PROCEDURE `GetOrderDatesById` (
IN orderId INT(11)
)
BEGIN    
	SELECT o.OrderDate, o.FilledDate, o.AptDateTime, o.LocalAptDateTime, o.OriginalOrderDate, o.ClosedDate, o.CommentDate, o.DropDate
	FROM `order` AS o
    WHERE o.OrderId = orderId;
END$$

DELIMITER ;
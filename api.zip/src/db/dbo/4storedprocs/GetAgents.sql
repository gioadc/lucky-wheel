DROP PROCEDURE IF EXISTS `GetAgents`;

DELIMITER $$

CREATE PROCEDURE `GetAgents`(
IN sortBy varchar(255),
IN sortDirection bit,
IN pageNumber int,
IN pageSize int
)
BEGIN
	
    DECLARE orderQuery varchar(255);  
	DECLARE sortDirectionQuery varchar(255);  
    DECLARE limitQuery varchar(255);  
    DECLARE whereQuery varchar(255);  
    
	IF (sortDirection = 1) 
		THEN SET sortDirectionQuery = ' ASC ';
	ELSE SET sortDirectionQuery = ' DESC ';
    END IF;
    
    IF (sortBy IS NULL OR sortBy = '')
       THEN SET orderQuery = ' ORDER BY RowNumber ';
	ELSE SET orderQuery = CONCAT(' ORDER BY ', sortBy, sortDirectionQuery);
    END IF;    
   
    SET limitQuery = CONCAT(' LIMIT ',  (pageNumber-1)*pageSize, ',', pageSize);
	
    SET whereQuery = ' WHERE 1=1 ';
     
	SET @querySql= concat('SELECT SQL_CALC_FOUND_ROWS @rownum := @rownum + 1 AS RowNumber,
			AgentId,
			FullName,
            Direct,
            Ext,
            Fax,
            Email,
            AfterhoursPhone,
            CAST(InActive AS unsigned) AS InActive 
            FROM Agent, (SELECT @rownum := 0) r ', whereQuery, orderQuery, limitQuery);

    PREPARE stmt FROM @querySql;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    
    SELECT FOUND_ROWS() as TotalRecords;
    
END$$
DELIMITER ;
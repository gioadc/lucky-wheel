DROP PROCEDURE IF EXISTS `GetOrderFees`;

DELIMITER $$
CREATE PROCEDURE `GetOrderFees` (
IN order_Id INT(11)
)
BEGIN    
	SELECT 
        o.FeeId, 
        o.FeeDescripID,
        f.Description,
        o.BrokerFee, 
        o.SignerFee, 
        o.Comment,
        o.OrderID
	FROM order_fee AS o
	LEFT JOIN fee_description AS f ON o.FeeDescripID = f.FeeDescriptionId
    WHERE o.OrderID = order_Id
    ORDER BY Date;
END$$

DELIMITER ;
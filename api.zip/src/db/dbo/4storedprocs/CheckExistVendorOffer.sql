DROP procedure IF EXISTS `CheckExistVendorOffer`;

DELIMITER $$
CREATE PROCEDURE `CheckExistVendorOffer`(
	IN aptDateTime datetime,
    IN signerId int,
    IN orderId int
)
BEGIN
	DECLARE IsValid int;
	DECLARE countOffer int;
    DECLARE countVendor int;

    SET countOffer = (SELECT COUNT(`order`.`OrderId`) AS count
    FROM `order`
    WHERE `order`.`SignerId` = signerId	
    AND DATE_FORMAT(`order`.`AptDateTime`, "%Y%m%d%H%i") = DATE_FORMAT(aptDateTime, "%Y%m%d%H%i"));
    
    SET isValid = 0;

    IF countOffer > 0 THEN SET isValid = 1;
	ELSE 
		SET countVendor = (SELECT COUNT(`order`.`signerId`) AS count
		FROM `order`
		WHERE `order`.`OrderId` = orderId);

        IF countVendor > 0
        THEN SET isValid = 2;
        END IF;
    END IF;

    SELECT isValid;
END$$

DELIMITER ;
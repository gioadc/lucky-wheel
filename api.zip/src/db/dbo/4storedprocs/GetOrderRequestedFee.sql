use tce_dev;
DROP PROCEDURE IF EXISTS `GetOrderRequestedFee`;

DELIMITER $$
CREATE PROCEDURE `GetOrderRequestedFee` (
IN order_Id INT(11)
)
BEGIN  
		SELECT
		f.FeeApprovalId,
		f.DateStamp AS RequestDate,
        u.UserName,
        f.OriginalAmount AS OriginalFee,
        f.FeeAmount AS ProposedFee,
        r.ReasonDescription,
        f.FeeApproved as Status,
        f.FeeDescripId,
        f.OrderId,
        f.FeeReason,
        CASE WHEN IsUserVendor(u.UsersId) = 1 THEN 'Vendor' ELSE '' END AS Type,
        fd.Description AS FeeDescription,
        of.BrokerFee AS ClientFee
	FROM `order_fee_approve` AS f
    INNER JOIN `fee_description` AS fd ON fd.FeeDescriptionId = f.FeeDescripId
    LEFT JOIN `order_fee` AS of ON of.OrderID=f.OrderId AND of.FeeDescripID=f.FeeDescripId
    LEFT JOIN `order_fee_approve_reason` AS r ON f.ReasonCode = r.ReasonCode
    LEFT JOIN `users` AS u ON u.UsersId = f.UsersId
    WHERE f.OrderID = order_Id;
END$$
DROP PROCEDURE IF EXISTS `getOrderDetailtStatus`;

DELIMITER $$
CREATE PROCEDURE `getOrderDetailtStatus`(
in order_Id int(11)
)
BEGIN
	select `order`.OrderId,
       `order`.DocDelMethod as `deliveryMethod`,
       `order`.RepId as `repId`,
       `order`.Filledby as `filledBy`,
       `order`.BrokerIdNum as `referenceNumber`,
       courier.Courier as `courier`,
       `order`.TrackingNumber as `trackingNumber`,
       broker.DefaultCourierAcnt as `courierAccountNumber`,
       `order`.TrackingNumber2 as `additionalTrackingNumber`,
       `order`.FaxBackReq as `faxBackRequired`,
       `order`.LoanType,
       `order`.ProgressId,
       `order`.Service,
       `order`.CustomerId,
       `order`.BrokerId,
       concat(employees.FirstName,' ', employees.LastName) as RepName
	from `order` left join broker on `order`.BrokerId = broker.BrokerID 
    left join courier on broker.DefaultCourierID = courier.CourierID 
    left join employees on `order`.RepId = employees.RepId
    where `order`.OrderId = order_Id;
END$$
DELIMITER ;
CREATE DEFINER=`tce`@`%` PROCEDURE `GetUserAdditionalInfoList`(
	IN `signerIdInput` INT
)
LANGUAGE SQL
NOT DETERMINISTIC
CONTAINS SQL
SQL SECURITY DEFINER
COMMENT ''
BEGIN
	DECLARE coverageAreasIds varchar(1500);
    DECLARE sqlQuery varchar(255);
    
	SELECT * FROM `loan_type`;
	SELECT * FROM `language`;
	SELECT @row := @row + 1 as Seq, t.*	FROM `state` t, (SELECT @row := 0) r;
    
	SELECT `CoverageArea` INTO coverageAreasIds
	FROM `signer`
	WHERE `SignerId` = signerIdInput;

    IF coverageAreasIds IS NOT NULL AND coverageAreasIds <> ''
    THEN
		SET @sqlQuery = CONCAT('

		SELECT `AreaId`, `Area`, `ZipCode`, `AreaCode`
		FROM `area`
		WHERE `AreaId` IN(', coverageAreasIds, ')');
		
		PREPARE stmt FROM @sqlQuery;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
	END IF;
END
ALTER TABLE `training_programs` ADD COLUMN `IsPublished` BIT NULL;
ALTER TABLE `training_programs` ADD COLUMN `Description` VARCHAR(250);
ALTER TABLE `training_programs` ADD COLUMN `Trainee` VARCHAR(10);

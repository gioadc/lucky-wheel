CREATE TABLE IF NOT EXISTS `sales_reps` (
    `SalesRepId` INT(11) NOT NULL AUTO_INCREMENT,
    `FirstName` VARCHAR(30),
    `LastName` VARCHAR(30),
    PRIMARY KEY (`SalesRepId`)
)
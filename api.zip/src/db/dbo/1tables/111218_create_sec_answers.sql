CREATE TABLE IF NOT EXISTS `sec_answers` (
    `AnswerId` INT(11) NOT NULL AUTO_INCREMENT,
    `UserId` INT(11),
    `ChalId1` INT(11),
    `Answer1` VARCHAR(250),
    `ChalId2` INT(11),
    `Answer2` VARCHAR(250),
    `ChalId3` INT(11),
    `Answer3` VARCHAR(250),    
    PRIMARY KEY (`AnswerId`)
)
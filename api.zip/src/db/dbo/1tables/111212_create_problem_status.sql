CREATE TABLE IF NOT EXISTS `problem_status` (
    `Id` INT(11) NOT NULL AUTO_INCREMENT,
    `Description` VARCHAR(50),
    PRIMARY KEY (`Id`)
);
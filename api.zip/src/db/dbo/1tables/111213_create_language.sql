CREATE TABLE `language` (
  `LanguageID` INT NOT NULL AUTO_INCREMENT,
  `Language` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`LanguageID`),
  UNIQUE INDEX `LanguageID_UNIQUE` (`LanguageID` ASC));
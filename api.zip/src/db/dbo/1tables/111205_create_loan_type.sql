-- Request from LamVT
-- Add loan type
CREATE TABLE IF NOT EXISTS `loan_type` (
    `LoanTypeId` INT(11) NOT NULL AUTO_INCREMENT,
    `LoanType` VARCHAR(40),
    PRIMARY KEY (`LoanTypeId`)
);



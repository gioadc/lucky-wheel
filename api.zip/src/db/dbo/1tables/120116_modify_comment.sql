ALTER TABLE `comment` CHANGE COLUMN `IsPublic` `IsPrivate` BIT(1) NOT NULL DEFAULT b'0' ;

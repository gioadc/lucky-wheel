CREATE TABLE IF NOT EXISTS `training_learning_path` (
	`LPID` INT(11) NOT NULL AUTO_INCREMENT,
    `LPName` VARCHAR(50) NOT NULL,
	`Description` VARCHAR(150) NULL,
    `Published` BIT NULL,
    `CreatedDate` DATETIME NULL,
	`CreatedBy` INT NULL,
    PRIMARY KEY (`LPID`),
	KEY `createdby_training_learning_path_idx` (`CreatedBy`),
	CONSTRAINT `createdby_training_learning_path` FOREIGN KEY (`CreatedBy`) REFERENCES `users` (`UsersId`) ON DELETE NO ACTION ON UPDATE NO ACTION
);
CREATE TABLE IF NOT EXISTS `sec_questions`(
	ChalId INT(11) ,
	Question VARCHAR(100) NULL,
	Example VARCHAR(25) NULL,
    PRIMARY KEY(`ChalId`)
);

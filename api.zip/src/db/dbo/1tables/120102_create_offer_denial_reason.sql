CREATE TABLE IF NOT EXISTS `offer_denial_reason` (
	`DenialReasonID` INT(11) NOT NULL AUTO_INCREMENT,
    `DenialReason` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`DenialReasonID`)
);
ALTER TABLE `broker_detail`
CHANGE COLUMN `SpecialInstruction1` `SpecialInstruction1` VARCHAR(250) NULL DEFAULT NULL;

ALTER TABLE `broker_detail` 
CHANGE COLUMN `SpecialInstruction2` `SpecialInstruction2` VARCHAR(250) NULL DEFAULT NULL;

ALTER TABLE `broker_detail` 
CHANGE COLUMN `SpecialInstruction3` `SpecialInstruction3` VARCHAR(250) NULL DEFAULT NULL;

ALTER TABLE `broker_detail` 
CHANGE COLUMN `SpecialInstruction4` `SpecialInstruction4` VARCHAR(250) NULL DEFAULT NULL;

ALTER TABLE `broker_detail`
CHANGE COLUMN `SpecialInstruction5` `SpecialInstruction5` VARCHAR(250) NULL DEFAULT NULL;

ALTER TABLE `broker_detail`
CHANGE COLUMN `CCInv` `CCInv` VARCHAR(100) NULL DEFAULT NULL;

ALTER TABLE `broker_detail` 
ADD COLUMN `SpecialInstruction6` VARCHAR(250) NULL AFTER `SpecialInstruction5`,
ADD COLUMN `SpecialInstruction7` VARCHAR(250) NULL AFTER `SpecialInstruction6`,
ADD COLUMN `SpecialInstruction8` VARCHAR(250) NULL AFTER `SpecialInstruction7`,
ADD COLUMN `SpecialInstruction9` VARCHAR(250) NULL AFTER `SpecialInstruction8`,
ADD COLUMN `SpecialInstruction10` VARCHAR(250) NULL AFTER `SpecialInstruction9`;



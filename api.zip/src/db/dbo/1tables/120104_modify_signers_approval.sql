ALTER TABLE `signers_approval` 
	ADD COLUMN `SignerId` INT(11) NULL AFTER `MgrReason`,
	ADD INDEX `signerId_approval_idx` (`SignerId` ASC);
    
ALTER TABLE `signers_approval` 
	ADD CONSTRAINT `signerId_approval` FOREIGN KEY (`SignerId`)  
		REFERENCES `signer` (`SignerId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

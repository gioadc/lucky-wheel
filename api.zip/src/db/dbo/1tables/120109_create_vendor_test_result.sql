CREATE TABLE IF NOT EXISTS `vendor_test_result` (
	`ResultId` INT(11) NOT NULL AUTO_INCREMENT,
	`VendorId` INT(11) NOT NULL,
    `ProgramId` INT(11) NULL,
    `TestId` INT(11) NOT NULL,
    `CorrectAnswerNum` SMALLINT NULL,
	`TestedNum` TINYINT NULL,
    `LastTesting` DATETIME NULL,
    `TestingTime` TINYINT NULL,
    PRIMARY KEY (`ResultId`),
	KEY `vendorid_vendor_test_result_idx` (`VendorId`),
	CONSTRAINT `vendorid_vendor_test_result` FOREIGN KEY (`VendorId`) REFERENCES `signer` (`SignerId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
    KEY `programid_vendor_test_result_idx` (`ProgramId`),
	CONSTRAINT `programid_vendor_test_result` FOREIGN KEY (`ProgramId`) REFERENCES `training_programs` (`ProgramId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
	KEY `testid_vendor_test_result_idx` (`TestId`),
    CONSTRAINT `testid_vendor_test_result` FOREIGN KEY (`TestId`) REFERENCES `test_info` (`TestId`) ON DELETE NO ACTION ON UPDATE NO ACTION
);
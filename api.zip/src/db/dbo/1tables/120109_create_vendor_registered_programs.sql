CREATE TABLE IF NOT EXISTS `vendor_registered_programs` (
	`Id` INT(11) NOT NULL AUTO_INCREMENT,
	`VendorId` INT(11) NOT NULL,
    `ProgramId` INT(11) NOT NULL,
    `Status` TINYINT NULL,
	`RegisteredDate` DATETIME NULL,
    PRIMARY KEY (`Id`),
	KEY `programid_vendor_registered_programs_idx` (`ProgramId`),
	CONSTRAINT `programid_vendor_registered_programs` FOREIGN KEY (`ProgramId`) REFERENCES `training_programs` (`ProgramId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
    KEY `vendorid_vendor_registered_programs_idx` (`VendorId`),
	CONSTRAINT `vendorid_vendor_registered_programs` FOREIGN KEY (`VendorId`) REFERENCES `signer` (`SignerId`) ON DELETE NO ACTION ON UPDATE NO ACTION
);
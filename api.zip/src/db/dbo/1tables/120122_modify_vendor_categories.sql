DELIMITER $$
CREATE PROCEDURE `alter_table_vendor_category` ()
BEGIN
    IF NOT EXISTS (SELECT 1 
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE
						TABLE_SCHEMA = 'tce_dev' AND
						TABLE_NAME = 'vendor_categories' AND 
                            COLUMN_NAME = 'Color') THEN
		ALTER TABLE `vendor_categories` ADD COLUMN `Color` VARCHAR(6);
	END IF;
END$$

DELIMITER ;

call alter_table_vendor_category();

DROP PROCEDURE IF EXISTS `alter_table_vendor_category`;
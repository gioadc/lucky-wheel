CREATE TABLE IF NOT EXISTS `broker_training_req` (
	`Id` INT(11) NOT NULL AUTO_INCREMENT,
    `BrokerId` INT(11) NOT NULL,
    `ProgramId` INT(11) NOT NULL,
    PRIMARY KEY (`Id`),
	KEY `brokerid_broker_idx` (`BrokerId`),
    CONSTRAINT `BrokerId_broker_training_req` FOREIGN KEY (`BrokerId`) REFERENCES `broker` (`BrokerId`) ON DELETE NO ACTION ON UPDATE NO ACTION
);
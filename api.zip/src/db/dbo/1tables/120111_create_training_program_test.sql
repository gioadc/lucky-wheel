use tce_dev;
CREATE TABLE IF NOT EXISTS `training_program_test` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ProgramId` int(11) NULL,
  `TestId` int(11) NULL,
  PRIMARY KEY (`Id`),
  KEY `programId_training_program_test_idx` (`ProgramId`),
  CONSTRAINT `programId_training_program_test` FOREIGN KEY (`ProgramId`) REFERENCES `training_programs` (`ProgramId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  KEY `testId_training_program_test_idx` (`TestId`),
  CONSTRAINT `testId_training_program_test` FOREIGN KEY (`TestId`) REFERENCES `test_info` (`TestId`) ON DELETE NO ACTION ON UPDATE NO ACTION
)

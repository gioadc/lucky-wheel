ALTER TABLE `order_progress_log` ADD COLUMN `IsPrivate` BIT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS `customer_training_req` (
	`Id` INT(11) NOT NULL AUTO_INCREMENT,
    `CustomerId` INT(11) NOT NULL,
    `ProgramId` INT(11) NOT NULL,
    PRIMARY KEY (`Id`),
	KEY `customerid_customer_idx` (`CustomerId`),
    CONSTRAINT `customerid_customer_training_req` FOREIGN KEY (`CustomerId`) REFERENCES `customers` (`CustomerId`) ON DELETE NO ACTION ON UPDATE NO ACTION
);
CREATE TABLE IF NOT EXISTS `signer_training` (
  `TraningId` int(11) NOT NULL,
  `SignerId` int(11) DEFAULT NULL,
  `CompleteDate` datetime DEFAULT NULL,
  `TenantID` int(11) NOT NULL,
  `CourseId` int(11) DEFAULT NULL,
  PRIMARY KEY (`TraningId`),
  KEY `teanantId_signer_training_idx` (`TenantID`),
  KEY `courseId_signer_training_idx` (`CourseId`),
  CONSTRAINT `Signer_traning` FOREIGN KEY (`TraningId`) REFERENCES `signer` (`SignerId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `courseId_signer_training` FOREIGN KEY (`CourseId`) REFERENCES `traning_courses` (`CourseId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `teanantId_signer_training` FOREIGN KEY (`TenantID`) REFERENCES `tenant` (`TenantId`) ON DELETE NO ACTION ON UPDATE NO ACTION
)



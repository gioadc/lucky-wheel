use tce_dev;

CREATE TABLE IF NOT EXISTS `system_settings` (
	Id INT(11) NOT NULL AUTO_INCREMENT,
    TwilioId VARCHAR(100) NULL,
    TwilioToken VARCHAR(100) NULL,
    TwilioFrom VARCHAR(15) NULL,
    PRIMARY KEY (`Id`)
);

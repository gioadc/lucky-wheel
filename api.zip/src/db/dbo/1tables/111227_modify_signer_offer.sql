ALTER TABLE `signer_offer` CHANGE COLUMN `DenialReason` `DenialReasonID` INT(11) NULL;
ALTER TABLE `signer_offer` ADD COLUMN `AltTime` DATETIME NULL;
ALTER TABLE `signer_offer` ADD COLUMN `NLDoMobileSigning` BIT NULL;
ALTER TABLE `signer_offer` ADD COLUMN `ReturnTime` DATETIME NULL;
ALTER TABLE `signer_offer` ADD COLUMN `NotDoProduct` VARCHAR(100);
ALTER TABLE `signer_offer` ADD COLUMN `AdditionalInfo` VARCHAR(250);
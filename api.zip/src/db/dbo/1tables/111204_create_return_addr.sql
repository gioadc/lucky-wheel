-- Request from HoangNM
-- Add table return address
CREATE TABLE IF NOT EXISTS `return_addr` (
    `RaId` INT(11) NOT NULL AUTO_INCREMENT,
    `BrokerId` INT(11),
    `ReturnAddr` VARCHAR(500),
    `DefaultAddr` VARCHAR(1),
    `BranchId` INT(11),
    PRIMARY KEY (`RaId`)
)
CREATE TABLE IF NOT EXISTS `loan_type_sub` (
	`SubTypeId` INT(11) NOT NULL AUTO_INCREMENT,
    `SubLoanType` VARCHAR(100) NOT NULL,
    `LoanTypeId` INT(11) NOT NULL,
    PRIMARY KEY (`SubTypeId`),
    KEY `loantypeid_sub_loan_type_idx` (`LoanTypeId`),
	CONSTRAINT `loantypeid_sub_loan_type` FOREIGN KEY (`LoanTypeId`) REFERENCES `loan_type` (`LoanTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
);
ALTER TABLE `order_docs` ADD COLUMN `RejectReason` VARCHAR(150) NULL;

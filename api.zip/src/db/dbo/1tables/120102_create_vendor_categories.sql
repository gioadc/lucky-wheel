CREATE TABLE IF NOT EXISTS `vendor_categories` (
	CatId INT(11) NOT NULL AUTO_INCREMENT,
    CatName VARCHAR(50) NOT NULL,
    MinOrder INT NULL,
    MinRating INT NULL,
    MinRMOrder INT NULL,
    PRIMARY KEY (`CatId`)
);

ALTER TABLE `order_docs` DROP FOREIGN KEY `BrokerId_order_docs`;
ALTER TABLE `order_docs` DROP COLUMN `BrokerId`;

ALTER TABLE `order_docs` 
ADD COLUMN `UserId` INT(11) NULL,
ADD INDEX `userid_order_docs_idx` (`UserId` ASC);

ALTER TABLE `order_docs` 
ADD CONSTRAINT `userid_order_docs`
  FOREIGN KEY (`UserId`)
  REFERENCES `users` (`UsersId`)  ON DELETE NO ACTION  ON UPDATE NO ACTION;


ALTER TABLE `order_docs` ADD COLUMN `DocumentType` VARCHAR(1) NULL;
ALTER TABLE `order_docs` ADD COLUMN `Status` VARCHAR(1) NULL;
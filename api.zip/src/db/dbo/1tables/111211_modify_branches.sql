-- Modify table branches
-- add Suite
ALTER TABLE branches ADD COLUMN `Suite` VARCHAR(50) NULL;
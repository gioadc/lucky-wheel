CREATE TABLE IF NOT EXISTS `state` (
    `Code` VARCHAR(2) NOT NULL,
    `Description` VARCHAR(50),
    PRIMARY KEY (`Code`)
)
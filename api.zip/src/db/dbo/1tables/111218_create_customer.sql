CREATE TABLE IF NOT EXISTS `customers` (
    `CustomerId` INT(11) NOT NULL AUTO_INCREMENT,
    `Name` VARCHAR(40),
    `Email` VARCHAR(200),
    `BrokerId` INT(11) NOT NULL,
    PRIMARY KEY (`CustomerId`)
);


CREATE TABLE IF NOT EXISTS `customer_product_type` (
	`Id` INT(11) NOT NULL AUTO_INCREMENT,
    `CustomerId` INT(11) NOT NULL,
    `ProductType` INT(11) NOT NULL,
    PRIMARY KEY (`Id`)
);

ALTER TABLE customer_product_type ADD KEY `customerid_customer_product_type_idx` (`CustomerId`);
ALTER TABLE customer_product_type ADD CONSTRAINT `customerid_customer_product_type` FOREIGN KEY (`CustomerId`) 
	REFERENCES `customers` (`CustomerId`) ON DELETE NO ACTION ON UPDATE NO ACTION;
    
ALTER TABLE customer_product_type ADD KEY `loantype_customer_product_type_idx` (`ProductType`);
ALTER TABLE customer_product_type ADD CONSTRAINT `loantype_customer_product_type` FOREIGN KEY (`ProductType`) 
	REFERENCES `loan_type` (`LoanTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION;
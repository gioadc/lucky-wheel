use tce_dev;
-- Request from LamVT
-- Add loan type
CREATE TABLE IF NOT EXISTS `order_progress_log` (
    `ProgressLogId` INT(11) NOT NULL AUTO_INCREMENT,
    `OrderId` INT(11) NOT NULL,
    `Activity` VARCHAR(1500) NULL,
    `UsersId` INT(11) NULL,
    `DateLog` DATETIME NULL,
    PRIMARY KEY (`ProgressLogId`),
    KEY `OrderId_order_progress_log_idx` (`OrderId`),
    KEY `UsersId_order_progress_log_idx` (`UsersId`),
	CONSTRAINT `ordersId_order_progress_log` FOREIGN KEY (`OrderId`) REFERENCES `order` (`OrderId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `usersId_order_progress_log` FOREIGN KEY (`UsersId`) REFERENCES `users` (`UsersId`) ON DELETE NO ACTION ON UPDATE NO ACTION
);
DROP TRIGGER IF EXISTS `trNewBroker`;

delimiter |

CREATE TRIGGER trNewBroker AFTER INSERT ON `broker`
FOR EACH ROW
BEGIN
    INSERT INTO `broker_detail` (BrokerId, TenantId)
    VALUES (NEW.BrokerID, NEW.TenantId);
END;
|

delimiter ;
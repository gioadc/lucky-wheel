DROP TRIGGER IF EXISTS `trNewOrder`;

delimiter |

CREATE TRIGGER trNewOrder AFTER INSERT ON `order`
FOR EACH ROW
BEGIN
	-- add 3 record by default
    INSERT INTO `order_special_instructions` (OrderId)
    VALUES (NEW.OrderID);
END;
|

delimiter ;
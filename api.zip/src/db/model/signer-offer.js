import Bookshelf from "../database";

const SignerOffer = Bookshelf.Model.extend({
    tableName: "signer_offer"
});

export default SignerOffer;
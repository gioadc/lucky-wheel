import Bookshelf from "../database";

const Payment = Bookshelf.Model.extend({
    tableName: "payment"
});

export default Payment;
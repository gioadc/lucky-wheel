import Bookshelf from "../database";

const Signer = Bookshelf.Model.extend({
    tableName: "signer"
});

export default Signer;
import Bookshelf from "../database";

const Client = Bookshelf.Model.extend({
    tableName: "broker"
});

export default Client;
import Bookshelf from "../database";

const LoanType = Bookshelf.Model.extend({
    tableName: "loan_type"
});

export default LoanType;
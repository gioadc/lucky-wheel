import Bookshelf from "../database";

const SecAnswers = Bookshelf.Model.extend({
    tableName: "sec_answers"
});

export default SecAnswers;
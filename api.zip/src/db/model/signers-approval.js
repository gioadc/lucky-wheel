import Bookshelf from "../database";

const SignersApproval = Bookshelf.Model.extend({
    tableName: "signers_approval"
});

export default SignersApproval;
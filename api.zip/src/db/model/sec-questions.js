import Bookshelf from "../database";

const SecQuestions = Bookshelf.Model.extend({
    tableName: "sec_questions"
});

export default SecQuestions;
import Bookshelf from "../database";

const IssueReporting = Bookshelf.Model.extend({
    tableName: "order_problem"
});

export default IssueReporting;
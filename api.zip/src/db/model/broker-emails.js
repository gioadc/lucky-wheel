import Bookshelf from "../database";

const BrokerEmails = Bookshelf.Model.extend({
    tableName: "broker_emails"
});

export default BrokerEmails;
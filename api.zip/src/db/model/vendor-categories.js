import Bookshelf from "../database";

const VendorCategories = Bookshelf.Model.extend({
    tableName: "vendor_categories"
});

export default VendorCategories;
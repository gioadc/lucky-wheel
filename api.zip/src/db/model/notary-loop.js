import Bookshelf from "../database";

const NotaryLoop = Bookshelf.Model.extend({
    tableName: "notaryloop"
});

export default NotaryLoop;
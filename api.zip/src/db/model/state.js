import Bookshelf from "../database";

const State = Bookshelf.Model.extend({
    tableName: "state"
});

export default State;
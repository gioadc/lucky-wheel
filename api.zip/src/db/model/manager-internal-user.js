import Bookshelf from "../database";

const ManagerInternalUser = Bookshelf.Model.extend({
    tableName: "employees"
});

export default ManagerInternalUser;
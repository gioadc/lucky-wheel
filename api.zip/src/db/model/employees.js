import Bookshelf from "../database";

const Employees = Bookshelf.Model.extend({
    tableName: "employees"
});

export default Employees;
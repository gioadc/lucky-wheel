import Bookshelf from "../database";

const Branch = Bookshelf.Model.extend({
    tableName: "branches"
});

export default Branch;
import Bookshelf from "../database";

const Fee = Bookshelf.Model.extend({
    tableName: "fee_description"
});

export default Fee;
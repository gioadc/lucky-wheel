import Bookshelf from "../database";

const SalesReps = Bookshelf.Model.extend({
    tableName: "sales_reps"
});

export default SalesReps;
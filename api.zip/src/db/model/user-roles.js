import Bookshelf from "../database";

const UserRole = Bookshelf.Model.extend({
    tableName: "user_roles"
});

export default UserRole;

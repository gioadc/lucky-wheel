import Bookshelf from "../database";

const OrderProgressLog = Bookshelf.Model.extend({
    tableName: "order_progress_log"
});

export default OrderProgressLog;
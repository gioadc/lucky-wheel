import Bookshelf from "../database";

const OrderProblem = Bookshelf.Model.extend({
    tableName: "order_problem"
});

export default OrderProblem;
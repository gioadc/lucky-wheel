import Bookshelf from "../database";

const CustomerDoNotUse = Bookshelf.Model.extend({
    tableName: "customer_donotuse"
});

export default CustomerDoNotUse;
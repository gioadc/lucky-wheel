import Bookshelf from "../database";

const Language = Bookshelf.Model.extend({
    tableName: "language"
});

export default Language;
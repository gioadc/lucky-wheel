import Bookshelf from "../database";

const TrainingProgramTest = Bookshelf.Model.extend({
    tableName: "training_program_test"
});

export default TrainingProgramTest;
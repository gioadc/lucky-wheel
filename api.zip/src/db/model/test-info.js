import Bookshelf from "../database";

const TestInfo = Bookshelf.Model.extend({
    tableName: "test_info"
});

export default TestInfo;
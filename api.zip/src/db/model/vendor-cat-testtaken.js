import Bookshelf from "../database";

const VendorCatTestTaken = Bookshelf.Model.extend({
    tableName: "vendor_cat_testtaken"
});

export default VendorCatTestTaken;
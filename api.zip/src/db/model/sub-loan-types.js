import Bookshelf from "../database";

const SubLoanTypes = Bookshelf.Model.extend({
    tableName: "loan_type_sub"
});

export default SubLoanTypes;
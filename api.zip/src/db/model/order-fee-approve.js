import Bookshelf from "../database";

const OrderFeeApprove = Bookshelf.Model.extend({
    tableName: "order_fee_approve"
});

export default OrderFeeApprove;
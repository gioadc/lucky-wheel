import Bookshelf from "../database";

const ReturnAddress = Bookshelf.Model.extend({
    tableName: "return_addr"
});

export default ReturnAddress;
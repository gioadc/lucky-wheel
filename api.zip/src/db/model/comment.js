import Bookshelf from "../database";

const Comment = Bookshelf.Model.extend({
    tableName: "comment"
});

export default Comment;
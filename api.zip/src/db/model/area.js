import Bookshelf from "../database";

const Area = Bookshelf.Model.extend({
    tableName: "area"
});

export default Area;
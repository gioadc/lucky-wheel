import Bookshelf from "../database";

const OrderSpecificIns = Bookshelf.Model.extend({
    tableName: "order_special_instructions"
});

export default OrderSpecificIns;
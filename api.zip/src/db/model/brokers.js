import Bookshelf from "../database";

const Broker = Bookshelf.Model.extend({
    tableName: "broker"
});

export default Broker;
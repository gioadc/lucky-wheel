import Bookshelf from "../database";

const CustomerProductType = Bookshelf.Model.extend({
    tableName: "customer_product_type"
});

export default CustomerProductType;
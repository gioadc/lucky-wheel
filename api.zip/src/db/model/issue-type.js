import Bookshelf from "../database";

const IssueType = Bookshelf.Model.extend({
    tableName: "problem_types"
});

export default IssueType;
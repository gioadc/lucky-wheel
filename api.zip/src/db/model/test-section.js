import Bookshelf from "../database";

const TestSection = Bookshelf.Model.extend({
    tableName: "test_sections"
});

export default TestSection;
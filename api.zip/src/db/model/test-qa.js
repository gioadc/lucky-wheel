import Bookshelf from "../database";

const TestQa = Bookshelf.Model.extend({
    tableName: "test_qa"
});

export default TestQa;
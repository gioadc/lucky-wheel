import Bookshelf from "../database";
import { bufferToBoolean, isBuffer } from "../../helper/common-helper";

const RolePermission = Bookshelf.Model.extend({
    tableName: "role_permission"
});

export const mapRole = (roleId, onSuccess, onFail) => {
    RolePermission.where({ RoleId: roleId })
        .fetch()
        .then((roles) => {
            if (roles === null) {
                return onFail({
                    message: `Role ID ${roleId} does not exist`
                });
            }

            const role = roles.attributes;
            const mappedRole = {
                roleName: role.RoleName,
                type: role.Type,
                permissions: []
            };

            Object.keys(role).forEach((item) => {
                const value = role[item];

                if (isBuffer(value) && bufferToBoolean(value)) {
                    mappedRole.permissions.push(item);
                }
            });

            return onSuccess(mappedRole);
        }, (err) => onFail(err));
};

export default RolePermission;
import Bookshelf from "../database";

const OrderDocs = Bookshelf.Model.extend({
    tableName: "order_docs"
});

export default OrderDocs;
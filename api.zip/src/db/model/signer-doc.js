import Bookshelf from "../database";

const SignerDoc = Bookshelf.Model.extend({
    tableName: "signer_docs"
});

export default SignerDoc;
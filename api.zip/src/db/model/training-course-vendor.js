import Bookshelf from "../database";

const TrainingCourseVendor = Bookshelf.Model.extend({
    tableName: "training_course_vendor"
});

export default TrainingCourseVendor;
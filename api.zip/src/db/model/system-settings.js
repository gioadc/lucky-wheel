import Bookshelf from "../database";

const SystemSettings = Bookshelf.Model.extend({
    tableName: "system_settings"
});

export default SystemSettings;
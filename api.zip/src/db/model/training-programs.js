import Bookshelf from "../database";

const TrainingPrograms = Bookshelf.Model.extend({
    tableName: "training_programs"
});

export default TrainingPrograms;
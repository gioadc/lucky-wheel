import Bookshelf from "../database";

const Agent = Bookshelf.Model.extend({
    tableName: "agent"
});

export default Agent;
import Bookshelf from "../database";

const CustomerTrainingReq = Bookshelf.Model.extend({
    tableName: "customer_training_req"
});

export default CustomerTrainingReq;
import Bookshelf from "../database";

const TrainingCourses = Bookshelf.Model.extend({
    tableName: "training_courses"
});

export default TrainingCourses;
import Bookshelf from "../database";

const BrokerFee = Bookshelf.Model.extend({
    tableName: "broker_fee"
});

export default BrokerFee;
import Bookshelf from "../database";

const CustomerSubProductType = Bookshelf.Model.extend({
    tableName: "customer_subproduct_type"
});

export default CustomerSubProductType;
import Bookshelf from "../database";

const SignerDocType = Bookshelf.Model.extend({
    tableName: "signer_doctypes"
});

export default SignerDocType;
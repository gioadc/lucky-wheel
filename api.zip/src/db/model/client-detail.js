import Bookshelf from "../database";

const ClientDetail = Bookshelf.Model.extend({
    tableName: "broker_detail"
});

export default ClientDetail;
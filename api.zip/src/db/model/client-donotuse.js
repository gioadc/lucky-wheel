import Bookshelf from "../database";

const ClientDonotuse = Bookshelf.Model.extend({
    tableName: "broker_donotuse"
});

export default ClientDonotuse;
import Bookshelf from "../database";

const TrainingLPProgram = Bookshelf.Model.extend({
    tableName: "training_lp_programs"
});

export default TrainingLPProgram;
import Bookshelf from "../database";

const Order = Bookshelf.Model.extend({
    tableName: "order"
});

export default Order;
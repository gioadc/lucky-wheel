import Bookshelf from "../database";

const OrderRefund = Bookshelf.Model.extend({
    tableName: "order_refund"
});

export default OrderRefund;
import Bookshelf from "../database";

const OrderLog = Bookshelf.Model.extend({
    tableName: "order_log"
});

export default OrderLog;
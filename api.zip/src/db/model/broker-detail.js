import Bookshelf from "../database";

const BrokerDetail = Bookshelf.Model.extend({
    tableName: "broker_detail"
});

export default BrokerDetail;
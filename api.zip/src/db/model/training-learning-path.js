import Bookshelf from "../database";

const TrainingLearning = Bookshelf.Model.extend({
    tableName: "training_learning_path"
});

export default TrainingLearning;
import Bookshelf from "../database";

const OrderFee = Bookshelf.Model.extend({
    tableName: "order_fee"
});

export default OrderFee;
import Bookshelf from "../database";

const SignerChanges = Bookshelf.Model.extend({
    tableName: "signer_changes"
});

export default SignerChanges;
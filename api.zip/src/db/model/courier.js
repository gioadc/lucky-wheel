import Bookshelf from "../database";

const Courier = Bookshelf.Model.extend({
    tableName: "courier"
});

export default Courier;
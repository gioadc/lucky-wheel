import Bookshelf from "../database";

const Issue = Bookshelf.Model.extend({
    tableName: "order_problem"
});

export default Issue;
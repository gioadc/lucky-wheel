import Bookshelf from "../database";

const TrainingProgramCourses = Bookshelf.Model.extend({
    tableName: "training_program_courses"
});

export default TrainingProgramCourses;
import Bookshelf from "../database";

const Customer = Bookshelf.Model.extend({
    tableName: "customers"
});

export default Customer;
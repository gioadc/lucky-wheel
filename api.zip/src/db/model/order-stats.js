import Bookshelf from "../database";

const OrderStats = Bookshelf.Model.extend({
    tableName: "order_stats"
});

export default OrderStats;
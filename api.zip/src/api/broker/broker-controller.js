import Boom from "boom";
import Bookshelf from "../../db/database";

import Broker from "../../db/model/brokers";
import ClientDetail from "../../db/model/client-detail";

class BrokerController {
    constructor() { }

    getBrokerAddressById(request, reply) {
        const { brokerId } = request.query;

        Bookshelf.knex.raw(`call GetBrokerAddressById(${brokerId})`)
            .then((result) => {
                if (result !== null) {
                    reply({ Location: result[0][0][0] });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        return reply;
    }

    updateBrokerById(request, reply) {
        const broker = request.payload;

        Broker.where({ BrokerID: broker.BrokerID }).save({
            AdditionalContact: broker.AdditionalContact,
            AdditionalContactEmail: broker.AdditionalContactEmail,
            AdditionalContactExt: broker.AdditionalContactExt,
            AdditionalContactPhone: broker.AdditionalContactPhone,
            Address: broker.Address,
            BrokerID: broker.BrokerID,
            City: broker.City,
            Email: broker.Email,
            EmailOpt: broker.EmailOpt,
            Phone: broker.Phone,
            PrimaryContactExt: broker.PrimaryContactExt,
            PrimaryContactFax: broker.PrimaryContactFax,
            PrimaryContactFirst: broker.PrimaryContactFirst,
            PrimaryContactLast: broker.PrimaryContactLast,
            State: broker.State,
            Suite: broker.Suite,
            TextOpt: broker.TextOpt,
            Zip: broker.Zip
        }, { method: "update" }).then((success) => {
            if (success !== null) {
                reply({ isSuccess: true });
            }

            // done updating Broker
            // update/create Broker Detail
            ClientDetail.where({ BrokerId: broker.BrokerID }).fetch().then((result) => {
                if (result !== null) {
                    ClientDetail.where({ BrokerId: broker.BrokerID }).save(
                        {
                            Cell: broker.Cell,
                            Website: broker.Website
                        },
                        { method: "update" }).then(() => {
                            //success
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                } else {
                    new ClientDetail({
                        BrokerId: broker.BrokerID,
                        TenantId: 1,
                        Cell: broker.Cell,
                        Website: broker.Website
                    }).save(null,
                        { method: "insert" }).then((response) => {
                            if (response !== null) {
                                reply({
                                    isSuccess: true
                                });
                            }
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getBrokerInfoDefault(request, reply) {
        const { brokerId } = request.query;

        Bookshelf.knex.raw(`call GetPrimaryContactInformation(${brokerId})`)
            .then((result) => {
                if (result !== null) {
                    reply(result[0][0][0]);
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        return reply;
    }

    getBrokerById(request, reply) {
        const { brokerId } = request.query;
        Broker.where({ BrokerID: brokerId }).fetch({ columns: ["AdministratorFirst", "AdministratorLast", "Administratorext", "AdministratorEmail"] }).then((result) => {
            if (result !== null) {
                reply(result);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

        return;
    }

    getBrokerAdminById(request, reply) {
        const { brokerId } = request.query;

        const getBranchAdmin = Promise.resolve(
            Broker.where({ BrokerId: brokerId }).fetch({
                columns: [
                    "AdministratorFirst", "AdministratorLast", "AdministratorExt", "AdministratorEmail"
                ]
            })
        );

        const getBranchAdminReturnAddr = Promise.resolve(Bookshelf.knex.raw(`select BranchId, City, DefaultAddr, Department, State, Suite, Zip from return_addr where BrokerId = ${brokerId}`));

        const getAllState = Promise.resolve(Bookshelf.knex.raw(`select Code from state`));

        const promiseData = Promise.all([getBranchAdmin, getBranchAdminReturnAddr, getAllState]);
        promiseData
            .then(values => {
                const data = {};
                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.admin = item;
                                    break;
                                case 1:
                                    data.returnAddr = item[0];
                                    break;
                                case 2:
                                    data.state = item[0];
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        return reply;
    }

    getBrokerBranchById(request, reply) {
        const { brokerId } = request.query;

        const getBranch = Promise.resolve(
            Broker.where({ BrokerId: brokerId }).fetch({
                columns: [
                    "Company", "Phone", "Address", "Suite", "City", "State", "Zip",
                    "AdministratorFirst", "AdministratorLast", "AdministratorExt", "AdministratorEmail",
                    "PrimaryContactFirst", "PrimaryContactLast", "Email", "PrimaryContactExt", "PrimaryContactFax",
                    "DefaultCourierID", "DefaultCourierAcnt"
                ]
            })
        );

        const getReturnAddr = Promise.resolve(Bookshelf.knex.raw(`select * from return_addr where BrokerId = ${brokerId}`));

        const getCcEmail = Promise.resolve(Bookshelf.knex.raw(`select * from broker_emails where BrokerId = ${brokerId}`));

        const getAllState = Promise.resolve(Bookshelf.knex.raw(`select Code from state`));

        const promiseData = Promise.all([getBranch, getReturnAddr, getCcEmail, getAllState]);
        promiseData
            .then(values => {
                const data = {};
                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.branch = item;
                                    break;
                                case 1:
                                    data.returnAddr = item[0];
                                    break;
                                case 2:
                                    data.ccEmail = item[0];
                                    break;
                                case 3:
                                    data.state = item[0];
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        return reply;
    }

}

export default new BrokerController();
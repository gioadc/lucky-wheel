import BrokerController from "./broker-controller";

const routes = [
{
    path: "/broker/getBrokerAddressById",
    method: "GET",
    config: { auth: false },
    handler: BrokerController.getBrokerAddressById
},
{
    path: "/broker/updateBrokerById",
    method: "PUT",
    config: { auth: false },
    handler: BrokerController.updateBrokerById
},
{
    path: "/broker/getBrokerById",
    method: "GET",
    config: { auth: false },
    handler: BrokerController.getBrokerById
},
{
    path: "/broker/getBrokerAdminById",
    method: "GET",
    config: { auth: false },
    handler: BrokerController.getBrokerAdminById
},
{
    path: "/broker/getBrokerBranchById",
    method: "GET",
    config: { auth: false },
    handler: BrokerController.getBrokerBranchById
},
{
    path: "/broker/getBrokerInfoDefault",
    method: "GET",
    config: { auth: false },
    handler: BrokerController.getBrokerInfoDefault
}];

export default routes;
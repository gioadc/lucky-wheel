import VendorClassificationsSettingController from "./vendor-classifications-setting-controller";

const routes = [
    {
        path: "/vendor-classifications/getVendorClassificationsSetting",
        method: "GET",
        config: { auth: false },
        handler: VendorClassificationsSettingController.getVendorClassifications
    },
    {
        path: "/vendor-classifications/addVendorCategoryClassifications",
        method: "POST",
        config: { auth: false },
        handler: VendorClassificationsSettingController.addVendorCategoryClassifications
    },
    {
        path: "/vendor-classifications/deleteVendorCategory",
        method: "DELETE",
        config: { auth: false },
        handler: VendorClassificationsSettingController.deleteVendorCategory
    },
    {
        path: "/vendor-classifications/updateVendorCategory",
        method: "POST",
        config: { auth: false },
        handler: VendorClassificationsSettingController.updateVendorCategory
    },
    {
        path: "/vendor-classifications/updateVendorClassifications",
        method: "POST",
        config: { auth: false },
        handler: VendorClassificationsSettingController.updateVendorClassifications
    }
];

export default routes;
import Bookshelf from "../../db/database";
import VendorCategories from "../../db/model/vendor-categories";
import Boom from "boom";


class VendorClassificationsSettingController {
    constructor() { }

    getVendorClassifications(request, reply) {
        const catSql = "select * From vendor_categories ORDER BY CatId";
        const testSql = `Select v.CatId, t.TestId, t.TestName From vendor_categories AS v 
                            INNER JOIN vendor_cat_testtaken AS vt ON v.CatId = vt.CatId 
                            INNER JOIN test_info AS t ON vt.TestId = t.TestId;`;
        const allTestSql = "Select TestId, TestName From test_info ORDER BY TestId";

        const queue = [];

        queue.push(Promise.resolve(Bookshelf.knex.raw(catSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(testSql)));
        queue.push(Promise.resolve(Bookshelf.knex.raw(allTestSql)));

        Promise.all(queue)
            .then((result) => {
                if (result !== null) {
                    const categories = result[0][0];
                    const testTaken = result[1][0];
                    const tests = result[2][0];

                    reply({ categories, testTaken, tests });
                }

                return;
            }).catch((error) => {
                reply(Boom.badRequest(error));

            });
    }

    addVendorCategoryClassifications(request, reply) {
        const { catName, catColor } = request.payload;

        new VendorCategories().save({
            CatName: catName,
            Color: catColor,
            MinOrder: 50,
            MinRating: 1,
            MinRMOrder: 50

        },
            { method: "insert" }).then((result) => {
                if (result !== null) {
                    reply({
                        catId: result.id,
                        isSuccess: true
                    });

                }
            }).catch((error) => {
                reply(Boom.badRequest(error));

            });
    }

    deleteVendorCategory(request, reply) {
        const { catId } = request.query;

        VendorCategories.where({ catId }).destroy({ require: true }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    updateVendorCategory(request, reply) {
        const vendorCategory = request.payload;

        VendorCategories.where({ CatId: vendorCategory.catId }).save(vendorCategory, { method: "update" }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return;
    }

    updateVendorClassifications(request, reply) {
        const { vendorCat, testTaken } = request.payload;
        const queue = [];

        if (vendorCat !== undefined && vendorCat.length > 0) {
            vendorCat.map((catListUpdate) => {
                queue.push(Promise.resolve(VendorCategories.where({ CatId: catListUpdate.CatId }).save(catListUpdate, { method: "update" })));
            });
        }

        if (testTaken !== undefined && testTaken.length > 0) {
            // delete
            vendorCat.map((cat) => {
                let deleteSql = "";
                let testIdStr = "";
                testTaken.map((test) => {
                    if (test.CatId === cat.CatId) {
                        if (testIdStr !== "") {
                            testIdStr = `${testIdStr}, ${test.TestId}`;
                        } else {
                            testIdStr = `(${test.TestId}`;
                        }
                    }
                });

                if (testIdStr !== "") {
                    deleteSql = `DELETE FROM vendor_cat_testtaken WHERE CatId=${cat.CatId} AND TestId NOT IN ${testIdStr})`;
                } else {
                    deleteSql = `DELETE FROM vendor_cat_testtaken WHERE CatId=${cat.CatId}`;
                }

                queue.push(Promise.resolve(Bookshelf.knex.raw(deleteSql)));
            });


            // add
            testTaken.map((test) => {
                const insertSql = `INSERT INTO vendor_cat_testtaken (CatId, TestId) VALUES (${test.CatId}, ${test.TestId}) ON DUPLICATE KEY UPDATE CatId=${test.CatId}, TestId=${test.TestId};`;

                queue.push(Promise.resolve(Bookshelf.knex.raw(insertSql)));
            });

        }

        Promise.all(queue).then(() => {
            reply({ isSuccess: true });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

        return reply;

    }

}

export default new VendorClassificationsSettingController();
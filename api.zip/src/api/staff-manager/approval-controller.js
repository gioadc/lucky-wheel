import Boom from "boom";
import Bookshelf from "../../db/database";

class ApprovalController {
    getNumberApprovals(request, reply) {
        Bookshelf.knex.raw("call GetStaffManagerApprovalData();").then((result) => {
            if (result !== null) {
                reply({isSuccess: true, numberFees: result[0][0][0].numberFees, numberVendors: result[0][1][0].numberVendors});
                return;
            }

            reply({isSuccess: false});
            return;
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}

export default new ApprovalController();
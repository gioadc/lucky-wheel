import ApprovalController from "./approval-controller";
const routes = [
    {
        path: "/staff-manager/getNumberApprovals",
        method: "GET",
        config: { auth: false },
        handler: ApprovalController.getNumberApprovals
    }
];

export default routes;
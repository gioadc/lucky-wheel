import SignerDoc from "../../db/model/signer-doc";
import Boom from "boom";
import Bookshelf from "../../db/database";
import moment from "moment";
import { isBuffer, bufferToBoolean } from "../../helper/common-helper";
import appConfig from "../../config/config";
import fs from "fs";

class SignerDocController {
	constructor() { }

	downloadSignerDocument(request, reply) {
		const { docId } = request.query;
		SignerDoc.where({ docId }).fetch({ columns: ["signerId", "docName"] }).then((signerDoc) => {
			const signerId = signerDoc.get("signerId");
			const docName = signerDoc.get("docName");
			const fileName = `TEMP-${signerId}_${docName}`;
			const filePath = `${appConfig.file.serverPath}/notary-docs-temp/${fileName}`;
			fs.readFile(filePath, (err, data) => {
				if (err) throw err;
				return reply(data)
					.header("content-disposition", `attachment; filename=${fileName}`);
			});
		}).catch((error) => reply(Boom.badRequest(error)));
	}

	uploadSignerDocument(request, reply) {
		const payload = request.payload;
		const file = payload.file;
		const signerDoc = {
			number: payload.number,
			docName: payload.docName,
			issuedDate: payload.issuedDate,
			expireDate: payload.expireDate,
			signerId: payload.signerId,
			docTypeId: payload.docTypeId,
			state: payload.state,
			referencePhoneNumber: payload.referencePhoneNumber,
			referenceName: payload.referenceName
		};
		for (const key in signerDoc) {
			if (signerDoc[key] === "null" || signerDoc[key] === "") {
				signerDoc[key] = null;
			}
		}
		const fileName = `TEMP-${signerDoc.signerId}_${signerDoc.docName}`;
		const filePath = `${appConfig.file.serverPath}/notary-docs-temp/${fileName}`;
		const insertSignerDoc = () => {
			new SignerDoc(signerDoc).save({ uploadDate: moment().format("YYYY-MM-DD HH:mm:ss") }, { method: "insert" }).then(() => {
				if (file) {
					const fileStream = fs.createWriteStream(filePath);
					file.pipe(fileStream);
					file.on("end", () => {
						reply({ isSuccess: true });
					});
				} else {
					reply({ isSuccess: true });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		};
		SignerDoc.where({ signerId: signerDoc.signerId, state: signerDoc.state, docTypeId: signerDoc.docTypeId }).count("*").then(count => {
			if (count > 0) {
				SignerDoc.where({ state: signerDoc.state, docTypeId: signerDoc.docTypeId }).destroy().then(() => {
					insertSignerDoc();
				});
			} else {
				insertSignerDoc();
			}
		}).catch(error => reply(Boom.badRequest(error)));
	}

	checkSignerDocExisting(request, reply) {
		const { signerId, docTypeId, state } = request.query;
		SignerDoc.where({ signerId, state, docTypeId }).fetch({ columns: ["expireDate"] }).then(model => {
			if (model !== null) {
				const expireDate = model.get("expireDate");
				reply({ isExist: expireDate === null || moment(expireDate) > moment() });
			} else {
				reply({ isExist: false });
			}
		}).catch(error => reply(Boom.badRequest(error)));
	}

	getSignerDocBySignerId(request, reply) {
		const { signerId } = request.query;
		const rawSql = `SELECT sdt.docType, sd.referencePhoneNumber, sd.referenceName, sd.docId, sd.number, sd.issuedDate,
		sd.state, sd.expireDate, sd.docName, sd.docTypeId,
		sd.approved, sd.rejected, sd.rejectReason
		FROM signer_docs sd
		JOIN signer_doctypes sdt on sd.docTypeId = sdt.docTypeId WHERE sd.signerId = ${signerId} `;
		Bookshelf.knex.raw(rawSql).then(result => {
			const signDocs = result[0];
			signDocs.map(signDoc => {
				Object.keys(signDoc).forEach((key) => {
					const value = signDoc[key];
					if (isBuffer(value)) {
						signDoc[key] = bufferToBoolean(value);
					}
				});
				return signDoc;
			});
			reply(signDocs);
		}).catch(error => reply(Boom.badRequest(error)));
	}
}

export default new SignerDocController();
import SignerDocController from "./signer-doc-controller";

const routes = [{
    path: "/signerDoc/uploadSignerDocument",
    method: "POST",
    config: {
        auth: false, payload: {
            output: "stream",
            allow: "multipart/form-data"
        }
    },
    handler: SignerDocController.uploadSignerDocument
}, {
    path: "/signerDoc/getSignerDocBySignerId",
    method: "GET",
    config: { auth: false },
    handler: SignerDocController.getSignerDocBySignerId
}, {
    path: "/signerDoc/downloadSignerDocument",
    method: "GET",
    config: {
        auth: false
    },
    handler: SignerDocController.downloadSignerDocument
}, {
    path: "/signerDoc/checkSignerDocExisting",
    method: "GET",
    config: {
        auth: false
    },
    handler: SignerDocController.checkSignerDocExisting
}];

export default routes;
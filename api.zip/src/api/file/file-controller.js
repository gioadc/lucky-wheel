import Boom from "boom";
import { uploader, fileOptions } from "../../helper/file-helper";

class FileController {

    async uploadFile (request, reply) {
        try {
            const { file, path } = request.payload;
            const options = Object.assign({}, fileOptions);

            // Check invalid path
            if (path && path.indexOf("../") !== -1) {
                reply(Boom.badRequest("Invalid path"));
            }
            options.path = path;

            // save the file
            const fileDetails = await uploader(file, options);

            // return result
            reply({isSuccess: true, file: fileDetails});

        } catch (err) {
            // error handling
            reply(Boom.badRequest(err.message, err));
        }
    }
}

export default new FileController();
import FileController from "./file-controller";

const routes = [{
    path: "/file/uploadFile",
    method: "POST",
    config: {
        auth: false,
        payload: {
            output: "stream",
            maxBytes: 1024 * 1024 * 50, // max: 50 MB
            allow: "multipart/form-data" // important
        }
    },
    handler: FileController.uploadFile
}];


export default routes;
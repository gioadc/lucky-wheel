import Boom from "boom";
import Bookshelf from "../../db/database";
import Area from "../../db/model/area";
import { handleSingleQuote } from "../../helper/common-helper";

class AreaController {
    getAreas(request, reply) {
        Area.forge().orderBy("Area").fetchAll().then((result) => {
            if (result !== null) {
                reply({ isSuccess: true, areas: result });
                return;
            }

            reply({ isSuccess: false, message: "No record found!" });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return;
    }

    getAreasByKeyword(request, reply) {
        const { searchText, selectedValues, limit } = request.query;

        const selectedValuesStr = selectedValues ? `AND AreaId NOT IN (${selectedValues})` : "";

        const rawSql = `SELECT AreaId, Area, ZipCode, AreaCode FROM area WHERE (AreaId LIKE '%${handleSingleQuote(searchText)}%'
        OR ZipCode LIkE '%${handleSingleQuote(searchText)}%' OR Area LIKE '%${handleSingleQuote(searchText)}%') ${selectedValuesStr} ORDER BY Area LIMIT ${limit};`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({ isSuccess: true, sources: result[0] });
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    getStateByZipCode(request, reply) {
        const { zipCode } = request.query;
        Area.where({ ZipCode: zipCode }).fetchAll({ columns: ["StateCode"] }).then((result) => {
            if (result !== null) {
                reply(result);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
        return;
    }

}

export default new AreaController();
import AreaController from "./area-controller";
const routes = [
    {
        path: "/area/getAreas",
        method: "GET",
        config: { auth: false },
        handler: AreaController.getAreas
    },
    {
        path: "/area/getAreasByKeyword",
        method: "GET",
        config: { auth: false },
        handler: AreaController.getAreasByKeyword
    },
    {
        path: "/area/getStateByZipCode",
        method: "GET",
        config: { auth: false },
        handler: AreaController.getStateByZipCode
    }
];

export default routes;
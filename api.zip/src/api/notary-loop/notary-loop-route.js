import NotaryLoopController from "./notary-loop-controller";

const routes = [{
    path: "/notaryloop/addNotaryLoop",
    method: "POST",
    config: { auth: false },
    handler: NotaryLoopController.addNotaryLoop
}];

export default routes;
import DownloadController from "./download-controller";

const routes = [
{
    path: "/download/report/{fileName*}",
    method: "GET",
    config: {auth: false},
    handler: DownloadController.report
}];


export default routes;
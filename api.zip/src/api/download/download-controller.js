const Path = require("path");
const fs = require("fs");

import Boom from "boom";

class DownloadController {
    report(request, reply) {
        const { fileName } = request.params;
        // eslint-disable-next-line
        const reportPath = Path.join(__dirname, `../../content/reports/${fileName}`);

        if (fs.existsSync(reportPath)) {
            // serve file
            reply.file(reportPath);
        } else {
            reply(Boom.badRequest(`File ${reportPath} is not exists.`));
        }
    }
}

export default new DownloadController();
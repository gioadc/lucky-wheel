import TrainingLearningPathController from "./training-learning-path-controller";
const routes = [
    {
        path: "/training-learning-path/getTrainingLearningPath",
        method: "GET",
        config: { auth: false },
        handler: TrainingLearningPathController.getTrainingLearningPath
    },
    {
        path: "/training-learning-path/getTrainingLearningPathByLPName",
        method: "GET",
        config: { auth: false },
        handler: TrainingLearningPathController.getTrainingLearningPathByLPName
    },
    {
        path: "/training-learning-path/deleteTrainingLearningPath",
        method: "DELETE",
        config: { auth: false },
        handler: TrainingLearningPathController.deleteTrainingLearningPath
    },
    {
        path: "/training-learning-path/addLearningPath",
        method: "POST",
        config: { auth: false },
        handler: TrainingLearningPathController.addLearningPath
    },
    {
        path: "/training-learning-path/getRequiredPrograms",
        method: "GET",
        config: { auth: false },
        handler: TrainingLearningPathController.getRequiredProgramOfLearningPath
    },
    {
        path: "/training-learning-path/updateLearningPath",
        method: "POST",
        config: { auth: false },
        handler: TrainingLearningPathController.updateLearningPath
    },
    {
        path: "/training-learning-path/checkExistLearningPath",
        method: "GET",
        config: { auth: false },
        handler: TrainingLearningPathController.checkExistLearningPath
    }
];

export default routes;

import TrainingLearning from "../../db/model/training-learning-path";
import TrainingLPProgram from "../../db/model/training-lp-programs";
import Boom from "boom";
import Bookshelf from "../../db/database";

class TrainingLearningPathController {
	constructor() { }
	getTrainingLearningPathByLPName(request, reply) {
		const {
    		lPName,
			sortColumn,
			sortDirection,
			page,
			itemPerPage
		} = request.query;
		const rawSql = `call GetTrainingLearningPathByLPName(
			${lPName === undefined ? null : `'${lPName}'`},
	        '\`${sortColumn}\`',
	        ${sortDirection},
	        ${page},
	        ${itemPerPage}
		);`;
		Bookshelf.knex.raw(rawSql)
			.then((result) => {
				if (result !== null) {
					reply({ learningPaths: result[0][0], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});

		return reply;
	}

	checkExistLearningPath(request, reply) {
		const { lPName } = request.query;
		TrainingLearning.where({ lPName }).count("*").then((count) => {
			const isExist = count > 0;
			reply({ isExist });
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return;
	}

	getTrainingLearningPath(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage
		} = request.query;
		const rawSql = `call GetAllTrainingLearningPath(
            '\`${sortColumn}\`',
            ${sortDirection},
            ${page},
            ${itemPerPage} 
		);`;
		Bookshelf.knex.raw(rawSql)
			.then((result) => {
				if (result !== null) {
					reply({ learningPaths: result[0][0], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});

		return reply;
	}

	getRequiredProgramOfLearningPath(request, reply) {
		const { lpId } = request.query;
		let requiredPrograms = [];
		if (lpId === undefined || lpId === null) {
			const rawSql = `select p.ProgramId, p.Title, case when l.LPID is null then 0 else 1 end as isMove
			from training_programs as p
			left join training_lp_programs as l ON p.ProgramId = l.ProgramId and l.LPID=${lpId === undefined ? 0 : `${lpId}`}`;
			Bookshelf.knex.raw(rawSql)
				.then((result) => {
					if (result !== null) {
						requiredPrograms = result[0];
					}

					reply(requiredPrograms);
				}).catch((err) => {
					reply(Boom.badRequest(err));
				});
			return;
		}
		const rawSql = `select p.ProgramId, p.Title, case when l.LPID is null then 0 else 1 end as isMove
						from training_programs as p
						left join training_lp_programs as l ON p.ProgramId = l.ProgramId and l.LPID=${lpId === undefined ? 0 : `${lpId}`}`;
		Bookshelf.knex.raw(rawSql)
			.then((result) => {
				if (result !== null) {
					requiredPrograms = result[0];
				}

				reply(requiredPrograms);
			}).catch((err) => {
				reply(Boom.badRequest(err));
			});

		return;
	}

	// Delete a TrainingLearningPath of order
	deleteTrainingLearningPath(request, reply) {
		const lPID = request.query;

		TrainingLPProgram.where(lPID).destroy().then((result) => {
			if (result !== null) {
				TrainingLearning.where(lPID).destroy().then(() => {
					if (result !== null) {
						reply({ isSuccess: true });
					}
				}).catch((error) => {
					reply(Boom.badRequest(error));
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return reply;
	}
	// Add MySQL
	addLearningPath(request, reply) {
		const input = request.payload;
		new TrainingLearning().save({
			LPName: input.LPName,
			Description: input.Description
		}, { method: "insert" }).then((result) => {
			if (result && result.attributes) {

				const lPID = result.attributes.id;
				const programsIdArray = input.ProgramId;

				programsIdArray.forEach(item => {
					new TrainingLPProgram().save({
						LPID: lPID,
						ProgramId: item
					}, { method: "insert" }).then(() => reply({ isSuccess: true })).catch(error => reply(Boom.badRequest(error)));
				});
			}
		}).catch((error) => {
			return reply(Boom.badRequest(error));
		});
	}

	updateLearningPath(request, reply) {
        const input = request.payload;

        TrainingLearning.where({ LPID: input.RepId }).save({
            FirstName: input.FirstName,
            Email: input.Email,
            LastName: input.LastName,
            TenantId: input.TenantId,
            MaxNumOrders: input.MaxNumOrders,
            Ext: input.Ext,
            Active: input.Active,
            SRepOrder: input.SRepOrder
        }, { method: "update" }).then((result) => {
            if (result === null) {
                reply(Boom.badRequest(`Data is null`));
                return;
            }

            const SRepOrder = input.SRepOrder;
            const UsersId = input.UsersId;
            const roleIdArray = input.RoleId;

            new UserRole().where({ UsersId }).destroy().then(() => {
                const insertRoles = [];
                roleIdArray.forEach(roleId => {
                    insertRoles.push({
                        UsersId: input.UsersId,
                        RoleId: roleId.RoleId
                    });
                });
                const UserRoles = Bookshelf.Collection.extend({
                    model: UserRole
                });

                UserRoles.forge(insertRoles).invokeThen("save")
                    .then(() => {
                        // save successfully
                        if (SRepOrder === true) {
                            new SalesReps().where({ RepID: input.RepId }).save({
                                FirstName: input.FirstName,
                                LastName: input.LastName,
                                CommissionPercent: hasStringValue(input.CommissionPercent) ? input.CommissionPercent : null,
                                CommissionAmount: hasStringValue(input.CommissionAmount) ? input.CommissionAmount : null
                            }, { method: "update" })
                                .then(
                                () => {
                                    reply({ isSuccess: true });
                                })
                                .catch(
                                error => {
                                    reply(Boom.badRequest(error));
                                });
                        } else {
                            reply({ isSuccess: true });
                            return;
                        }
                    })
                    .catch(
                    error => reply(Boom.badRequest(error)));
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

}

export default new TrainingLearningPathController();
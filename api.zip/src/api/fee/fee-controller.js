import Boom from "boom";
import Bookshelf from "../../db/database";

class FeeController {
    constructor() { }

    getAllFee(request, reply) {
        Bookshelf.knex.raw(`call GetAllFee()`)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0]
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        return reply;
    }
}

export default new FeeController();
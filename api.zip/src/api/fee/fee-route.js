import FeeController from "./fee-controller";
import FeeRequestReason from "./fee-request-reason";

const routes = [{
    path: "/fee/getFee",
    method: "GET",
    config: { auth: false },
    handler: FeeController.getAllFee
},
{
    path: "/fee/getFeeRequestReason",
    method: "GET",
    config: { auth: false },
    handler: FeeRequestReason.getReasonCode
}];


export default routes;
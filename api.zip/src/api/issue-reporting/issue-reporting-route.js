import IssueReportingController from "./issue-reporting-controller";

const routes = [{
    path: "/issueReporting/getIssuesReporting",
    method: "GET",
    config: { auth: false },
    handler: IssueReportingController.getIssuesReporting
},
{
    path: "/issueReporting/getIssuesReportingById",
    method: "GET",
    config: { auth: false },
    handler: IssueReportingController.getIssuesReportingById
},

{
    path: "/issueReporting/updateIssueReporting",
    method: "POST",
    config: { auth: false },
    handler: IssueReportingController.updateIssueReporting
}
];


export default routes;
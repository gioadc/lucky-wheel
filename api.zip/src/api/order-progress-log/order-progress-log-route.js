import OrderProgressLogController from "./order-progress-log-controller";

const routes = [{
    path: "/orderprogress/addProgressLog",
    method: "POST",
    config: { auth: false },
    handler: OrderProgressLogController.addProgressLog
}];

export default routes;
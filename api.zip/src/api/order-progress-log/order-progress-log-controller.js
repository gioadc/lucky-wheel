import Boom from "boom";
import OrderProgressLog from "../../db/model/order-progress-log";

class OrderProgressLogController {
    constructor() { }

    addProgressLog(request, reply) {
        const log = request.payload;
        const newLog = new OrderProgressLog();

        // add a log to db
        newLog.save(log, { method: "insert" }).then(() => {
            reply({
                isSuccess: true
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }
}

export default new OrderProgressLogController();
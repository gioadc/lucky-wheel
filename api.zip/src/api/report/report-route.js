import SendReport from "./report-controller";

const routes = [{
    path: "/report/sendReportOrderDetails",
    method: "POST",
    config: { auth: false },
    handler: SendReport.sendReportOrderDetails
}, {
    path: "/report/sendReportOrderConfirmation",
    method: "POST",
    config: { auth: false },
    handler: SendReport.sendReportOrderConfirmation
}, {
    path: "/report/sendOrderClosedReport",
    method: "GET",
    config: { auth: false },
    handler: SendReport.sendOrderClosedReport
}, {
    path: "/report/sendOrderScheduledReport",
    method: "GET",
    config: { auth: false },
    handler: SendReport.sendOrderScheduledReport
}];

export default routes;
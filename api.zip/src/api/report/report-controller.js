import Bookshelf from "../../db/database";
import Boom from "boom";
import pdf from "html-pdf";
import fs from "fs";
import Order from "../../db/model/order";
import Signers from "../../db/model/signers";
import Users from "../../db/model/users";
import sendMailCore from "../../mail/mail-helper";
import { error } from "util";
import { readFileToString, mergeDataField, convertRowDataPackage, writeFileToHTML, handleBreakLine } from "../../helper/common-helper";
import { getMergeFieldMapping, TEMPLATE_ORDER_DETAILS_PATH, OUTPUT_ORDER_DETAILS_HTML_PATH, OUTPUT_ORDER_DETAILS_PDF_PATH } from "../../merge-engine/reports/order-detail";
import { getMergeFieldMappingOrderConfirmation, TEMPLATE_ORDER_CONFIRMATION_PATH, OUTPUT_ORDER_CONFIRMATION_HTML_PATH, OUTPUT_ORDER_CONFIRMATION_PDF_PATH } from "../../merge-engine/reports/order-confirmation";
import {
    getMergeFieldMappingOrderClosed, TEMPLATE_ORDER_CLOSED_PATH,
    OUTPUT_ORDER_CLOSED_HTML_PATH, OUTPUT_ORDER_CLOSED_PDF_PATH
} from "../../merge-engine/reports/order-closed";
import {
    getMergeFieldMappingOrderScheduled, TEMPLATE_ORDER_SCHEDULED_PATH,
    OUTPUT_ORDER_SCHEDULED_HTML_PATH, OUTPUT_ORDER_SCHEDULED_PDF_PATH
} from "../../merge-engine/reports/order-scheduled";

class ReportController {
    constructor() { }

    sendReportOrderDetails(request, reply) {
        const { orderID } = request.payload;
        // const orderID = 12;

        // const brokerId = Order.where({ orderID: orderID }).fetch({ columns: ["BrokerId"] }).then((result) => {
        //     return result[0];
        // });

        const rawSqlSumFees = `SELECT SUM(SignerFee) AS signerFee
                        FROM order_fee
                        WHERE OrderID = ${orderID};`;

        Bookshelf.knex.raw(rawSqlSumFees)
            .then(feesResult => {
                if (feesResult !== null) {
                    const signerFee = convertRowDataPackage(feesResult[0][0]);
                    const rawSqlSignerInfo = `SELECT u.UserName AS signerUsername, s.Email AS signerEmail, s.Fax AS signerFax, concat(s.FirstName, " ", s.LastName) AS signerFullName          
                    FROM signer as s
                    INNER JOIN \`order\` as o ON o.SignerId = s.SignerId
                    INNER JOIN users as u ON u.MappingUserId = s.SignerId
                    INNER JOIN user_roles ur ON ur.UsersId = u.UsersId
                    INNER JOIN role_permission rp ON rp.RoleId = ur.RoleId                                    
                    WHERE rp.Type = 'Vendor' AND o.OrderId = ${orderID};`;

                    Bookshelf.knex.raw(rawSqlSignerInfo)
                        .then(signerResult => {
                            const signerInfo = convertRowDataPackage(signerResult[0][0]);
                            if (signerInfo.signerEmail !== null) {

                                Bookshelf.knex.raw(`call GetDataForOrderDetailsReport(${orderID})`)
                                    .then(result => {
                                        const attachments = [];
                                        const tempData = convertRowDataPackage(result[0][0][0]);
                                        tempData.importantCompanyInstruction = handleBreakLine(tempData.importantCompanyInstruction);
                                        const dataToSendReport = Object.assign({}, signerFee, signerInfo, tempData, { orderID });

                                        // Test array List - Begin

                                        const testArrayRawSQL = `SELECT of.BrokerFee
                                                                        , of.SignerFee
                                                                        , fd.Description
                                                                from order_fee as of
                                                                inner join fee_description as fd on of.FeeDescripID = fd.FeeDescriptionId
                                                                where of.OrderID = 1
                                                                union
                                                                (SELECT sum(BrokerFee), sum(SignerFee), "Total"
                                                                from order_fee
                                                                where OrderID = 1)`;

                                        Bookshelf.knex.raw(testArrayRawSQL).then(result => {
                                            const feeData = convertRowDataPackage(result[0]);
                                            //console.log(feeData.length);
                                            const testData = Object.assign({}, signerFee, signerInfo, tempData, { orderID }, { feeData });
                                            const reportHtml = mergeDataField(readFileToString(TEMPLATE_ORDER_DETAILS_PATH), getMergeFieldMapping(testData));

                                            writeFileToHTML("./src/content/reports/OrderDetails_testArray.html", reportHtml);
                                            }).catch((error) => {
                                            return error;
                                        });

                                        // Test array List - End

                                        const options = {
                                            "height": "10.5in",
                                            "width": "8in",
                                            "format": "A4",
                                            "orientation": "portrait"
                                        };
                                        const reportHtml = mergeDataField(readFileToString(TEMPLATE_ORDER_DETAILS_PATH), getMergeFieldMapping(dataToSendReport));
                                        const newFileName = `/TheClosingExchange-Confirmation_OrderId-${orderID}.pdf`;

                                        writeFileToHTML(OUTPUT_ORDER_DETAILS_HTML_PATH, reportHtml);

                                        pdf.create(reportHtml, options).toFile(OUTPUT_ORDER_DETAILS_PDF_PATH + newFileName, (error) => {
                                            if (error) reply(Boom.badRequest(error));
                                        });

                                        if (tempData.brokerId.length > 0 && tempData.brokerId !== null || tempData.brokerId !== "") {
                                            try {
                                                if (fs.accessSync(`D:/LenderSpecs/${tempData.brokerId}/Lenderspecifics.pdf`, fs.constants.R_OK) === undefined) {
                                                    attachments.push("/download/report/Lenderspecifics.pdf");
                                                }
                                                if (fs.accessSync("D:/LenderSpecifics/Email/NotaryAttachments.pdf", fs.constants.F_OK) === undefined) {
                                                    attachments.push("/download/report/NotaryAttachments.pdf");
                                                }
                                                if (tempData.agentName.length > 0 && tempData.agentName === "WFAF") {
                                                    if (fs.accessSync("D:/LenderSpecifics/Email/WFAF_Special_Instruction.pdf", fs.constants.F_OK) === undefined) {
                                                        attachments.push("/download/report/WFAF_Special_Instruction.pdf");
                                                    }
                                                }
                                                if (fs.accessSync(OUTPUT_ORDER_DETAILS_PDF_PATH + newFileName, fs.constants.F_OK) === undefined) {
                                                    attachments.push(`/download/report${newFileName}`);
                                                }
                                            } catch (err) {
                                                reply(Boom.badRequest(error));
                                            }
                                            // fs.access("D:/LenderSpecs/" + tempData.brokerId + "/lenderspecifics.pdf", fs.constants.F_OK, (err) => {
                                            //     err ? console.log("lenderspecifics.pdf not exists!") :
                                            //     fs.access("D:/LenderSpecifics/Email/NotaryAttachments.pdf", fs.constants.F_OK, (err) => {
                                            //         err ? console.log("NotaryAttachments.pdf not exists!") : attachments.push("NotaryAttachments.pdf");
                                            //     });
                                            //     if (tempData.agentName.length > 0 && tempData.agentName === "WFAF") {
                                            //         fs.access("D:/LenderSpecifics/Email/WFAF_Special_Instruction.pdf", fs.constants.F_OK, (err) => {
                                            //             err ? console.log("WFAF_Special_Instruction.pdf not exists!") : attachments.push("WFAF_Special_Instruction.pdf");
                                            //         });
                                            //     }
                                            // });
                                        }


                                        reply({ signerEmail: signerInfo.signerEmail, subject: `The Closing Exchange Order ${orderID} Signing Details`, body: reportHtml, attachments });
                                        // const mailOptions = {
                                        //     from: "pavaso01@adb.com",
                                        //     to: "pavaso01@adb.com",
                                        //     subject: `The Closing Exchange Order ${orderID} Signing Details`,
                                        //     text: `Send Email`,
                                        //     html: reportHtml
                                        // };

                                        // sendMailCore(mailOptions, (resultSendMail) => {
                                        //     reply(resultSendMail);
                                        // });

                                    }).catch((error) => {
                                        reply(Boom.badRequest(error));
                                    });
                            }
                            return "Unable to Send, Missing or Invalid Signer Email Address";
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                        });
                }
                return "This order does not have Fees, enter fees before sending reports";
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

        // switch (type) {
        //     case "OrderFormAsPDF": {
        //         // Business goes here
        //         // tham khao client-controller line: 390
        //         break;
        //     }

        //     default: {
        //         // Business goes here
        //     };
        // };
    }

    sendReportOrderConfirmation(request, reply) {
        //const { orderID } = request.payload;
        const orderID = 1;

        Bookshelf.knex.raw(`call GetDataForOrderConfirmationReport(${orderID})`)
            .then(result => {
                const options = {
                    "height": "10.5in",
                    "width": "8in",
                    "format": "A4",
                    "orientation": "portrait"
                };
                const tempData = convertRowDataPackage(result[0][0][0]);
                const dataToSendReport = Object.assign({}, tempData, { orderID });
                const reportHtml = mergeDataField(readFileToString(TEMPLATE_ORDER_CONFIRMATION_PATH), getMergeFieldMappingOrderConfirmation(dataToSendReport));
                writeFileToHTML(OUTPUT_ORDER_CONFIRMATION_HTML_PATH, reportHtml);
                pdf.create(reportHtml, options).toFile(OUTPUT_ORDER_CONFIRMATION_PDF_PATH, (error) => {
                    if (error) reply(Boom.badRequest(error));
                });
                reply("Done!");
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }


    sendOrderClosedReport(request, reply) {
        // const { orderID } = request.query;
        const orderID = 14;
        const options = {
            "height": "10.5in",
            "width": "8in",
            "format": "A4",
            "orientation": "portrait"
        };

        Bookshelf.knex.raw(`call GetDataForOrderClosedAndScheduledReport(${orderID})`)
            .then(result => {
                const data = convertRowDataPackage(result[0][0][0]);

                //validate data
                if (!hasStringValue(data.toEmail)) {
                    reply({
                        isSuccess: false,
                        message: "Unable to Send, Missing or Invalid Agent Email Address"
                    });
                    return;
                }
                //done validate -> write file
                const reportHtml = mergeDataField(readFileToString(TEMPLATE_ORDER_CLOSED_PATH), getMergeFieldMappingOrderClosed(data));

                writeFileToHTML(OUTPUT_ORDER_CLOSED_HTML_PATH, reportHtml);
                pdf.create(reportHtml, options).toFile(OUTPUT_ORDER_CLOSED_PDF_PATH, (err) => {
                    if (err) reply(Boom.badRequest(err));
                });

                reply({
                    isSuccess: true
                });
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }

    sendOrderScheduledReport(request, reply) {
        // const { orderID } = request.query;
        const orderID = 14;
        const options = {
            "height": "10.5in",
            "width": "8in",
            "format": "A4",
            "orientation": "portrait"
        };

        Bookshelf.knex.raw(`call GetDataForOrderClosedAndScheduledReport(${orderID})`)
            .then(result => {
                const data = convertRowDataPackage(result[0][0][0]);

                //validate data
                if (data.brokerId === 2165 || data.brokerId === 3174) {
                    reply({
                        isSuccess: false,
                        message: "Broker does not require this Report. No Action Taken"
                    });
                    return;
                }

                if (!hasStringValue(data.toEmail)) {
                    reply({
                        isSuccess: false,
                        message: "Unable to Send, Missing or Invalid Agent Email Address"
                    });
                    return;
                }
                //done validate -> write file
                const reportHtml = mergeDataField(readFileToString(TEMPLATE_ORDER_SCHEDULED_PATH), getMergeFieldMappingOrderScheduled(data));

                writeFileToHTML(OUTPUT_ORDER_SCHEDULED_HTML_PATH, reportHtml);
                pdf.create(reportHtml, options).toFile(OUTPUT_ORDER_SCHEDULED_PDF_PATH, (err) => {
                    if (err) reply(Boom.badRequest(err));
                });

                reply({
                    isSuccess: true
                });
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }
}

export default new ReportController();
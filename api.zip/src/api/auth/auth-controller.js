import { authConstant } from "../../server/constant";
import Jwt from "../../lib/jwt";
import Boom from "boom";
import Bookshelf from "../../db/database";

import { isBuffer, bufferToBoolean, bookshelfError } from "../../helper/common-helper";

import User from "../../db/model/users";
import Employees from "../../db/model/employees";
import Broker from "../../db/model/brokers";
import Signer from "../../db/model/signers";
import Agent from "../../db/model/agents";

import UserRoles from "../../db/model/user-roles";

class AuthController {
	constructor() { }

	createAnAccount(request, reply) {
		const {
			username,
			password,
			mappingUserId,
			tenantId
		} = request.payload;

		if (username === undefined || username === null || password === undefined || password === null) {
			reply(Boom.badRequest("Missing credentials"));
			return;
		}

		// hash password
		const salt = Jwt.generateSalt();
		const hashedPassword = Jwt.hash(password, salt);

		new User().save({
			Username: username,
			Password: hashedPassword,
			MappingUserId: mappingUserId,
			TenantId: tenantId,
			HashSalt: salt
		}, { method: "insert" })
			.then((rs) => {
				if (rs === null) {
					reply(Boom.badRequest("Can not save account"));
					return;
				}

				const { UserID, TenantID } = rs.attributes;

				reply({
					UserID,
					TenantID
				});
			});
	}

	register(request, reply) {
		const {
			user
		} = request.payload;

		// validate user
		const newUser = new User(user);

		if (newUser.isNew()) {
			// create user
			new User(user)
				.save()
				.then((result) => {
					if (result === null) {
						reply(Boom.badRequest(authConstant.registerFailed));
						return;
					}

					const { UserID, TenantID } = result.attributes;

					reply({
						UserID,
						TenantID
					});
				}, () => {
					reply(Boom.badRequest(authConstant.registerFailed));
					return;
				});
		}
	}

	authorize(request, reply) {
		const {
			username,
			password
		} = request.payload;

		const mapRoleByUserId = (userId, onSuccess, onError) => {
			const rolesSql = `CALL GetUserRolePermissions(${userId});`;

			Bookshelf.knex.raw(rolesSql)
				.then((result) => {
					if (result === null) {
						return onError({
							message: `Unable to get role and permissions of user ${userId}`
						});
					}

					const rolePermissions = result[0][0];
					const userRole = {
						roleNames: [],
						permissions: [],
						roleType: ""
					};

					// get role type
					userRole.roleType = rolePermissions[0].Type;

					rolePermissions.forEach((role) => {
						// get role name
						userRole.roleNames.push(role.RoleName);

						// get permissions
						Object.keys(role).forEach((permission) => {
							const value = role[permission];

							if (isBuffer(value) && bufferToBoolean(value)) {
								userRole.permissions.push(permission);
							}
						});
					});

					return onSuccess(userRole);
				}, (err) => {
					return onError({
						message: `Unable to get role and permissions of user ${userId}: ${JSON.stringify(err)}`
					});
				});
		};

		User.where({ UserName: username })
			.fetch({ columns: ["UsersId", "Password", "HashSalt", "MappingUserId", "TenantId", "IsActive", "UserName"] })
			.then((result) => {
				if (result === null) {
					reply(Boom.badRequest(authConstant.userNotFound));
					return;
				}

				const { Password, HashSalt, MappingUserId, TenantId, UsersId, IsActive, UserName } = result.attributes;
				const isUserActive = bufferToBoolean(IsActive);

				if (Jwt.checkPassword(Password, HashSalt, password)) {
					// user is valid
					if (!isUserActive) {
						reply(Boom.badRequest(`Inactive account.`));
						return;
					}

					// get his role
					mapRoleByUserId(UsersId, (userRole) => {
						// get his profile based on role type
						switch (userRole.roleType) {
							case "Staff":
								Employees.where({
									TenantId,
									RepId: MappingUserId
								})
									.fetch({ columns: ["RepId", "FirstName", "LastName"] })
									.then((profile) => {
										if (profile === null) {
											reply(Boom.badRequest(authConstant.userNotFound));
											return;
										}

										const { FirstName, LastName, RepId } = profile.attributes;

										const token = Jwt.signIn(username, {
											id: UsersId,
											role: userRole,
											tenantId: TenantId,
											profile: {
												id: RepId,
												firstName: FirstName,
												lastName: LastName,
												userName: UserName,
												userId: UsersId,
												subRoleType: ""
											}
										});

										reply({
											accessToken: token
										});
									}).catch((err) => {
										reply(Boom.badRequest(bookshelfError(err)));
										return;
									});
								break;
							case "Client":
								if (userRole.roleNames[0] === "Agent") {
									Agent.where({
										TenantId,
										AgentId: MappingUserId
									}).fetch({ columns: ["AgentId", "FullName", "inActive"] }).then(profile => {
										if (profile === null) {
											reply(Boom.badRequest(authConstant.userNotFound));
											return;
										}

										const inActive = profile.attributes.inActive;
										if (isBuffer(inActive) && bufferToBoolean(inActive)) {
											reply(Boom.badRequest(authConstant.userNotFound));
											return;
										}

										const { FullName, AgentId } = profile.attributes;
										const token = Jwt.signIn(username, {
											id: UsersId,
											role: userRole,
											tenantId: TenantId,
											profile: {
												id: AgentId,
												firstName: FullName,
												lastName: "",
												userName: UserName,
												userId: UsersId,
												subRoleType: "AGENT"
											}
										});

										reply({
											accessToken: token
										});
									})
										.catch((err) => {
											reply(Boom.badRequest(bookshelfError(err)));
											return;
										});
								} else {
									Broker.where({
										TenantId,
										BrokerID: MappingUserId
									})
										.fetch({ columns: ["BrokerID", "Company", "GID"] })
										.then((profile) => {
											if (profile === null) {
												reply(Boom.badRequest(authConstant.userNotFound));
												return;
											}

											const { Company, BrokerID, GID } = profile.attributes;

											const token = Jwt.signIn(username, {
												id: UsersId,
												role: userRole,
												tenantId: TenantId,
												profile: {
													id: BrokerID,
													firstName: Company,
													lastName: "",
													userName: UserName,
													userId: UsersId,
													subRoleType: GID !== null && GID > 0 ? "BRANCH" : "CLIENT"
												}
											});

											reply({
												accessToken: token
											});
										});
								}
								break;
							case "Vendor":
								Signer.where({
									TenantId,
									SignerId: MappingUserId
								})
									.fetch({ columns: ["SignerId", "FirstName", "LastName"] })
									.then((profile) => {
										if (profile === null) {
											reply(Boom.badRequest(authConstant.userNotFound));
											return;
										}

										const { FirstName, LastName, SignerId } = profile.attributes;

										const token = Jwt.signIn(username, {
											id: UsersId,
											role: userRole,
											tenantId: TenantId,
											profile: {
												id: SignerId,
												firstName: FirstName,
												lastName: LastName,
												userName: UserName,
												userId: UsersId,
												subRoleType: ""
											}
										});

										reply({
											accessToken: token
										});
									})
									.catch((err) => {
										reply(Boom.badRequest(bookshelfError(err)));
										return;
									});
								break;
						}
					}, (err) => {
						reply(Boom.badRequest(err.message));
						return;
					});
				} else {
					reply(Boom.badRequest(authConstant.incorrectPassword));
					return;
				}
			}, (err) => {
				reply(Boom.badRequest(`Unable to connect to database: ${JSON.stringify(err)}`));
				return;
			});
	}
}

export default new AuthController();
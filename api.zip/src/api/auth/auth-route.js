import AuthController from "./auth-controller";

const routes = [{
    path: "/authorize",
    method: "POST",
    config: { auth: false },
    handler: AuthController.authorize
},
{
    path: "/createAccount",
    method: "POST",
    config: { auth: false },
    handler: AuthController.createAnAccount
}];

export default routes;
import IssueController from "./issue-controller";

const routes = [{
    path: "/issue/getIssues",
    method: "GET",
    config: { auth: false },
    handler: IssueController.getIssues
},
{
    path: "/issue/addIssue",
    method: "POST",
    config: { auth: false },
    handler: IssueController.addIssue
},
{
    path: "/issue/updateIssue",
    method: "POST",
    config: { auth: false },
    handler: IssueController.updateIssue
},
{
    path: "/issue/deleteIssue",
    method: "DELETE",
    config: { auth: false },
    handler: IssueController.deleteIssue
},
{
    path: "/issue/getIssueById",
    method: "GET",
    config: { auth: false },
    handler: IssueController.getIssueById
}];


export default routes;
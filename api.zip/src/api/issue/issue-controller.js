// import { authConstant } from "../../server/constant";
import Issue from "../../db/model/issue";
import Boom from "boom";
import Bookshelf from "../../db/database";
import moment from "moment";
import { isBuffer, bufferToBoolean } from "../../helper/common-helper";
import OrderProgressLog from "../../db/model/order-progress-log";

class IssueController {
	constructor() { }

	getIssueById(request, reply) {
		const { problemId } = request.query;
		const rawSql = `SELECT op.problemId, op.orderId, sn.firstName as 'signerFirstName',
		sn.lastname as 'signerLastName', ps.description as 'status',
		pt.description as 'type',em.firstName as 'repFirstName',
		em.lastname as 'repLastName', op.date, us.username as 'enteredBy', op.trackingNumber,
		op.mistake,op.acknowledged,op.apologySentDate,op.notes,op.resolution,
		usap.username as 'approvedBy',usrs.username as 'resolvedBy'
		FROM order_problem op
		LEFT JOIN signer sn on sn.signerId = op.signerId
		LEFT JOIN problem_status ps on ps.id = op.status
		LEFT JOIN problem_types pt on pt.id= op.type
		LEFT JOIN employees em on em.repId = op.repId
		LEFT JOIN users us on us.usersId = op.enteredBy
		LEFT JOIN users usap on usap.usersId = op.approvedBy
		LEFT JOIN users usrs on usrs.usersId = op.resolvedBy
		WHERE op.problemId = ${problemId}`;
		Bookshelf.knex.raw(rawSql).then((result) => {
			if (result !== null) {
				result = result[0][0];
				Object.keys(result).forEach((key) => {
					const value = result[key];
					if (isBuffer(value)) {
						result[key] = bufferToBoolean(value);
					}
				});
				reply(result);
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return;
	}

	getIssues(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			orderId
		} = request.query;
		Bookshelf.knex.raw(`call GetOrderIssuesByOrderId(${orderId},'${sortColumn}',${sortDirection},${page},
			${itemPerPage})`)
			.then((result) => {
				if (result !== null) {
					reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});

		return reply;
	}

	addIssue(request, reply) {
		const issue = request.payload;
		delete issue.isEmailLender;
		delete issue.isEmailVendor;
		issue.mistake = issue.mistake === "1";
		new Issue(issue).save({ date: moment().format("YYYY-MM-DD HH:mm:ss") }, { method: "insert" }).then(() => {
			new OrderProgressLog().save({ orderId: issue.orderId, activity: "Problem Added", dateLog: moment().format("YYYY-MM-DD HH:mm:ss"), usersId: issue.enteredBy }, { method: "insert" }).then(() => {
				reply({
					isSuccess: true
				});
			}).catch((error) => reply(Boom.badRequest(error)));
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	updateIssue(request, reply) {
		const issue = request.payload;
		const isAddProgress = issue.isAddProgress;
		const usersId = issue.usersId;
		delete issue.isAddProgress;
		delete issue.usersId;
		let activity = "";
		switch (issue.status) {
			case 3:
				activity = "Problem Resolved";
				break;
			case 4:
				activity = "Problem Approved";
				break;
			case 5:
				activity = "Problem Rejected";
				break;
		}
		Issue.where({ problemId: issue.problemId }).save(issue, { method: "update" }).then(() => {
			if (isAddProgress) {
				new OrderProgressLog().save({ orderId: issue.orderId, activity, dateLog: moment().format("YYYY-MM-DD HH:mm:ss"), usersId }, { method: "insert" }).then(() => {
					reply({
						isSuccess: true
					});
				}).catch((error) => reply(Boom.badRequest(error)));
			} else {
				reply({
					isSuccess: true
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	// Delete a issue of order
	deleteIssue(request, reply) {
		const problemId = request.query;

		Issue.where(problemId).destroy().then((result) => {
			if (result !== null) {
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return reply;
	}
}

export default new IssueController();
import ClientProfileCredentialsController from "./client-profile-credentials-controller";

const routes = [{
    path: "/client-profile/getUserProfileCredentials",
    method: "GET",
    config: { auth: false },
    handler: ClientProfileCredentialsController.getUserProfileCredentials
},
{
    path: "/client-profile/updateUserProfileCredentials",
    method: "POST",
    config: { auth: false },
    handler: ClientProfileCredentialsController.updateUserProfileCredentials
}
];

export default routes;
import ClientProfileController from "./client-profile-controller";

const routes = [{
    path: "/client-profile/getClientProfiles",
    method: "GET",
    config: { auth: false },
    handler: ClientProfileController.getClientProfiles
}, {
    path: "/client-profile/updateClientProfiles",
    method: "POST",
    config: { auth: false },
    handler: ClientProfileController.updateClientProfiles
}];

export default routes;
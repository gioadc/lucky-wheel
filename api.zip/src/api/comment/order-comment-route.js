import OrderCommentController from "../comment/order-comment-controller";

const routes = [{
    path: "/comment/getComments",
    method: "GET",
    config: { auth: false },
    handler: OrderCommentController.getComments
},
{
    path: "/comment/deleteComment",
    method: "DELETE",
    config: { auth: false },
    handler: OrderCommentController.deleteComment
},
{
    path: "/comment/addComment",
    method: "POST",
    config: { auth: false },
    handler: OrderCommentController.addComment
},
{
    path: "/comment/getCommentByType",
    method: "GET",
    config: { auth: false },
    handler: OrderCommentController.getCommentByType
}];


export default routes;
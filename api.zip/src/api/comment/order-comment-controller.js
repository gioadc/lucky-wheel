import Comment from "../../db/model/comment";
import Boom from "boom";
import Bookshelf from "../../db/database";

class OrderCommentController {

    // Get Comment MySQL
    getComments(request, reply) {

        const {
            orderId,
			sortColumn,
            sortDirection,
            page,
            itemPerPage
		} = request.query;

        const rawSql = `call GetOrderComment('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId === undefined ? null : `${orderId}`})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });

                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return;
            });

        return reply;
    }

    // Add Comment MySQL
    addComment(request, reply) {
        const comment = request.payload;
        new Comment().save({
            Description: comment.Description,
            CreatedBy: comment.CreatedBy,
            TypeID: comment.TypeID,
            OwnerID: comment.OwnerID,
            ParentID: comment.ParentID,
            CreatedDate: comment.CreatedDate,
            IsPrivate: comment.IsPrivate
        },
            { method: "insert" }).then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });

                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return;
            });
    }

    deleteComment(request, reply) {
        const CommentID = request.query;
        Comment.where(CommentID).destroy().then((result) => {

            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getCommentByType(request, reply) {
        const { typeId, ownerId } = request.query;

        const rawSql = `SELECT Description, CommentID, CreatedDate, u.UserName ` +
            `FROM comment AS c INNER JOIN users AS u ON u.UsersId=c.CreatedBy ` +
            `WHERE TypeID=${typeId} AND OwnerID=${ownerId} ORDER BY CommentID DESC`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply(result[0]);
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }
}

export default new OrderCommentController();
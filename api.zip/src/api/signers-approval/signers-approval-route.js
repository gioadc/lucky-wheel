import SignersApprovalController from "./signers-approval-controller";

const routes = [{
    path: "/staffApprovalManagement/getSignersApproval",
    method: "GET",
    config: { auth: false },
    handler: SignersApprovalController.getSignersApproval
}, {
    path: "/staffApprovalManagement/updateSignerApproval",
    method: "POST",
    config: { auth: false },
    handler: SignersApprovalController.updateSignerApproval
}];

export default routes;
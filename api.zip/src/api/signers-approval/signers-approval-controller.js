import Bookshelf from "../../db/database";
import Boom from "boom";
import moment from "moment";
import SignersApproval from "../../db/model/signers-approval";
import Order from "../../db/model/order";
import OrderProgressLog from "../../db/model/order-progress-log";

class SignersApprovalController {
	constructor() { }

	getSignersApproval(request, reply) {
		const { sortColumn, sortDirection, page, itemPerPage, orderID, status, requesterName } = request.query;
		const rawSql = `CALL GetSignersApproval('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderID === "" ? null : orderID}, '${status}', '${requesterName}');`;

		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null) {
					result[0][0].forEach((item) => {
						item.RequestDate = item.RequestDate === null ? null : moment(item.RequestDate).format("MM/DD/YY hh:mm:ss A");
						item.ApprovedDate = item.ApprovedDate === null ? null : moment(item.ApprovedDate).format("MM/DD/YY hh:mm:ss A");
					});
					reply(result[0]);
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	updateSignerApproval(request, reply) {
		const payload = request.payload;
		const signerApproval = {
			approvedBy: payload.approvedBy,
            approvalID: payload.approvalID,
            orderId: payload.orderId,
            signerId: payload.signerId,
            status: payload.status,
            mgrReason: payload.mgrReason,
            approvedDate: payload.approvedDate
		};
		const usersId = payload.usersId;

		SignersApproval.where({ approvalID: signerApproval.approvalID, Status: "Open" }).save(signerApproval, { method: "update", require: true }).then(() => {
			if (signerApproval.status === "Approved") {
				Order.where({ OrderId: signerApproval.orderId }).save({ SignerId: signerApproval.signerId }, { method: "update", require: true });

				new OrderProgressLog().save({
					OrderId: signerApproval.orderId,
					Activity: "Assigned to Vendor",
					UsersId: usersId,
					DateLog: signerApproval.approvedDate
				}, { method: "insert" });
			}
			reply({ isSuccess: true });
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

}

export default new SignersApprovalController();
import Bookshelf from "../../db/database";
import Boom from "boom";
import { handleSingleQuote, bufferToBoolean } from "../../helper/common-helper";
import TrainingCourses from "../../db/model/training-courses";
import VendorCategory from "../../db/model/vendor-categories";
import TrainingCourseVendor from "../../db/model/training-course-vendor";
import TrainingProgramCourses from "../../db/model/training-program-courses";
import appConfig from "../../config/config";
import fs from "fs";
import moment from "moment";

class TrainingCourseController {
    constructor() { }

    getCourses(request, reply) {
        const {
			sortColumn,
            sortDirection,
            page,
            itemPerPage,
            courseName,
            courseStatus
		} = request.query;
        Bookshelf.knex.raw(`call GetTrainingCourses('${sortColumn}',${sortDirection},${page},
		${itemPerPage},'${handleSingleQuote(courseName)}','${courseStatus}')`)
            .then((result) => {
                if (result !== null) {
                    result[0][0].map((item) => {
                        item.isActive = bufferToBoolean(item.isActive);
                        item.isActiveProgram = bufferToBoolean(item.isActiveProgram);
                        item.isPublishedProgram = bufferToBoolean(item.isPublishedProgram);
                    });

                    const data = {
                        courses: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    };

                    reply(data);
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    getCourseById(request, reply) {
        const courseId = request.query;
        let promiseData;
        const getVendorCategory = Promise.resolve(VendorCategory.forge().orderBy("CatName").fetchAll({ columns: ["catId", "catName"] }));

        if (courseId !== "0" || courseId !== undefined) {
            const rawSqlCourse = `select courseId, title, description, SUBSTRING_INDEX(VideoFile, '_', -1) videoFileName, SUBSTRING_INDEX(document, '_', -1) documentName from training_courses where courseId =${courseId.courseId};`;
            const getCourse = Promise.resolve(Bookshelf.knex.raw(rawSqlCourse));
            const rawSql = `select tcv.catId from training_course_vendor tcv inner join vendor_categories vc on tcv.CatId=vc.CatId where tcv.courseId =${courseId.courseId};`;
            const getVendorByCourseId = Promise.resolve(Bookshelf.knex.raw(rawSql));
            promiseData = Promise.all([getVendorCategory, getCourse, getVendorByCourseId]);
        } else {
            promiseData = Promise.all([getVendorCategory]);
        }
        promiseData.then(values => {
            const data = {};

            if (values !== null) {

                values.forEach((item, index) => {
                    if (item !== null) {
                        switch (index) {
                            case 0:
                                data.vendorCategoryList = item;
                                break;
                            case 1:
                                data.course = item[0][0];
                                break;
                            case 2:
                                data.vendorCategories = item[0];
                                break;
                        }
                    }
                });

            }

            reply(data);
        }).catch(err => {
            reply(Boom.badRequest(err));
        });
    }

    changeStatusCourse(request, reply) {
        const { courseId, isActive } = request.query;

        TrainingCourses.where({ CourseId: courseId }).save({ IsActive: isActive === "true" ? true : false }, { method: "update" }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    deleteCourse(request, reply) {
        const { courseId } = request.query;

        TrainingCourseVendor.where({ courseId }).destroy().then(() => {
            TrainingProgramCourses.where({ courseId }).destroy().then(() => {
                TrainingCourses.where({ courseId }).destroy().then(() => {
                    reply({ isSuccess: true });
                });
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    addCourse(request, reply) {
        const coursesModel = request.payload;
        const course = {
            title: coursesModel.title,
            description: coursesModel.description,
            isActive: true
        };
        const videoFileName = `TEMP-${moment().format("HHmmss")}_${coursesModel.videoFileName}`;
        const videoFilePath = `${appConfig.file.serverPath}/training-course-temp/${videoFileName}`;
        const documentName = `TEMP-${moment().format("HHmmss")}_${coursesModel.documentName}`;
        const documentPath = `${appConfig.file.serverPath}/training-course-temp/${documentName}`;
        course.videoFile = videoFilePath;
        course.document = documentPath;

        new TrainingCourses().save(course, { method: "insert" }).then((result) => {

            if (result !== null) {
                if (coursesModel.vendorCategories !== undefined) {
                    JSON.parse(coursesModel.vendorCategories).map((item) => {
                        item.courseId = result.attributes.id;
                        new TrainingCourseVendor().save(item, { method: "insert" }).then();
                    });
                }

                if (coursesModel.videoFile) {
                    const fileStream = fs.createWriteStream(videoFilePath);
                    coursesModel.videoFile.pipe(fileStream);
                    coursesModel.videoFile.on("end", () => { });
                }

                if (coursesModel.document) {
                    const fileStream = fs.createWriteStream(documentPath);
                    coursesModel.document.pipe(fileStream);
                    coursesModel.document.on("end", () => { });
                }

                reply(result.attributes.id);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    updateCourse(request, reply) {
        const coursesModel = request.payload;
        const course = {
            title: coursesModel.title,
            description: coursesModel.description
        };

        if (coursesModel.videoFileName[0] !== "") {
            const videoFileName = `TEMP-${moment().format("HHmmss")}_${coursesModel.videoFileName[0]}`;
            const videoFilePath = `${appConfig.file.serverPath}/training-course-temp/${videoFileName}`;
            course.videoFile = videoFilePath;
            const fileStream = fs.createWriteStream(videoFilePath);
            coursesModel.videoFile.pipe(fileStream);
            coursesModel.videoFile.on("end", () => { });
        }

        if (coursesModel.documentName[0] !== "") {
            const documentName = `TEMP-${moment().format("HHmmss")}_${coursesModel.documentName[0]}`;
            const documentPath = `${appConfig.file.serverPath}/training-course-temp/${documentName}`;
            course.document = documentPath;
            const fileStream = fs.createWriteStream(documentPath);
            coursesModel.document.pipe(fileStream);
            coursesModel.document.on("end", () => { });
        }
        const courseId = coursesModel.courseId;

        TrainingCourses.where({ courseId }).save(course, { method: "update" }).then((result) => {
            if (result !== null) {
                TrainingCourseVendor.where({ CourseId: courseId }).destroy().then(() => {
                    if (coursesModel.vendorCategories !== undefined) {
                        JSON.parse(coursesModel.vendorCategories).map((item) => {
                            item.courseId = courseId;
                            new TrainingCourseVendor().save(item, { method: "insert" }).then();
                        });
                    }
                });

                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}

export default new TrainingCourseController();
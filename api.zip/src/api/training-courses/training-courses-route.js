import TrainingCourseController from "./training-courses-controller";

const routes = [
    {
        path: "/training-courses/getCourses",
        method: "GET",
        config: { auth: false },
        handler: TrainingCourseController.getCourses
    },
    {
        path: "/training-courses/getCourseById",
        method: "GET",
        config: { auth: false },
        handler: TrainingCourseController.getCourseById
    },
    {
        path: "/training-courses/deleteCourse",
        method: "GET",
        config: { auth: false },
        handler: TrainingCourseController.deleteCourse
    },
    {
        path: "/training-courses/addCourse",
        method: "POST",
        config: {
            auth: false, payload: {
                output: "stream",
                allow: "multipart/form-data"
            }
        },
        handler: TrainingCourseController.addCourse
    },
    {
        path: "/training-courses/updateCourse",
        method: "POST",
        config: {
            auth: false, payload: {
                output: "stream",
                allow: "multipart/form-data"
            }
        },
        handler: TrainingCourseController.updateCourse
    },
    {
        path: "/training-courses/changeStatusCourse",
        method: "GET",
        config: { auth: false },
        handler: TrainingCourseController.changeStatusCourse
    }
];

export default routes;
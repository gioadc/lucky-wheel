import Boom from "boom";
import Bookshelf from "../../db/database";
import SignerOffer from "../../db/model/signer-offer";
import Users from "../../db/model/users";
import Order from "../../db/model/order";

class VendorOfferController {

    getVendorOffer(request, reply) {

        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderID,
            daysBack,
            offerStatus,
            signerId
        } = request.query;
        const rawSql = `call GetVendorOffer(${signerId},'${sortColumn}',${sortDirection},${page}, ${itemPerPage},${orderID},${daysBack},'${offerStatus}')`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0][0],
                        totalRecords: result[0][1][0].TotalRecords
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });

    }

    updateStatusVendorOffer(request, reply) {
        const signerOffer = request.payload;

        SignerOffer.where({ OrderID: signerOffer.OrderID, SignerId: signerOffer.SignerId}).save({
            OfferStatus: signerOffer.OfferStatus
        },
        { method: "update" }).then((result) => {
			if (result !== null) {
                if (signerOffer.OfferStatus === "A") {
                    Order.where({ OrderID: signerOffer.OrderID}).save({
                        SignerId: signerOffer.SignerId
                    },
                    { method: "update" }).then((response) => {
                        if (response !== null) {

                            reply({ isSuccess: true });
                        }
                    }).catch((error) => {
                        reply(Boom.badRequest(error));
                    });
                } else {
                    reply({ isSuccess: true });
                }
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
    }

    getReasonDeclined(request, reply) {
        const rawSql = `select DenialReasonID, DenialReason from offer_denial_reason order by DenialReasonID;`;

        Bookshelf.knex.raw(rawSql)
        .then((result) => {
            if (result !== null) {
                reply({
                    data: result[0]
                });
            }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    sendRequestFeedback(request, reply) {
        const feedback = request.payload;
        const stringAltTime = feedback.altTime === null ? null : `'${ feedback.altTime }'`;
        const stringReturnTime = feedback.returnTime === null ? null : `'${ feedback.returnTime }'`;

        const rawSql = `call DeclinedVendorOffer(${feedback.orderId},${feedback.signerId},${feedback.userId},${feedback.selectedReasonOptions},${stringAltTime}, ${feedback.feeAmount},${stringReturnTime},'${feedback.notDoProduct}','${feedback.additionalInfo}')`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    inactivatedUser(request, reply) {
        const {UsersId} = request.payload;

        Users.where({ UsersId}).save({
            IsActive: false
        },
        { method: "update" }).then((result) => {
			if (result !== null) {
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
    }

    checkExistVendorOffer(request, reply) {
		const { aptDateTime, signerId, orderId } = request.query;
        const rawSql = `call CheckExistVendorOffer('${aptDateTime}',${signerId}, ${orderId})`;
        Bookshelf.knex.raw(rawSql)
        .then((result) => {
            if (result !== null) {
                reply({
                    data: result[0][0][0].isValid
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
	}

}

export default new VendorOfferController();
import VendorOfferController from "./vendor-offer-controller";
const routes = [
    {
        path: "/vendor-offer/getVendorOffer",
        method: "GET",
        config: { auth: false },
        handler: VendorOfferController.getVendorOffer
    },
    {
        path: "/vendor-offer/updateStatusVendorOffer",
        method: "POST",
        config: { auth: false },
        handler: VendorOfferController.updateStatusVendorOffer
    },
    {
        path: "/vendor-offer/getReasonDeclined",
        method: "GET",
        config: { auth: false },
        handler: VendorOfferController.getReasonDeclined
    },
    {
        path: "/vendor-offer/sendRequestFeedback",
        method: "POST",
        config: { auth: false },
        handler: VendorOfferController.sendRequestFeedback
    },
    {
        path: "/vendor-offer/inactivatedUser",
        method: "POST",
        config: { auth: false },
        handler: VendorOfferController.inactivatedUser
    },
    {
        path: "/vendor-offer/checkExistVendorOffer",
        method: "GET",
        config: { auth: false },
        handler: VendorOfferController.checkExistVendorOffer
    }

];

export default routes;
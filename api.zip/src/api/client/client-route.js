import ClientController from "./client-controller";

const routes = [{
    path: "/client/getClients",
    method: "POST",
    config: { auth: false },
    handler: ClientController.getClients
}, {
    path: "/client/getClientManagementData",
    method: "POST",
    config: { auth: false },
    handler: ClientController.getClientManagementData
}, {
    path: "/client/addClient",
    method: "POST",
    config: { auth: false },
    handler: ClientController.addClient
}, {
    path: "/client/updateClient",
    method: "POST",
    config: { auth: false },
    handler: ClientController.updateClient
}, {
    path: "/client/getClientById",
    method: "GET",
    config: { auth: false },
    handler: ClientController.getClientById
}, {
    path: "/client/changeStatusClient",
    method: "GET",
    config: { auth: false },
    handler: ClientController.changeStatusClient
}, {
    path: "/client/getClientContactByClientId",
    method: "GET",
    config: { auth: false },
    handler: ClientController.getClientContactByClientId
}, {
    path: "/client/getClientOrderByClientId",
    method: "GET",
    config: { auth: false },
    handler: ClientController.getClientOrderByClientId
}, {
    path: "/client/getAllClientForDropDown",
    method: "GET",
    config: { auth: false },
    handler: ClientController.getAllClientForDropDown
}, {
    path: "/client/updateClientContact",
    method: "POST",
    config: { auth: false },
    handler: ClientController.updateClientContact
}, {
    path: "/client/getBranchesByBrokerId",
    method: "GET",
    config: { auth: false },
    handler: ClientController.getBranchesByBrokerId
}, {
    path: "/client/getClientStatusReport",
    method: "GET",
    config: { auth: false },
    handler: ClientController.getClientStatusReport
}, {
    path: "/client/updateClientIsAvailable",
    method: "POST",
    config: { auth: false },
    handler: ClientController.updateClientIsAvailable
}];

export default routes;
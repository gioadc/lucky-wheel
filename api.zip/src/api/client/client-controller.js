import Bookshelf from "../../db/database";
import Boom from "boom";
import Client from "../../db/model/clients";
import State from "../../db/model/state";
import Courier from "../../db/model/courier";
import Employees from "../../db/model/employees";
import SalesRep from "../../db/model/sales-reps";
import Fee from "../../db/model/fees";
import BrokerFee from "../../db/model/broker-fee";
import Users from "../../db/model/users";
import { handleSingleQuote } from "../../helper/common-helper";
import pdf from "html-pdf";
import moment from "moment";

class ClientController {
	constructor() { }

	getClientById(request, reply) {
		const brokerId = request.query;
		const rawSql = `SELECT b.BrokerID, b.Company, b.Inactive FROM broker b where (b.GID is null or b.GID = 0) and (b.Inactive is null or b.Inactive = 0) and b.IsAvailable = 1 and b.BrokerID !=${brokerId.brokerId};`;
		const getAllClientActive = Promise.resolve(Bookshelf.knex.raw(rawSql));
		const getAllCourier = Promise.resolve(Courier.fetchAll({ columns: ["CourierID", "Courier"] }));
		const getAllStates = Promise.resolve(State.fetchAll({ columns: ["Code", "Description"] }));
		const getAllEmployees = Promise.resolve(Employees.fetchAll({ columns: ["RepId", "FirstName", "LastName"] }));
		const getAllSaleReps = Promise.resolve(SalesRep.fetchAll({ columns: ["SalesRepId", "FirstName", "LastName", "CommissionPercent", "CommissionAmount"] }));
		let promiseData;
		if (brokerId !== 0 || brokerId !== undefined) {
			const getClient = Promise.resolve(Client.where(brokerId).fetch(
				{
					columns: ["BrokerID", "Company", "Address", "City", "State", "Zip",
						"Phone", "DefaultCourierID", "DefaultCourierAcnt", "RepId", "Email",
						"TermsAccept", "LenderSpecific", "Ccemail", "AutoOrders",
						"TenantId", "Program", "SalesRepId", "Suite", "Inactive", "GID", "InvoiceOnly"]
				}
			));
			const getExistUser = Promise.resolve(Users.where({ UserName: `CLIENT${brokerId.brokerId}` }).fetch({ columns: ["UserName"] }));
			promiseData = Promise.all([getAllClientActive, getAllCourier, getAllStates, getAllEmployees, getAllSaleReps, getClient, getExistUser]);
		} else {
			promiseData = Promise.all([getAllClientActive, getAllCourier, getAllStates, getAllEmployees, getAllSaleReps]);
		}
		promiseData
			.then(values => {
				const data = {};
				if (values !== null) {
					values.forEach((item, index) => {
						if (item !== null) {
							switch (index) {
								case 0:
									data.listClients = item;
									break;
								case 1:
									data.listCourier = item;
									break;
								case 2:
									data.listStates = item;
									break;
								case 3:
									data.listEmployees = item;
									break;
								case 4:
									data.listSalesRep = item;
									break;
								case 5:
									data.clientDetails = item;
									break;
								case 6:
									data.username = item;
									break;
							}
						}
					});
				}
				reply(data);
			}).catch(err => {
				reply(Boom.badRequest(err));
			});

		return reply;
	}
	getClients(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			clientID,
			clientName,
			address,
			city,
			state,
			inactive
		} = request.payload;

		Bookshelf.knex.raw(`call GetClients('${sortColumn}',${sortDirection},${page},
		${itemPerPage},'${clientID}','${handleSingleQuote(clientName)}','${handleSingleQuote(address)}','${handleSingleQuote(city)}','${state}',${inactive})`)
			.then((result) => {
				if (result !== null) {
					const data = {};
					data.listClient = {
						clients: result[0][0],
						totalRecords: result[0][1][0].TotalRecords
					};
					reply(data);
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		return reply;
	}

	getClientManagementData(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			clientID,
			clientName,
			address,
			city,
			state,
			inactive
		} = request.payload;

		const getClients = Promise.resolve(Bookshelf.knex.raw(
			`call GetClients('${sortColumn}',${sortDirection},${page},
			${itemPerPage},'${clientID}','${clientName}','${address}','${city}','${state}',${inactive})`));
		const getAllStates = Promise.resolve(State.fetchAll({ columns: ["Code", "Description"] }));

		Promise.all([getClients, getAllStates])
			.then(values => {
				const data = {};

				if (values !== null) {
					values.forEach((item, index) => {
						if (item !== null) {
							switch (index) {
								case 0:
									data.listClient = {
										clients: item[0][0],
										totalRecords: item[0][1][0].TotalRecords
									};
									break;
								case 1:
									data.listState = item;
									break;
							}
						}
					});
				}
				reply(data);
			}).catch(err => {
				reply(Boom.badRequest(err));
			});

		return reply;
	}

	addClient(request, reply) {
		const client = request.payload;
		const newClient = new Client(client);
		newClient.save({ isAvailable: false }, { method: "insert" }).then((result) => {
			if (result !== null) {
				const brokerId = result.attributes.id;
				Fee.fetchAll().then((fees) => {
					if (fees !== null) {
						const replyError = error => reply(Boom.badRequest(error));

						fees.map(fee => {
							const newBrokerFee = {
								brokerId,
								feeDescripId: fee.attributes.FeeDescriptionId,
								tenantId: 1
							};

							switch (result.attributes.Program.toString()) {
								case "1": //Standard
									newBrokerFee.brokerFee = fee.attributes.DefaultBrokerFee;
									break;
								case "2": //Gold
									newBrokerFee.brokerFee = fee.attributes.Gold;
									break;
								case "3": //Platinum
									newBrokerFee.brokerFee = fee.attributes.Platinum;
									break;
							}

							new BrokerFee(newBrokerFee).save(null, { method: "insert" }).then().catch(replyError);
						});
					}
				}).catch(error => reply(Boom.badRequest(error)));
				reply({ brokerId, isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	updateClient(request, reply) {
		const client = request.payload;
		Client.where({ BrokerId: client.BrokerID }).fetch({ columns: ["Program"] }).then(data => {
			const oldProgram = data.attributes.Program;
			const newProgram = client.Program;
			Client.where({ BrokerId: client.BrokerID }).save(client, { method: "update" }).then(() => {
				if (oldProgram !== newProgram) {
					BrokerFee.where({ brokerId: client.BrokerID }).destroy().then(() => {
						const addFees = (fees) => {
							if (fees !== null) {
								const replyError = error => reply(Boom.badRequest(error));

								const addNewFee = fee => {
									const newBrokerFee = {
										brokerId: client.BrokerID,
										feeDescripId: fee.attributes.FeeDescriptionId,
										tenantId: 1
									};

									switch (newProgram.toString()) {
										case "1":
											newBrokerFee.brokerFee = fee.attributes.DefaultBrokerFee;
											break;
										case "2":
											newBrokerFee.brokerFee = fee.attributes.Gold;
											break;
										case "3":
											newBrokerFee.brokerFee = fee.attributes.Platinum;
											break;
									}

									new BrokerFee(newBrokerFee).save(null, { method: "insert" }).then().catch(replyError);
								};
								fees.map(addNewFee);
							}
						};

						//add new fees
						Fee.fetchAll().then(addFees).catch(error => reply(Boom.badRequest(error)));
					}).catch(error => reply(Boom.badRequest(error)));
				}
				reply({ isSuccess: true });
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});

		}).catch(error => reply(Boom.badRequest(error)));

	}

	updateClientContact(request, reply) {
		const client = request.payload;

		Client.where({ BrokerId: client.BrokerID }).save(client, { method: "update" }).then(() => { reply({ isSuccess: true }); }).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	updateClientIsAvailable(request, reply) {
		const client = request.payload;

		Client.where({ brokerId: client.brokerId }).fetch({ columns: ["company", "administratorFirst"] }).then((model) => {
			const company = model.get("company");
			const administratorFirst = model.get("administratorFirst");
			client.isAvailable = company && company.length > 0 && administratorFirst && administratorFirst.length > 0;
			Client.where({ brokerId: client.brokerId }).save(client, { method: "update" }).then(() => { reply({ isAvailable: client.isAvailable }); }).catch((error) => {
				reply(Boom.badRequest(error));
			});
		}
		);
	}

	changeStatusClient(request, reply) {
		const { brokerId } = request.query;
		Bookshelf.knex.raw(`call ChangeStatusClient('${brokerId}')`).then((result) => {
			if (result !== null) {
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
		return reply;
	}

	getAllClientForDropDown(request, reply) {
		const rawSql = `select b.BrokerID, 
						b.Company, 
						b.City, 
						b.State,
						b.AdditionalContact, 
						b.AdditionalContactEmail, 
						b.AdditionalContactExt, 
						b.AdditionalContactPhone,
						b.DefaultCourierAcnt,
						c.Courier
					from broker b 
					left join courier c on b.DefaultCourierID = c.CourierID 
					where (b.Inactive is null OR b.Inactive=false) AND b.IsAvailable=true order by b.Company;`;

		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null) {
					reply(result[0]);
				}

				return reply;
			}).catch((error) => {
				reply(Boom.badRequest(error));

				return reply;
			});
	}

	getClientContactByClientId(request, reply) {
		const client = request.query;
		Client.where({ brokerId: client.brokerId }).fetch({ columns: ["BrokerID", "administratorFirst", "administratorLast", "administratorExt", "administratorEmail", "primaryContactFirst", "primaryContactLast", "primaryContactExt", "primaryContactFax", "contactNotes"] }).then((result) => {
			reply(result);
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getClientOrderByClientId(request, reply) {
		const client = request.query;
		Client.where({ brokerId: client.brokerId }).fetch({ columns: ["BrokerId", "firstContactDate", "lastContactDate", "firstOrderDate", "lastOrderDate", "ytdOrders", "mtdOrders", "totalOrders"] }).then((result) => {
			reply(result);
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getBranchesByBrokerId(request, reply) {
		const { brokerId } = request.query;
		Client.where({ gid: brokerId }).fetchAll({ columns: ["brokerId", "gId", "company"] }).then(branches => {
			reply(branches);
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getClientStatusReport(request, reply) {
		let htmlBody = "";
		Bookshelf.knex.raw(`call GetClientStatus()`).then((result) => {
			if (result !== null) {
				result[0][0].map((item) => {
					htmlBody = htmlBody.concat(`<tr><td>${item.OrderID}</td>
					<td>${item.BrokerIDNum}</td>
					<td>${item.Company}</td>
					<td>${item.FullName}</td>
					<td>${item.LastName}</td>
					<td>${item.OrderDate ? moment(item.OrderDate).format("MM/DD/YYYY") : ""}</td>
					<td>${item.AptDateTime ? moment(item.AptDateTime).format("MM/DD/YYYY") : ""}</td>
					<td>${item.AptDateTime ? moment(item.FilledDate).format("MM/DD/YYYY") : ""}</td>
					<td>${item.Signer}</td>
					<td>${item.SaleRep}</td>
					<td>${item.closeddate ? moment(item.closeddate).format("MM/DD/YYYY") : ""}</td>
					<td>${item.ProgressDescription}</td></tr>`);
				});
				const options = {
					"height": "10.5in",
					"width": "8in",
					"format": "A4",
					"orientation": "portrait",
					"footer": {
						"height": "12mm",
						"contents": {
							default: `<hr/><span style="color: #444; font-size: 8pt; padding-left: 20px;">${moment().format("dddd, MMMM dS, YYYY")}</span><span style="color: #444; font-size: 8pt; padding-right: 20px; float:right;">Page {{page}} of {{pages}}</span>`
						}
					}
				};
				const html = `<html><body>
				<h1>Client Status Report</h1><hr/>
				<table style="font-size: 8pt; border-spacing: 0;border-collapse: collapse;">
					<thead>
						<th style="border-bottom: 1px solid #222;">Order ID</th>
						<th style="border-bottom: 1px solid #222;">Loan #</th>
						<th style="border-bottom: 1px solid #222;">Customer</th>
						<th style="border-bottom: 1px solid #222;">Contact</th>
						<th style="border-bottom: 1px solid #222;">Borrower</th>
						<th style="border-bottom: 1px solid #222;">Order Date</th>
						<th style="border-bottom: 1px solid #222;">Scheduled</th>
						<th style="border-bottom: 1px solid #222;">Assigned</th>
						<th style="border-bottom: 1px solid #222;">Signing Agent</th>
						<th style="border-bottom: 1px solid #222;">TCE Rep</th>
						<th style="border-bottom: 1px solid #222;">Date Closed</th>
						<th style="border-bottom: 1px solid #222;">Progress</th>
					</thead>
					<tbody>
						${htmlBody}
					</tbody>
				</table>
				</body></html>`;

				pdf.create(html, options).toBuffer((err, buffer) => {

					return reply(buffer)
						.header("content-disposition", `attachment; filename=ClientStatus.pdf`);
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}
}

export default new ClientController();
import Boom from "boom";
import Bookshelf from "./../../db/database";

class StateController {
    constructor() { }
    getAllState(request, reply) {
        Bookshelf.knex.raw(`call GetAllState`)
            .then((result) => {
                if (result !== null) {
                    reply(result[0][0]);
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }
}
export default new StateController();
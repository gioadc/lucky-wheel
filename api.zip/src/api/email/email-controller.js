import sendMailCore from "../../mail/mail-helper";

class EmailController {
    constructor() { }

    sendMail(request, reply) {
        const options = request.payload;

        const mailOptions = {
            from: "pavaso01@adb.com",
            to: options.to,
            subject: options.subject,
            text: options.text || "",
            html: options.html
        };

        sendMailCore(mailOptions, (result) => {
            return reply(result);
        });
    }
}

export default new EmailController();
import EmailController from "./email-controller";

const routes = [{
    path: "/mail/sendMail",
    method: "POST",
    config: { auth: false },
    handler: EmailController.sendMail
}];

export default routes;
import SmsController from "./sms-controller";

const routes = [{
    path: "/sms/sendSms",
    method: "POST",
    config: { auth: false },
    handler: SmsController.sendSms
}];

export default routes;
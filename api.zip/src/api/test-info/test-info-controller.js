import Boom from "boom";
import moment from "moment";
import TestInfo from "../../db/model/test-info";
import TestSection from "../../db/model/test-section";
import TestQa from "../../db/model/test-qa";
import TrainingProgramTest from "../../db/model/training-program-test";
import { isBuffer, bufferToBoolean } from "../../helper/common-helper";
import Bookshelf from "../../db/database";
import { handleSingleQuote } from "../../helper/common-helper";

class TestInfoController {
	constructor() { }

	async addTestInfo(request, reply) {
		const testInfo = request.payload;
		const { sections } = testInfo;
		delete testInfo.sections;
		new TestInfo(testInfo).save({
			tenantId: 1,
			active: true,
			createdDate: moment().format("YYYY-MM-DD HH:mm:ss")
		}, { method: "insert" }).then(async (testInfoModel) => {
			const testId = testInfoModel.get("id");

			const addSection = async section => {
				if (section.flag !== "Deleted") {
					const { questions } = section;
					delete section.questions;
					delete section.isShowQuestion;
					delete section.sectionId;
					delete section.flag;
					delete section.isNewAdded;
					await new Promise((sectionResolve) => new TestSection(section).save({ testId }, { method: "insert" }).then(async sectionModel => {
						const sectionId = sectionModel.get("id");
						const addQuestion = async question => {
							if (question.flag !== "Deleted") {
								delete question.questionId;
								delete question.flag;
								delete question.isNewAdded;
								const errorAddQuestion = error => Boom.badRequest(error);
								await new Promise((resolve) => new TestQa(question).save({ tenantId: 1, testId, sectionId }, { method: "insert" }).then(() => {
									resolve();
								}).catch(errorAddQuestion));
							}
						};
						for (const question of questions) {
							await addQuestion(question);
						}
						sectionResolve();
					}).catch(error => Boom.badRequest(error)));
				}
			};
			for (const section of sections) {
				await addSection(section);
			}
			reply({ isSuccess: true });
		}).catch(error => Boom.badRequest(error));
	}

	getTestInfoById(request, reply) {
		const { testId } = request.query;
		TestInfo.where({ testId }).fetch({ columns: ["testId", "expiredAfter", "testName", "testDesc", "passPercent", "maxAttempts", "lockDays"] }).then(test => {
			TestSection.where({ testId }).orderBy("sortOrder", "ASC").fetchAll({ columns: ["sectionId", "sectionDescription", "sortOrder", "testId"] }).then(sections => {
				TestQa.where({ testId }).orderBy("sortOrder", "ASC").fetchAll({ columns: ["testId", "questionId", "sectionId", "question", "a", "b", "c", "d", "e", "correct", "isActive", "isRotated", "sortOrder"] }).then((questions) => {
					const handleConvertBufferToBoolean = question => {
						const handleConvert = (key) => {
							const value = question.attributes[key];
							if (isBuffer(value)) {
								question.attributes[key] = bufferToBoolean(value);
							}
						};

						Object.keys(question.attributes).forEach(handleConvert);
						return question;
					};

					questions = questions.map(handleConvertBufferToBoolean);

					const addQuestions = section => {
						section.attributes.questions = [];
						const addQuestion = question => {
							if (question.get("sectionId") === section.get("sectionId")) {
								section.attributes.questions.push(question);
							}
						};

						questions.forEach(addQuestion);
						return section;
					};

					sections = sections.map(addQuestions);
					test.attributes.sections = sections;
					reply(test);
				}).catch(error => Boom.badRequest(error));
			}).catch(error => Boom.badRequest(error));
		}).catch(error => Boom.badRequest(error));
	}

	async updateTestInfo(request, reply) {
		const testInfo = request.payload;
		const { sections } = testInfo;
		delete testInfo.sections;

		const badRequest = error => Boom.badRequest(error);

		TestInfo.where({ testId: testInfo.testId }).save(testInfo, { method: "update" }).then(async () => {
			if (sections) {
				const handleSection = async section => {
					const { questions, isNewAdded, flag } = section;
					delete section.flag;
					delete section.questions;
					delete section.isShowQuestion;
					delete section.isNewAdded;

					const handleQuestions = async sectionId => {
						const handleQuestion = async question => {
							const questionFlag = question.flag;
							const isNewQuestionAdded = question.isNewAdded;
							delete question.flag;
							delete question.isNewAdded;
							switch (questionFlag) {
								case "Edited":
									await new Promise(resolve => TestQa.where({ questionId: question.questionId }).save(question, { method: "update" }).then(() => resolve()).catch(badRequest));
									break;
								case "Added":
									delete question.questionId;
									await new Promise(resolve => new TestQa(question).save({ sectionId, tenantId: 1, testId: testInfo.testId }, { method: "insert" }).then(() => resolve()).catch(badRequest));
									break;
								case "Deleted":
									if (!isNewQuestionAdded) {
										await new Promise(resolve => TestQa.where({ questionId: question.questionId }).destroy().then(() => resolve()).catch(badRequest));
									}
									break;
								default: break;
							}
						};

						for (const question of questions) {
							await handleQuestion(question);
						}

					};

					switch (flag) {
						case "Edited":
							await new Promise(resolve => TestSection.where({ sectionId: section.sectionId }).save(section, { method: "update" }).then(async () => {
								await handleQuestions(section.sectionId);
								resolve();
							}).catch(badRequest));
							break;
						case "Added":
							delete section.sectionId;
							await new Promise(resolve => new TestSection(section).save({ testId: testInfo.testId }, { method: "insert" }).then(async (sectionModel) => {
								await handleQuestions(sectionModel.get("id"));
								resolve();
							}).catch(badRequest));
							break;
						case "Deleted":
							if (!isNewAdded) {
								await new Promise(resolve => TestQa.where({ sectionId: section.sectionId }).destroy().then(() => {
									TestSection.where({ sectionId: section.sectionId }).destroy().then(() => resolve()).catch(badRequest);
								}
								).catch(badRequest));
							}
							break;
						default: break;
					}
				};

				for (const section of sections) {
					await handleSection(section);
				}
			}
			reply({ isSuccess: true });
		}).catch(badRequest);
	}

	deleteTestInfo(request, reply) {
		const { testId } = request.payload;
		TestQa.where({ testId }).destroy().then(() => {
			TestSection.where({ testId }).destroy().then(() => {
				TrainingProgramTest.where({ testId }).destroy().then(() => {
					const doneDeleteTestInfo = () => {
						reply({ isSuccess: true });
					};
					TestInfo.where({ testId }).destroy().then(doneDeleteTestInfo).catch(error => Boom.badRequest(error));
				}).catch(error => Boom.badRequest(error));
			}).catch(error => Boom.badRequest(error));
		}).catch(error => Boom.badRequest(error));
	}

	getTestInfos(request, reply) {
		const { testName, isActive, sortColumn, sortDirection, page, itemPerPage } = request.payload;
		Bookshelf.knex.raw(`call GetTestInfos('${handleSingleQuote(testName)}',${isActive},'${sortColumn}',${sortDirection},${page},${itemPerPage})`)
			.then((result) => {
				if (result !== null) {
					reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	checkExistTest(request, reply) {
		const { testName } = request.payload;
		let { testId } = request.payload;
		if (!testId) {
			testId = 0;
		}
		TestInfo.query((qb) => {
			qb.where("testName", "=", `${testName}`).andWhere("testId", "<>", testId);
		}).count("*").then((result) => {
			reply({ isExist: result > 0 });
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}
}

export default new TestInfoController();
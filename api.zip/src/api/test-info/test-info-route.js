import TestInfoController from "./test-info-controller";

const routes = [{
    path: "/testInfo/addTestInfo",
    method: "POST",
    config: { auth: false },
    handler: TestInfoController.addTestInfo
}, {
    path: "/testInfo/getTestInfos",
    method: "POST",
    config: { auth: false },
    handler: TestInfoController.getTestInfos
},
{
    path: "/testInfo/updateTestInfo",
    method: "POST",
    config: { auth: false },
    handler: TestInfoController.updateTestInfo
}, {
    path: "/testInfo/deleteTestInfo",
    method: "POST",
    config: { auth: false },
    handler: TestInfoController.deleteTestInfo
}, {
    path: "/testInfo/getTestInfoById",
    method: "GET",
    config: { auth: false },
    handler: TestInfoController.getTestInfoById
}, {
    path: "/testInfo/checkExistTest",
    method: "POST",
    config: { auth: false },
    handler: TestInfoController.checkExistTest
}];

export default routes;
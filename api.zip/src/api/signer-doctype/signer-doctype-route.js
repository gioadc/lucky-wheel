import SignerDocTypeController from "./signer-doctype-controller";

const routes = [{
    path: "/signerDocType/getDocTypeBySignerId",
    method: "GET",
    config: { auth: false },
    handler: SignerDocTypeController.getDocTypeBySignerId
}];

export default routes;
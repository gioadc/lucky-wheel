import AgentController from "./agent-controller";

const routes = [{
    path: "/agent/getAgentsByBrokerId",
    method: "GET",
    config: { auth: false },
    handler: AgentController.getAgentsByBrokerId
},
{
    path: "/agent/addAgent",
    method: "POST",
    config: { auth: false },
    handler: AgentController.addAgent
},
{
    path: "/agent/updateAgent",
    method: "POST",
    config: { auth: false },
    handler: AgentController.updateAgent
},
{
    path: "/agent/getAgentById",
    method: "GET",
    config: { auth: false },
    handler: AgentController.getAgentById
},
{
    path: "/agent/getAgentByOption",
    method: "GET",
    config: { auth: false },
    handler: AgentController.getAgentByOption
}];

export default routes;
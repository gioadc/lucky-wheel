import Boom from "boom";
import Bookshelf from "../../db/database";
import Agent from "../../db/model/agents";
import User from "../../db/model/users";
import UserRole from "../../db/model/user-roles";
import RolePermission from "../../db/model/role-permission";
import Jwt from "../../lib/jwt";
import moment from "moment";
import { handleSingleQuote } from "../../helper/common-helper";

class AgentController {
	constructor() { }

	getAgentById(request, reply) {
		const { agentId } = request.query;

		// annv2: comment below lines code and add new query
		// Agent.where({ agentId }).fetch().then((result) => {
		// 	if (result !== null) {
		// 		reply(result);
		// 	}
		// }).catch((error) => {
		// 	reply(Boom.badRequest(error));
		// });

		Bookshelf.knex.select("agent.AgentId", "agent.TenantId", "agent.Ext", "agent.Fax", "agent.Email",
			"agent.AfterhoursPhone", "agent.Inactive", "agent.BranchID", "agent.Direct",
			"agent.ViewAll", "agent.BrokerId", "agent.FullName", "agent.NeedResetPassword", "broker.Company")
			.from("agent")
			.innerJoin("broker", "agent.BrokerId", "=", "broker.BrokerID")
			.where("AgentId", agentId)
			.then((result) => {
				reply(result);
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});

		return;
	}

	getAgentsByBrokerId(request, reply) {
		const {
			brokerId,
			sortColumn,
			sortDirection,
			page,
			itemPerPage
		} = request.query;

		Bookshelf.knex.raw(`call GetAgentsByBrokerId(${brokerId},'${sortColumn}',${sortDirection},${page},
			${itemPerPage})`)
			.then((result) => {
				if (result !== null) {
					reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		return reply;
	}

	addAgent(request, reply) {
		const agent = request.payload.agent;
		const user = request.payload.user;
		const username = user.Username;
		const password = user.Password;
		delete agent.BranchID;

		User.where({ username }).count("*").then((count) => {
			if (count === 0) {
				const newAgent = new Agent(agent);
				newAgent.save(null, { method: "insert" }).then((result) => {
					if (result && result.attributes) {

						const newAgentId = result.attributes.id;
						let roleId = 1;

						const addUserSuccess = (userModel) => {
							const usersId = userModel.get("id");
							new UserRole().save({
								UsersId: usersId,
								RoleId: roleId
							}, { method: "insert" }).then(() => reply({ isSuccess: true })).catch(error => reply(Boom.badRequest(error)));
						};

						RolePermission.where({ RoleName: "Agent", Type: "Client" }).fetch().then((roleResult) => {
							if (roleResult && roleResult.attributes) {
								roleId = roleResult.attributes.RoleId;
							}

							const salt = Jwt.generateSalt();
							const hashedPassword = Jwt.hash(password, salt);

							new User().save({
								Username: username,
								Password: hashedPassword,
								MappingUserId: newAgentId,
								HashSalt: salt,
								DateCreated: moment().format("YYYY-MM-DD HH:mm:ss"),
								TenantId: 1
							},
								{ method: "insert" })
								.then(addUserSuccess).catch((error) => {
									return reply(Boom.badRequest(error));
								});
						}).catch((error) => {
							return reply(Boom.badRequest(error));
						});
					}
				}).catch((error) => {
					return reply(Boom.badRequest(error));
				});
			} else {
				return reply({ isSuccess: false });
			}
		});
	}

	updateAgent(request, reply) {
		const agent = request.payload;
		delete agent.BranchID;
		delete agent.NeedResetPassword;
		delete agent.Company;

		Agent.where({ AgentId: agent.AgentId }).save(agent, { method: "update" }).then((result) => {
			if (result !== null) {
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getAgentByOption(request, reply) {
		const { brokerId, sortColumn, sortDirection, page, itemPerPage, agentId, agentName, agentEmail } = request.query;
		const newAgentId = agentId === "" ? null : agentId;

		Bookshelf.knex.raw(`call GetAgentByOption( ${brokerId}, '${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${newAgentId}, '${handleSingleQuote(agentName)}', '${handleSingleQuote(agentEmail)}')`)
			.then((result) => {
				if (result !== null) {
					reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

}

export default new AgentController();
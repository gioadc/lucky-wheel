import SubLoanTypeController from "./sub-loan-type-controller";
const routes = [
    {
        path: "/sub-loan-type/getSubLoanTypes",
        method: "GET",
        config: { auth: false },
        handler: SubLoanTypeController.getSubLoanTypes
    }
];

export default routes;
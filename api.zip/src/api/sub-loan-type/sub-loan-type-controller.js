import Boom from "boom";
import Bookshelf from "../../db/database";

class SubLoanTypeController {
    getSubLoanTypes(request, reply) {
        const loanTypes = request.query;
        const rawSql = `SELECT lts.SubTypeId, lts.SubLoanType FROM loan_type_sub lts inner join loan_type lt on lts.LoanTypeId=lt.LoanTypeId where lt.LoanTypeId in (${loanTypes.LoanTypeId})`;
        Bookshelf.knex.raw(rawSql).then((result) => {
            if (result !== null) {
                reply(result[0]);
            }
        }).catch((error) => {
			reply(Boom.badRequest(error));
		});
    }
}

export default new SubLoanTypeController();
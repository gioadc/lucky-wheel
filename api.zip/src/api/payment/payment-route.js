import PaymentController from "./payment-controller";

const routes = [{
    path: "/payment/requestPaymentToken",
    method: "POST",
    config: { auth: false },
    handler: PaymentController.requestPaymentToken
}];

export default routes;
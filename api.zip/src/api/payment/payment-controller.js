import Boom from "boom";

import Payment from "../../db/model/payment";

import Gateway from "../../lib/braintree-gateway";

class PaymentController {
    constructor() { }

    requestPaymentToken(request, reply) {
        const {
            nonce,
            paymentId
        } = request.payload;

        const updateCustomer = (customerId) => {
            return Gateway.customer.update(customerId, {
                paymentMethodNonce: nonce
            })
                .then((result) => {
                    if (result && result.success) {
                        const { expirationMonth, expirationYear, token, maskedNumber } = result.customer.paymentMethods[0];

                        // update token
                        const paymentMethod = {
                            Token: token,
                            ExpirationMonth: expirationMonth,
                            ExpirationYear: expirationYear,
                            MaskedNumber: maskedNumber
                        };

                        Payment.where({ PaymentId: paymentId }).save(paymentMethod, { method: "update" })
                            .then(() => {
                                reply(paymentId);
                                return;
                            })
                            .catch((error) => {
                                reply(Boom.badRequest(error));
                                return;
                            });
                    }
                })
                .catch(err => {
                    reply(Boom.badRequest(`Braintree: ${err.name}`));
                    return;
                });
        };

        const createCustomer = () => {
            return Gateway.customer.create({
                paymentMethodNonce: nonce
            })
                .then((result) => {
                    if (result && result.success) {
                        const customerId = result.customer.id;
                        const { expirationMonth, expirationYear, token, maskedNumber } = result.customer.paymentMethods[0];

                        // save token to database
                        new Payment().save({
                            CustomerId: customerId,
                            Token: token,
                            ExpirationMonth: expirationMonth,
                            ExpirationYear: expirationYear,
                            MaskedNumber: maskedNumber
                        }, { method: "insert" }).then((data) => {
                            const { id } = data;

                            reply(id);
                            return;
                        }).catch((error) => {
                            reply(Boom.badRequest(error));
                            return;
                        });
                    }
                })
                .catch(err => {
                    reply(Boom.badRequest(`Braintree: ${err.name}`));
                    return;
                });
        };

        if (paymentId && paymentId > 0) {
            // if this payment has been saved
            Payment.where({ PaymentId: paymentId }).fetch()
                .then((result) => {
                    const { CustomerId } = result.attributes;

                    updateCustomer(CustomerId);
                })
                .catch(err => {
                    reply(Boom.badRequest(`Braintree: ${err.name}`));
                    return;
                });
        } else {
            // create a customer
            createCustomer();
        }
    }
}

export default new PaymentController();
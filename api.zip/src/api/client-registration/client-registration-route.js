import ReturnDocsController from "./return-docs-controller";

const routes = [{
    path: "/client-registration/getReturnDocsDataById",
    method: "GET",
    config: { auth: false },
    handler: ReturnDocsController.getReturnDocsData
},
{
    path: "/client-registration/addNewInputData",
    method: "POST",
    config: { auth: false },
    handler: ReturnDocsController.addNewReturnDocsData
}];

export default routes;
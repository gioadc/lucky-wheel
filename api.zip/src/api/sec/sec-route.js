import SecController from "./sec-controller";

const routes = [
    {
        path: "/sec/getSecQuestionsForDropdown",
        method: "GET",
        config: { auth: false },
        handler: SecController.getSecQuestionsForDropdown
    },
    {
        path: "/sec/addSecAnswer",
        method: "POST",
        config: { auth: false },
        handler: SecController.addSecAnswer
    },
    {
        path: "/sec/deleteSecAnswers",
        method: "GET",
        config: { auth: false },
        handler: SecController.deleteSecAnswers
    }
];

export default routes;
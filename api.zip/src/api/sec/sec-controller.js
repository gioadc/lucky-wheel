import Bookshelf from "../../db/database";
import SecAnswers from "../../db/model/sec-answers";
import Boom from "boom";
import User from "../../db/model/users";
class SecController {
    constructor() { }

    getSecQuestionsForDropdown(request, reply) {
        const rawSql = `select q.ChalID, q.Question from sec_questions q;`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply(result[0]);
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

    // add new sec_answers
    addSecAnswer(request, reply) {
        const secAnswers = request.payload;

        new SecAnswers().save({
            UserId: secAnswers.mappingUserId,
            ChalId1: secAnswers.chalId1,
            Answer1: secAnswers.answer1,
            ChalId2: secAnswers.chalId2,
            Answer2: secAnswers.answer2,
            ChalId3: secAnswers.chalId3,
            Answer3: secAnswers.answer3
        },
            { method: "insert" }).then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    deleteSecAnswers(request, reply) {
        const username = request.query;
        User.where({ UserName: username.username }).fetch({ columns: ["UsersId"] }).then((data) => {
            SecAnswers.where({ UserId: data.attributes.UsersId }).destroy().then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}

export default new SecController();
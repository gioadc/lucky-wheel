import ManagerInternalUserController from "../manage-internal-user/manage-internal-user-controller";

const routes = [{
    path: "/managerinternaluser/getAllManagerInternalUser",
    method: "GET",
    config: { auth: false },
    handler: ManagerInternalUserController.getAllManagerInternalUser
},
{
    path: "/managerinternaluser/deleteManagerInternalUser",
    method: "DELETE",
    config: { auth: false },
    handler: ManagerInternalUserController.deleteManagerInternalUser
},
{
    path: "/managerinternaluser/getManagerInternalUser",
    method: "GET",
    config: { auth: false },
    handler: ManagerInternalUserController.getManagerInternalUser
},
{
    path: "/managerinternaluser/getUsersByRepId",
    method: "GET",
    config: { auth: false },
    handler: ManagerInternalUserController.getUsersByRepId
},
{
    path: "/managerinternaluser/getRoleName",
    method: "GET",
    config: { auth: false },
    handler: ManagerInternalUserController.getRoleName
},
{
    path: "/managerinternaluser/addManagerInternalUser",
    method: "POST",
    config: { auth: false },
    handler: ManagerInternalUserController.addManagerInternalUser
},
{
    path: "/managerinternaluser/updateEmployees",
    method: "POST",
    config: { auth: false },
    handler: ManagerInternalUserController.updateEmployees
},
{
    path: "/managerinternaluser/updateActive",
    method: "POST",
    config: { auth: false },
    handler: ManagerInternalUserController.updateActive
},
{
    path: "/managerinternaluser/getUserIdByRepId",
    method: "GET",
    config: { auth: false },
    handler: ManagerInternalUserController.getUserIdByRepId
}];
// {
//     path: "managerinternaluser/getUserIdByRepId",
//     method: "POST",
//     config: { auth: false },
//     handler: ManagerInternalUserController.getUserIdByRepId
// }];
export default routes;

import Boom from "boom";
import LoanType from "../../db/model/loan-type";

class LoanTypeController {
    getLoanTypes(request, reply) {
        LoanType.forge().orderBy("LoanType").fetchAll().then((result) => {
            if (result !== null) {
                reply({ isSuccess: true, loanTypes: result });
                return;
            }

            reply({ isSuccess: false, message: "No record found!"});
        }).catch((error) => {
			reply(Boom.badRequest(error));
		});
        return;
    }
}

export default new LoanTypeController();
import LoanTypeController from "./loan-type-controller";
const routes = [
    {
        path: "/loan-type/getLoanTypes",
        method: "GET",
        config: { auth: false },
        handler: LoanTypeController.getLoanTypes
    }
];

export default routes;
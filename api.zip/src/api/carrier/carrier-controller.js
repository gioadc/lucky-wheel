import Bookshelf from "../../db/database";
import Boom from "boom";

class CarrierController {
	constructor() { }

	getAllCarriersForDropDown(request, reply) {
		const rawSql = `select c.CarrierID, c.Carrier from carriers c;`;

		Bookshelf.knex.raw(rawSql)
			.then(result => {
				if (result !== null) {
					reply(result[0]);
				}

				return reply;
			}).catch((error) => {
				reply(Boom.badRequest(error));

				return reply;
			});
	}
}

export default new CarrierController();
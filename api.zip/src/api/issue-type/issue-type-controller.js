// import { authConstant } from "../../server/constant";
import IssueType from "../../db/model/issue-type";
import Boom from "boom";

class IssueTypeController {
	constructor() { }
	getAllIssueType(request, reply) {
		new IssueType().fetchAll({ columns: ["Id", "Description"] }).then((result) => {
			if (result !== null) {
				reply(result);
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return;
	}
}

export default new IssueTypeController();
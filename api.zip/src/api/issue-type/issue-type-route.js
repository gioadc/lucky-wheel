import IssueTypeController from "./issue-type-controller";

const routes = [{
    path: "/issueType/getAllIssueType",
    method: "GET",
    config: { auth: false },
    handler: IssueTypeController.getAllIssueType
}];


export default routes;
import Boom from "boom";
import Bookshelf from "./../../db/database";

class LanguageController {
    constructor() { }
    getAllLanguage(request, reply) {
        const rawSql = `select LanguageID, Language from language order by Language;`;
        Bookshelf.knex.raw(rawSql)
        .then((result) => {
            if (result !== null) {
                reply({
                    data: result[0]
                });
                return;
            }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }
}
export default new LanguageController();
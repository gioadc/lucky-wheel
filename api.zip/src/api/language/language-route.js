import LanguageController from "./language-controller";

const routes = [{
    path: "/language/getAllLanguage",
    method: "GET",
    config: { auth: false },
    handler: LanguageController.getAllLanguage
}];

export default routes;
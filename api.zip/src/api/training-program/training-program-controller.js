import Boom from "boom";
import Bookshelf from "../../db/database";
import { isBuffer, bufferToBoolean } from "../../helper/common-helper";
import TrainingPrograms from "../../db/model/training-programs";
import TrainingProgramCourses from "../../db/model/training-program-courses";
import TrainingProgramTest from "../../db/model/training-program-test";

class TrainingProgramController {

    getTrainingPrograms(request, reply) {
        const {
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            programName,
            programStatus
        } = request.query;
        const rawSql = `call getTrainingPrograms('${sortColumn}',${sortDirection},${page}, ${itemPerPage},'${programName}',${programStatus})`;

        Bookshelf.knex.raw(rawSql)
        .then((result) => {
            if (result !== null) {
                const trainingPrograms = result[0][0];
                Object.keys(trainingPrograms).forEach((keyRow) => {
                    const value = trainingPrograms[keyRow];
                    Object.keys(value).forEach((keyField) => {
                        if (isBuffer(trainingPrograms[keyRow][keyField])) {
                            trainingPrograms[keyRow][keyField] = bufferToBoolean(trainingPrograms[keyRow][keyField]);
                        }
                    });
                });
                reply({
                    data: trainingPrograms,
                    totalRecords: result[0][1][0].TotalRecords
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getInputProgagram(request, reply) {
        const { programId } = request.query;

        const getAllCourses = Promise.resolve(Bookshelf.knex.raw(`select CourseId as value, Title as label from training_courses order by label;`));
        const getAllTests = Promise.resolve(Bookshelf.knex.raw(`select TestId as value, TestName as label from test_info order by label;`));
        if (programId !== 0) {
            const getCoursesById = Promise.resolve(Bookshelf.knex.raw(`select training_program_courses.CourseId as value, training_courses.Title as label from training_program_courses
                                                                        inner join training_courses on training_program_courses.CourseId = training_courses.CourseId where training_program_courses.ProgramId = ${programId};`));
            const getTestsById = Promise.resolve(Bookshelf.knex.raw(`select training_program_test.TestId as value, test_info.TestName as label from training_program_test
                                                                    inner join test_info on training_program_test.TestId = test_info.TestId  where training_program_test.ProgramId = ${programId};`));
            Promise.all([getAllCourses, getAllTests, getCoursesById, getTestsById])
            .then(values => {
                const data = {};
                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.listCourse = item;
                                    break;
                                case 1:
                                    data.listTest = item;
                                    break;
                                case 2:
                                    data.courses = item;
                                    break;
                                case 3:
                                    data.tests = item;
                                    break;
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        } else {
            Promise.all([getAllCourses, getAllTests ])
            .then(values => {
                const data = {};
                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.listCourse = item;
                                    break;
                                case 1:
                                    data.listTest = item;
                                    break;
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        }
    }

    updateTraningProgram(request, reply) {
        const {program, courses, tests} = request.payload;
        if (program.programId === 0) {

            const getMaxTrainingId = `select Max(ProgramId) as currentMax from training_programs`;

            Bookshelf.knex.raw(getMaxTrainingId)
            .then((result) => {
                if (result !== null) {
                    const maxTraningProgram = result[0][0].currentMax + 1;

                    const addTraningProgram = Promise.resolve(new TrainingPrograms().save({
                        Title: program.programName,
                        Description: program.description,
                        ForVendor: program.forVendor,
                        ForStaff: program.forStaff,
                        IsPublished: program.isPublished,
                        IsActive: program.isActive
                    }, { method: "insert" }));

                    const queue = [addTraningProgram];

                    queue.push(Promise.resolve(Bookshelf.knex.raw(getMaxTrainingId)));
                    if (courses !== undefined && courses.length > 0) {
                        courses.map((addr) => {
                            queue.push(Promise.resolve(new TrainingProgramCourses().save({
                                CourseId: addr.value,
                                ProgramId: maxTraningProgram
                            }, { method: "insert" })));
                        });
                    }

                    if (courses !== undefined && tests.length > 0) {
                        tests.map((addr) => {
                            queue.push(Promise.resolve(new TrainingProgramTest().save({
                                TestId: addr.value,
                                ProgramId: maxTraningProgram
                            }, { method: "insert" })));
                        });
                    }

                    Promise.all(queue).then(() => {
                        reply({ isSuccess: true });
                    }).catch((error) => {
                        reply(Boom.badRequest(error));
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        } else {
            const updateTraningProgram = Promise.resolve(TrainingPrograms.where({ ProgramId: program.programId }).save({
                Title: program.programName,
                Description: program.description,
                ForVendor: program.forVendor,
                ForStaff: program.forStaff,
                IsPublished: program.isPublished,
                IsActive: program.isActive
            }, { method: "update" }));

            const queue = [updateTraningProgram];
            if (courses !== undefined && courses.length > 0) {
                const delCoursesById = `DELETE FROM training_program_courses WHERE ProgramId=${program.programId}`;
                queue.push(Promise.resolve(Bookshelf.knex.raw(delCoursesById)));
                courses.map((addr) => {
                    queue.push(Promise.resolve(new TrainingProgramCourses().save({
                        CourseId: addr.value,
                        ProgramId: program.programId
                    }, { method: "insert" })));
                });
            }

            if (tests !== undefined && tests.length > 0) {
                const delTestsById = `DELETE FROM training_program_test WHERE ProgramId=${program.programId}`;
                queue.push(Promise.resolve(Bookshelf.knex.raw(delTestsById)));
                tests.map((addr) => {
                    queue.push(Promise.resolve(new TrainingProgramTest().save({
                        TestId: addr.value,
                        ProgramId: program.programId
                    }, { method: "insert" })));
                });
            }

            Promise.all(queue).then(() => {
                reply({ isSuccess: true });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        }
    }

    deleteTrainingProgram(request, reply) {
        const { programId } = request.query;
        const deleteTrainingProgramCourses = Promise.resolve(TrainingProgramCourses.where({ProgramId: programId}).destroy());
        const deleteTrainingProgramTest = Promise.resolve(TrainingProgramTest.where({ProgramId: programId}).destroy());
        const deleteTrainingProgram = Promise.resolve(TrainingPrograms.where({ProgramId: programId}).destroy());
        const queue = [deleteTrainingProgramCourses, deleteTrainingProgramTest, deleteTrainingProgram];

        Promise.all(queue).then(() => {
            reply({ isSuccess: true });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    publicUnPublicTrainingProgram(request, reply) {
        const {program} = request.payload;

        if (program.isPublished === true) {
            TrainingPrograms.where({ProgramId: program.programId}).save({
                IsPublished: false
            },
            { method: "update" }).then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        } else {
            const publicTraningProgram = Promise.resolve(TrainingPrograms.where({ ProgramId: program.programId }).save({
                IsPublished: true
            }, { method: "update" }));
            const queue = [publicTraningProgram];
            if (program.isActive !== true) {
                queue.push(Promise.resolve(TrainingPrograms.where({ ProgramId: program.programId }).save({
                    IsActive: true
                }, { method: "update" })));
            }

            Promise.all(queue).then(() => {
                reply({ isSuccess: true });
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
        }
    }

    checkProgramName(request, reply) {
        const { programName } = request.query;
		TrainingPrograms.where({ Title: programName }).count("*").then((count) => {
            const isExist = count > 0;
			reply({isExist});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}
}

export default new TrainingProgramController();
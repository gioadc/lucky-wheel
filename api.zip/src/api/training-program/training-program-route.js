import TrainingProgramController from "./training-program-controller";
const routes = [
    {
        path: "/training-program/getTrainingPrograms",
        method: "GET",
        config: { auth: false },
        handler: TrainingProgramController.getTrainingPrograms
    },
    {
        path: "/training-program/getInputProgagram",
        method: "GET",
        config: { auth: false },
        handler: TrainingProgramController.getInputProgagram
    },
    {
        path: "/training-program/updateTraningProgram",
        method: "POST",
        config: { auth: false },
        handler: TrainingProgramController.updateTraningProgram
    },
    {
        path: "/training-program/deleteTrainingProgram",
        method: "DELETE",
        config: { auth: false },
        handler: TrainingProgramController.deleteTrainingProgram
    },
    {
        path: "/training-program/publicUnPublicTrainingProgram",
        method: "POST",
        config: { auth: false },
        handler: TrainingProgramController.publicUnPublicTrainingProgram
    },
    {
        path: "/training-program/checkProgramName",
        method: "GET",
        config: { auth: false },
        handler: TrainingProgramController.checkProgramName
    }
];

export default routes;
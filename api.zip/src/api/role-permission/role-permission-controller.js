import Bookshelf from "../../db/database";
import Boom from "boom";

import { bufferToBoolean } from "../../helper/common-helper";

import RolePermission from "../../db/model/role-permission";

class RolePermissionController {

    getRolePermission(request, reply) {
        RolePermission.fetchAll({
            columns: ["RoleId", "RoleName", "General", "UserManagement", "ContentManagement", "TrainingAndTesting", "Accounting", "RoleAndPermission",
                "ClientManagement", "ClientPipeline", "Chatting", "VendorManagement", "VendorPipeline", "InternalUserManagement", "AssignVendor",
                "VendorClassification", "Reporting", "AddViewOrder", "VendorRatingSetting", "FeeApproval", "VendorApproval", "ServiceConfigurationApproval",
                "VendorCredentialsDocumentApproval", "SignedDocumentApproval", "ChangeFeeOnClosedOrders", "DisableNewOrders", "AutoOrders",
                "IssueApproval", "IssueReporting", "UserProfileSetting", "FeeRequest", "Type"]
        }).then((result) => {
            if (result !== null) {
                const rolePermissions = result;
                const userRoles = [];

                rolePermissions.forEach((role) => {
                    const userRole = {
                        RoleId: role.attributes.RoleId, RoleName: role.attributes.RoleName,
                        Type: role.attributes.Type,
                        General: bufferToBoolean(role.attributes.General) ? 1 : 0,
                        UserManagement: bufferToBoolean(role.attributes.UserManagement) ? 1 : 0,
                        ContentManagement: bufferToBoolean(role.attributes.ContentManagement) ? 1 : 0,
                        TrainingAndTesting: bufferToBoolean(role.attributes.TrainingAndTesting) ? 1 : 0,
                        Accounting: bufferToBoolean(role.attributes.Accounting) ? 1 : 0,
                        RoleAndPermission: bufferToBoolean(role.attributes.RoleAndPermission) ? 1 : 0,
                        ClientManagement: bufferToBoolean(role.attributes.ClientManagement) ? 1 : 0,
                        ClientPipeline: bufferToBoolean(role.attributes.ClientPipeline) ? 1 : 0,
                        Chatting: bufferToBoolean(role.attributes.Chatting) ? 1 : 0,
                        VendorManagement: bufferToBoolean(role.attributes.VendorManagement) ? 1 : 0,
                        VendorPipeline: bufferToBoolean(role.attributes.VendorPipeline) ? 1 : 0,
                        InternalUserManagement: bufferToBoolean(role.attributes.InternalUserManagement) ? 1 : 0,
                        AssignVendor: bufferToBoolean(role.attributes.AssignVendor) ? 1 : 0,
                        VendorClassification: bufferToBoolean(role.attributes.VendorClassification) ? 1 : 0,
                        Reporting: bufferToBoolean(role.attributes.Reporting) ? 1 : 0,
                        AddViewOrder: bufferToBoolean(role.attributes.AddViewOrder) ? 1 : 0,
                        VendorRatingSetting: bufferToBoolean(role.attributes.VendorRatingSetting) ? 1 : 0,
                        FeeApproval: bufferToBoolean(role.attributes.FeeApproval) ? 1 : 0,
                        VendorApproval: bufferToBoolean(role.attributes.VendorApproval) ? 1 : 0,
                        ServiceConfigurationApproval: bufferToBoolean(role.attributes.ServiceConfigurationApproval) ? 1 : 0,
                        VendorCredentialsDocumentApproval: bufferToBoolean(role.attributes.VendorCredentialsDocumentApproval) ? 1 : 0,
                        SignedDocumentApproval: bufferToBoolean(role.attributes.SignedDocumentApproval) ? 1 : 0,
                        ChangeFeeOnClosedOrders: bufferToBoolean(role.attributes.ChangeFeeOnClosedOrders) ? 1 : 0,
                        DisableNewOrders: bufferToBoolean(role.attributes.DisableNewOrders) ? 1 : 0,
                        AutoOrders: bufferToBoolean(role.attributes.AutoOrders) ? 1 : 0,
                        IssueApproval: bufferToBoolean(role.attributes.IssueApproval) ? 1 : 0,
                        IssueReporting: bufferToBoolean(role.attributes.IssueReporting) ? 1 : 0,
                        UserProfileSetting: bufferToBoolean(role.attributes.UserProfileSetting) ? 1 : 0,
                        FeeRequest: bufferToBoolean(role.attributes.FeeRequest) ? 1 : 0
                    };

                    userRoles.push(userRole);
                });

                reply(userRoles);
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    updateRolePermissions(request, reply) {
        const { data } = request.payload;
        const response = {
            isSuccess: false,
            failure: ""
        };

        data.map((item) => {
            RolePermission.where({ RoleId: item.RoleId }).save(
                item, { method: "update" }).then((result) => {
                    if (result !== null) {
                        response.isSuccess = true;
                    }
                }).catch((error) => {
                    response.failure = Boom.badRequest(error);
                });
        });

        reply(response);
    }

    getConsoleStaffUser(request, reply) {
        const { page, itemPerPage, fullName } = request.query;
        const rawsSql = `call GetConsoleStaffUser('${fullName}')`;

        Bookshelf.knex.raw(rawsSql)
            .then((result) => {
                if (result !== null) {
                    const rolePermissions = result[0][0];
                    const resultRolePermis = [];

                    rolePermissions.forEach((item) => {
                        let isAdded = false;
                        resultRolePermis.forEach((role) => {
                            if (item.UsersId === role.usersId) {
                                isAdded = true;

                                switch (item.RoleName) {
                                    case "Admin":
                                        role.admin = true;
                                        break;
                                    case "Operational Manager":
                                        role.manager = true;
                                        break;
                                    case "Content Manager":
                                        role.contentManager = true;
                                        break;
                                    case "Training Manager":
                                        role.trainingManager = true;
                                        break;
                                    case "Accounting Manager":
                                        role.accountingManager = true;
                                        break;
                                    case "Scheduler":
                                        role.scheduler = true;
                                        break;
                                    case "Status":
                                        role.status = true;
                                        break;
                                    case "Quality Control":
                                        role.qualityControl = true;
                                        break;
                                    case "Sales Rep":
                                        role.salesRep = true;
                                        break;
                                    default:
                                        break;
                                }
                                role.roles.push({
                                    roleName: item.RoleName,
                                    roleId: item.RoleId
                                });
                            }
                        });
                        if (!isAdded) {
                            const tempRole = {
                                usersId: "",
                                name: "",
                                admin: false,
                                manager: false,
                                contentManager: false,
                                trainingManager: false,
                                scheduler: false,
                                status: false,
                                qualityControl: false,
                                salesRep: false,
                                accountingManager: false,
                                roles: []
                            };

                            tempRole.usersId = item.UsersId;
                            tempRole.name = item.FullName;
                            tempRole.admin = (item.RoleName === "Admin");
                            tempRole.manager = (item.RoleName === "Operational Manager");
                            tempRole.contentManager = (item.RoleName === "Content Manager");
                            tempRole.trainingManager = (item.RoleName === "Training Manager");
                            tempRole.accountingManager = (item.RoleName === "Accounting Manager");
                            tempRole.scheduler = (item.RoleName === "Scheduler");
                            tempRole.status = (item.RoleName === "Status");
                            tempRole.qualityControl = (item.RoleName === "Quality Control");
                            tempRole.salesRep = (item.RoleName === "Sales Rep");
                            tempRole.roles.push({
                                roleName: item.RoleName,
                                roleId: item.RoleId
                            });
                            resultRolePermis.push(tempRole);
                        }
                    });

                    const response = resultRolePermis.slice((page - 1) * itemPerPage, page * itemPerPage);
                    reply({
                        response,
                        rolePermissions,
                        totalRecords: resultRolePermis.length
                    });
                }
            });
    }
}

export default new RolePermissionController();
import RolePermissionController from "./role-permission-controller";

const routes = [{
    path: "/rolePermission/getRolePermissions",
    method: "GET",
    config: { auth: false },
    handler: RolePermissionController.getRolePermission
},
{
    path: "/rolePermission/getConsoleStaffUser",
    method: "GET",
    config: { auth: false },
    handler: RolePermissionController.getConsoleStaffUser
},
{
    path: "/rolePermission/updateRolePermissions",
    method: "PUT",
    config: { auth: false },
    handler: RolePermissionController.updateRolePermissions
}];

export default routes;
import BranchController from "./branch-controller";
import BranchManagemetController from "./branch-management-controller";

const routes = [{
    path: "/branch/getBranchesForDropdown",
    method: "GET",
    config: { auth: false },
    handler: BranchController.getBranchesForDropdown
}, {
    path: "/branch/lockBranch",
    method: "GET",
    config: { auth: false },
    handler: BranchController.lockBranch
},
{
    path: "/branch/getAllBranch",
    method: "GET",
    config: { auth: false },
    handler: BranchManagemetController.getAllBranch
},
{
    path: "/branch/getBranchNameByKeyword",
    method: "GET",
    config: { auth: false },
    handler: BranchController.getBranchNameByKeyword
},
{
    path: "/branch/getBranchManagementData",
    method: "POST",
    config: { auth: false },
    handler: BranchController.getBranchManagementData
},
{
    path: "/branch/updateBranch",
    method: "POST",
    config: { auth: false },
    handler: BranchController.updateBranch
}];

export default routes;
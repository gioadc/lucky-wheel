import Branch from "../../db/model/branches";
import Bookshelf from "../../db/database";
import Boom from "boom";
import Broker from "../../db/model/brokers";
import { handleSingleQuote } from "../../helper/common-helper";

class BranchController {
	constructor() { }

	getBranchesForDropdown(request, reply) {
		new Branch().fetchAll({ columns: ["BranchID", "BranchName"] }).then((result) => {
			if (result !== null) {
				reply(result);
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return;
	}

	getBranchNameByKeyword(request, reply) {
        const { GID, searchText, selectedValues, limit } = request.query;

        const selectedValuesStr = selectedValues ? `AND Company NOT IN (${selectedValues})` : "";

		const rawSql = `SELECT BrokerID, Company FROM broker WHERE (Company LIKE '%${searchText}%' AND GID = '${GID}') ${selectedValuesStr} ORDER BY BrokerID LIMIT ${limit};`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                if (result !== null) {
                    reply({ isSuccess: true, sources: result[0] });
                }

                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return reply;
            });
    }

	lockBranch(request, reply) {
		const branchId = request.query;

		Branch.where(branchId).save({ Inactive: true }, { method: "update" }).then((result) => {
			if (result !== null) {
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	getBranchManagementData(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			brokerID,
			company,
			contactFirst,
			contactLast,
			GID
		} = request.payload;

		const getClients = Promise.resolve(Bookshelf.knex.raw(
			`call GetBranches('${sortColumn}',${sortDirection},${page},
			${itemPerPage},'${brokerID}','${handleSingleQuote(company)}','${handleSingleQuote(contactFirst)}','${handleSingleQuote(contactLast)}','${GID}')`));

		Promise.all([getClients])
			.then(values => {
				const data = {};

				if (values !== null) {
					values.forEach((item) => {
						if (item !== null) {
							data.listBranch = {
								branches: item[0][0],
								totalRecords: item[0][1][0].TotalRecords
							};
						}
					});
				}
				reply(data);
			}).catch(err => {
				reply(Boom.badRequest(err));
			});

		return reply;
	}

	updateBranch(request, reply) {
        const broker = request.payload;

        Broker.where({ BrokerId: broker.BrokerId }).save(broker, { method: "update" }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

}

export default new BranchController();
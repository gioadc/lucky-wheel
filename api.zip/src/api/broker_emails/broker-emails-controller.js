import Boom from "boom";
import Bookshelf from "../../db/database";
import BrokerEmails from "../../db/model/broker-emails";

class BrokerEmailsController {
    constructor() { }

    addCcEmail(request, reply) {
        const ccEmail = request.payload;

        new BrokerEmails().save(ccEmail,
            { method: "insert" }).then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    deleteCcEmail(request, reply) {
		const BrokerEmailId = request.query;

		BrokerEmails.where(BrokerEmailId).destroy().then((result) => {
			if (result !== null) {
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return reply;
    }
    
    updateCcEmail(request, reply) {
        const ccEmail = request.payload;
        BrokerEmails.where({ BrokerEmailId: ccEmail.BrokerEmailId }).save(ccEmail, { method: "update" }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
}

export default new BrokerEmailsController();
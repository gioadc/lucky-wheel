import BrokerEmailsController from "./broker-emails-controller";

const routes = [{
    path: "/broker-emails/addCcEmail",
    method: "POST",
    config: { auth: false },
    handler: BrokerEmailsController.addCcEmail
},
{
    path: "/broker-emails/deleteCcEmail",
    method: "GET",
    config: { auth: false },
    handler: BrokerEmailsController.deleteCcEmail
},
{
    path: "/broker-emails/updateCcEmail",
    method: "POST",
    config: { auth: false },
    handler: BrokerEmailsController.updateCcEmail
}];

export default routes;
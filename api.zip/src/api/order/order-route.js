import OrderController from "./order-controller";
import OrderFeeController from "./order-fee-controller";
import OrderCollectController from "./order-collect-controller";
import OrderStatusController from "./order-status-controller";
import OrderSpecController from "./order-spec-controller";
import OrderClientController from "./order-client-controller";
import OrderCustomerController from "./order-customer-controller";
import OrderDateController from "./order-date-controller";
import OrderDocController from "./order-docs-controller";
import OrderFeeApproveController from "./order-fee-approve-controller";

const routes = [{
    path: "/order/getOrders",
    method: "GET",
    config: { auth: false },
    handler: OrderController.getOrders
},
{
    path: "/order/getOrdersFeeData",
    method: "GET",
    config: { auth: false },
    handler: OrderFeeController.getOrdersFeeData
},
{
    path: "/order/getInitData",
    method: "GET",
    config: { auth: false },
    handler: OrderController.getInitDataForViewOrders
},
{
    path: "/order/getOrderStatusInitData",
    method: "GET",
    config: { auth: false },
    handler: OrderStatusController.getInitDataForOrderStatus
},
{
    path: "/order/getOrderCollect",
    method: "GET",
    config: { auth: false },
    handler: OrderCollectController.getOrderCollectById
},
{
    path: "/order/deleteOrderFee",
    method: "DELETE",
    config: { auth: false },
    handler: OrderFeeController.deleteOrderFee
},
{
    path: "/order/getOrderFee",
    method: "GET",
    config: { auth: false },
    handler: OrderFeeController.getOrderFee
},
{
    path: "/order/addOrderFee",
    method: "POST",
    config: { auth: false },
    handler: OrderFeeController.addOrderFee
},
{
    path: "/order/getOrderStatusProgressLog",
    method: "GET",
    config: { auth: false },
    handler: OrderStatusController.getOrderStatusProgressLog
},
{
    path: "/order/getOrderSpecificsData",
    method: "GET",
    config: { auth: false },
    handler: OrderSpecController.getOrderSpecificsData
},
{
    path: "/order/addOrderRequestedFee",
    method: "POST",
    config: { auth: false },
    handler: OrderFeeController.addOrderRequestedFee
},
{
    path: "/order/getOrderRequestedFee",
    method: "GET",
    config: { auth: false },
    handler: OrderFeeController.getOrderRequestedFee
},
{
    path: "/order/updateOrderRequestedFee",
    method: "POST",
    config: { auth: false },
    handler: OrderFeeController.updateOrderRequestedFee
},
{
    path: "/order/processRequestFee",
    method: "POST",
    config: { auth: false },
    handler: OrderFeeController.processRequestFee
},
{
    path: "/order/getOrderClientDropdownDataByClientId",
    method: "GET",
    config: { auth: false },
    handler: OrderClientController.getOrderClientBranchDropdownDataByClientId
},
{
    path: "/order/getOrderClientAgentData",
    method: "GET",
    config: { auth: false },
    handler: OrderClientController.getOrderClientAgentData
},
{
    path: "/order/getOrderClientById",
    method: "GET",
    config: { auth: false },
    handler: OrderClientController.getOrderClientById
},
{
    path: "/order/getInitDataForOrderCustomer",
    method: "GET",
    config: { auth: false },
    handler: OrderCustomerController.getInitDataForOrderDetailCustomer
},
{
    path: "/order/getOrderDatesById",
    method: "GET",
    config: { auth: false },
    handler: OrderDateController.getOrderDate
},
{
    path: "/order/updateOrderDetailStatus",
    method: "POST",
    config: { auth: false },
    handler: OrderStatusController.updatOrderStatus
},
{
    path: "/order/updateOrderDetailClient",
    method: "POST",
    config: { auth: false },
    handler: OrderClientController.updateOrderDetailClient
},
{
    path: "/order/updateOrderDetailCustomer",
    method: "POST",
    config: { auth: false },
    handler: OrderCustomerController.updateOrderDetailCustomer
},
{
    path: "/order/addOrder",
    method: "POST",
    config: { auth: false },
    handler: OrderController.addOrder
},
{
    path: "/order/updateOrderDate",
    method: "POST",
    config: { auth: false },
    handler: OrderDateController.updateOrderDate
},
{
    path: "/order/getDefaultDataForOrderDetailHeader",
    method: "GET",
    config: { auth: false },
    handler: OrderController.getDefaultDataForOrderDetailHeader
},
{
    path: "/order/updateOrderSpecific",
    method: "POST",
    config: { auth: false },
    handler: OrderSpecController.updateOrderSpecific
},
{
    path: "/order/getListCustomerByBrokerId",
    method: "GET",
    config: { auth: false },
    handler: OrderStatusController.getListCustomerByBrokerId
},
{
    path: "/order/getOrderDetailProductTypeByCustomerId",
    method: "GET",
    config: { auth: false },
    handler: OrderStatusController.getOrderDetailProductTypeByCustomerId
},
{
    path: "/order/getOrderDocsByOrderId",
    method: "GET",
    config: { auth: false },
    handler: OrderDocController.getOrderDoc
},
{
    path: "/order/getInitRequiredTabForOrderDetail",
    method: "GET",
    config: { auth: false },
    handler: OrderController.getInitRequiredTabForOrderDetail
},
{
    path: "/order/getOrdersFeeApproveData",
    method: "GET",
    config: { auth: false },
    handler: OrderFeeApproveController.getOrdersFeeApproveData
},
{
    path: "/order/checkInCompleteOrder",
    method: "GET",
    config: { auth: false },
    handler: OrderController.checkInCompleteOrder
},
{
    path: "/order/removeInCompleteOrder",
    method: "GET",
    config: { auth: false },
    handler: OrderController.removeInCompleteOrder
},
{
    path: "/order/changeOrderFeeApproveStatus",
    method: "POST",
    config: { auth: false },
    handler: OrderFeeApproveController.changeOrderFeeApproveStatus
},
{
    path: "/order/setActiveOrder",
    method: "GET",
    config: { auth: false },
    handler: OrderController.setActiveOrder
},
{
    path: "/order/setCurrentTabOfInCompleteOrder",
    method: "GET",
    config: { auth: false },
    handler: OrderController.setCurrentTabOfInCompleteOrder
},
{
    path: "/order/getDocGrid",
    method: "GET",
    config: { auth: false },
    handler: OrderDocController.getDocGrid
},
{
    path: "/order/getDocGridMultiple",
    method: "GET",
    config: { auth: false },
    handler: OrderDocController.getDocGridMultiple
},
{
    path: "/order/insertOrderDoc",
    method: "POST",
    config: { auth: false },
    handler: OrderDocController.insertOrderDoc
},
{
    path: "/order/updateOrderDoc",
    method: "POST",
    config: { auth: false },
    handler: OrderDocController.updateOrderDoc
},
{
    path: "/order/downloadOrderDoc",
    method: "GET",
    config: {
        auth: false
    },
    handler: OrderDocController.downloadOrderDoc
}
];

export default routes;
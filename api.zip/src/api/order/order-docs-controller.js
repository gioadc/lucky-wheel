import Boom from "boom";
import Bookshelf from "./../../db/database";
import moment from "moment";
import { isBuffer, bufferToBoolean } from "../../helper/common-helper";
import OrderDocs from "../../db/model/order-docs";
import { UPLOAD_PATH } from "../../helper/file-helper";
import fs from "fs";

class OrderDocController {
    constructor() { }

    getOrderDoc(request, reply) {
        const {
            orderId
        } = request.query;

        Bookshelf.knex.raw(`select * from order_docs where OrderId = (${orderId})`)
            .then((result) => {
                if (result !== null) {
                    reply({
                        data: result[0]
                    });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    getDocGrid(request, reply) {
        const {
			sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderId,
            docType
		} = request.query;

        const rawSql = `call GetDocGrid('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId}, ${docType})`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    let data = result[0][0];

                    result[0][0].forEach((item) => {

                        item.Viewed = bufferToBoolean(item.Viewed);
                        item.UploadedDate = item.UploadedDate === null ? null : moment(item.UploadedDate).format("MM/DD/YY hh:mm:ss A");
                        item.DownloadDate = item.UploadedDate === null ? null : moment(item.UploadedDate).format("MM/DD/YY hh:mm:ss A");
                        item.ReviewDate = item.ReviewDate === null ? null : moment(item.ReviewDate).format("MM/DD/YY hh:mm:ss A");
                    });
                    let obj = { data }
                    obj['totalRecords' + docType] = result[0][1][0].TotalRecords;
                    reply(obj);

                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));

                return;
            });

        return reply;
    }


    getDocGridMultiple(request, reply) {
        const {
			sortColumn,
            sortDirection,
            page,
            itemPerPage,
            orderId
        } = request.query;
        const rawSql1 = Promise.resolve(Bookshelf.knex.raw(`call GetDocGrid('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId}, ${1})`));
        const rawSql2 = Promise.resolve(Bookshelf.knex.raw(`call GetDocGrid('${sortColumn}', ${sortDirection}, ${page}, ${itemPerPage}, ${orderId}, ${2})`));
        Promise.all([rawSql1, rawSql2])
            .then(value => {
                const result = {};
                if (value !== null) {
                    // reply(value);
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    item[0][0].forEach((item) => {

                                        item.Viewed = bufferToBoolean(item.Viewed);
                                        item.UploadedDate = item.UploadedDate === null ? null : moment(item.UploadedDate).format("MM/DD/YY hh:mm:ss A");
                                        item.DownloadDate = item.UploadedDate === null ? null : moment(item.UploadedDate).format("MM/DD/YY hh:mm:ss A");
                                        item.ReviewDate = item.ReviewDate === null ? null : moment(item.ReviewDate).format("MM/DD/YY hh:mm:ss A");
                                    });

                                    result.data1 = item[0][0];
                                    result.totalRecords1 = item[0][1][0].TotalRecords;

                                    break;
                                case 1:
                                    item[0][0].forEach((item) => {

                                        item.Viewed = bufferToBoolean(item.Viewed);
                                        item.UploadedDate = item.UploadedDate === null ? null : moment(item.UploadedDate).format("MM/DD/YY hh:mm:ss A");
                                        item.DownloadDate = item.UploadedDate === null ? null : moment(item.UploadedDate).format("MM/DD/YY hh:mm:ss A");
                                        item.ReviewDate = item.ReviewDate === null ? null : moment(item.ReviewDate).format("MM/DD/YY hh:mm:ss A");
                                    });

                                    result.data2 = item[0][0];
                                    result.totalRecords2 = item[0][1][0].TotalRecords;
                            }
                        }
                    });
                }
                reply(result);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    insertOrderDoc(request, reply) {
        const data = request.payload;
        const newOrderDoc = new OrderDocs();
        newOrderDoc.save({
            OrderId: data.OrderId,
            TenantId: data.TenantId,
            Description: data.Description,
            DocumentType: data.DocumentType,
            // UserId: data.UserId,
            
            UploadedDate: moment().format("YYYY-MM-DD HH:mm:ss")
        }, { method: "insert" }).then(() => {
            reply(1);
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    updateOrderDoc(request, reply) {
		let data = request.payload;
		OrderDocs.where({ DocId: data.DocId }).save(
			data
			, { method: "update" }).then((result) => {
				if (result !== null) {
					reply({ isSuccess: true });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
    }
    
    downloadOrderDoc(request, reply) {
		const { docId } = request.query;
		OrderDocs.where({ docId }).fetch({ columns: ["OrderId", "Description"] }).then((orderDoc) => {
			const orderId = orderDoc.get("OrderId");
			const docName = orderDoc.get("Description");
			// const fileName = `${docName}`;
			const filePath = `${UPLOAD_PATH}/orderDocs/${orderId}/${docName}`;
			fs.readFile(filePath, (err, data) => {
				if (err) throw err;
				return reply(data)
					.header("content-disposition", `attachment; filename=${docName}`);
			});
		}).catch((error) => reply(Boom.badRequest(error)));
	}
};


export default new OrderDocController();
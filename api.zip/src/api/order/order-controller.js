import Boom from "boom";
import Bookshelf from "./../../db/database";
import Order from "./../../db/model/order";
import moment from "moment";
import { handleSingleQuote } from "./../../helper/common-helper";
import OrderDocs from "./../../db/model/order-docs";
import OrderFee from "./../../db/model/order-fee";
import OrderFeeApprove from "./../../db/model/order-fee-approve";
import OrderLog from "./../../db/model/order-log";
import OrderProblem from "./../../db/model/order-problem";
import OrderProgressLog from "./../../db/model/order-progress-log";
import OrderRefund from "./../../db/model/order-refund";
import OrderStats from "./../../db/model/order-stats";
import SignersApproval from "./../../db/model/signers-approval";

class OrderController {
    constructor() { }

    getInitDataForViewOrders(request, reply) {
        const getInitDataDrop = Promise.resolve(Bookshelf.knex.raw(`call getDataInitForViewOrders();`));
        const getDataSearch = Promise.resolve(Bookshelf.knex.raw(`call ViewOrders(null,'','','',null,null,null,'','','\`Order Date\`',false,1,25);`));

        Promise.all([getInitDataDrop, getDataSearch])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.companyBranch = item[0][0];
                                    data.progress = item[0][1];
                                    break;
                                case 1:
                                    data.data = item[0][0];
                                    data.totalRecords = item[0][1][0].TotalRecords;
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
        return reply;
    }

    getOrders(request, reply) {
        const {
            orderID,
            vendorLastName,
            borrLastName,
            companyBranch,
            apptDate,
            fromDate,
            toDate,
            loanAgent,
            statusOrder,
            sortColumn,
            sortDirection,
            page,
            itemPerPage
        } = request.query;

        const rawSql = `call ViewOrders(
            ${orderID === undefined ? null : `${orderID}`},
            '${handleSingleQuote(vendorLastName)}',
            '${handleSingleQuote(borrLastName)}',
            '${companyBranch}',
            ${apptDate === undefined ? null : `'${apptDate}'`},
            ${fromDate === undefined ? null : `'${fromDate}'`},
            ${toDate === undefined ? null : `'${toDate}'`},
            '${handleSingleQuote(loanAgent)}',
            ${statusOrder === undefined ? null : `'${statusOrder}'`},
            '\`${sortColumn}\`',
            ${sortDirection},
            ${page},
            ${itemPerPage} 
        );`;

        Bookshelf.knex.raw(rawSql)
            .then((result) => {
                if (result !== null) {
                    reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
                }
                return reply;
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return reply;
            });
    }

    // add new order and return orderid
    addOrder(request, reply) {
        const newOrder = new Order();

        newOrder.save({
            OrderDate: moment().format("YYYY-MM-DD HH:mm:ss")
        }, { method: "insert" }).then((result) => {
            if (result && result.attributes) {
                const orderId = result.attributes.id;
                reply({ orderId, isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

        return reply;
    }

    getInitRequiredTabForOrderDetail(request, reply) {
        const { orderId } = request.query;
        const rawSql = `SELECT o.BrokerId, o.AgentId, o.Zip from \`order\` o where o.OrderId = ${orderId};`;

        Bookshelf.knex.raw(rawSql)
            .then(result => {
                const data = {
                    isValidStatusTab: false,
                    isValidClientTab: false,
                    isValidCustomerTab: false
                };

                if (result[0][0]) {
                    if (result[0][0].BrokerId) data.isValidStatusTab = true;
                    if (result[0][0].AgentId) data.isValidClientTab = true;
                    if (result[0][0].Zip) data.isValidCustomerTab = true;
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getDefaultDataForOrderDetailHeader(request, reply) {
        const { orderId } = request.query;
        const getClientData = Promise.resolve(Bookshelf.knex.raw(`select a.AgentId, b.Company, a.FullName, a.Direct, a.Ext, a.AfterhoursPhone, a.Email 
            from \`order\` o left join broker b on o.BrokerId = b.BrokerID left join agent a on a.AgentId = o.AgentId
            where o.OrderId = ${orderId};`
        ));
        const getCustomerData = Promise.resolve(Bookshelf.knex.raw(`select o.FirstName, o.LastName, o.City, o.State, o.HomePhone, o.AptDateTime, o.Email from \`order\` o where o.OrderId = ${orderId};`));
        const getSignerData = Promise.resolve(Bookshelf.knex.raw(`select s.FirstName, s.HomePhone, s.WorkPhone, s.Ext, s.Mobile, s.Email from \`order\` o left join signer s on o.SignerId = s.SignerId where o.OrderId = ${orderId};`));

        Promise.all([getClientData, getCustomerData, getSignerData])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.client = item[0];
                                    break;
                                case 1:
                                    data.customer = item[0];
                                    break;
                                case 2:
                                    data.signer = item[0];
                                    break;
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    checkInCompleteOrder(request, reply) {
        const { userId } = request.query;
        const rawSql = `select distinct o.OrderId, o.CurrentTab from \`order\` o where o.IsActive = false and o.CreatedBy = ${userId};`;

        Bookshelf.knex.raw(rawSql)
            .then(value => {
                if (value !== null) {
                    const result = value[0];
                    if (result.length === 0) {
                        reply({ hasInCompleteOrder: false });
                    } else {
                        reply({ hasInCompleteOrder: true, orderData: result[0] });
                    }
                } else {
                    reply({ hasInCompleteOrder: false });
                }
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    removeInCompleteOrder(request, reply) {
        const { orderId } = request.query;
        const removeOrderDocs = Promise.resolve(OrderDocs.where({ OrderId: orderId }).destroy());
        const removeOrderFee = Promise.resolve(OrderFee.where({ OrderId: orderId }).destroy());
        const removeOrderFeeApprove = Promise.resolve(OrderFeeApprove.where({ OrderId: orderId }).destroy());
        const removeOrderLog = Promise.resolve(OrderLog.where({ OrderId: orderId }).destroy());
        const removeOrderProblem = Promise.resolve(OrderProblem.where({ OrderId: orderId }).destroy());
        const removeOrderProgressLog = Promise.resolve(OrderProgressLog.where({ OrderId: orderId }).destroy());
        const removeOrderRefund = Promise.resolve(OrderRefund.where({ OrderId: orderId }).destroy());
        const removeOrderStats = Promise.resolve(OrderStats.where({ OrderId: orderId }).destroy());
        const removeSignerApprove = Promise.resolve(SignersApproval.where({ OrderId: orderId }).destroy());

        Promise.all([
            removeOrderDocs,
            removeOrderFee,
            removeOrderFeeApprove,
            removeOrderLog,
            removeOrderProblem,
            removeOrderProgressLog,
            removeOrderRefund,
            removeOrderStats,
            removeSignerApprove
        ]).then(() => {
                Order.where({ OrderId: orderId }).destroy()
                    .then(() => {
                        reply({ isSucces: true });
                    }).catch((err) => {
                        reply(Boom.badRequest(err));
                    });
            }).catch((err) => {
                reply(Boom.badRequest(err));
            });
    }

    setActiveOrder(request, reply) {
        const { orderId } = request.query;

        Order.where({ OrderId: orderId }).save({ IsActive: true }, { method: "update" })
            .then(() => {
                reply({ isSuccess: true });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    setCurrentTabOfInCompleteOrder(request, reply) {
        const {orderId, currentTab} = request.query;

        Order.where({ OrderId: orderId }).save({ CurrentTab: currentTab }, { method: "update" })
            .then(() => {
                reply({ isSuccess: true });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }
}

export default new OrderController();

import Boom from "boom";
import Bookshelf from "./../../db/database";
import Order from "./../../db/model/order";

class OrderStatusController {
    constructor() { }

    getOrderStatusProgressLog(request, reply) {
        const { orderId, sortColumn, sortDirection, page, itemPerPage, accountId } = request.query;
        const rawSql = `call getOrderProgressLog(${orderId}, "${sortColumn}", ${sortDirection}, ${page}, ${itemPerPage}, ${accountId});`;

        Bookshelf.knex.raw(rawSql).then(result => {
            if (result !== null) {
                reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
            }

            return reply;
        }).catch((error) => {
            reply(Boom.badRequest(error));

            return reply;
        });
    }

    getInitDataForOrderStatus(request, reply) {
        const { orderId, accountId } = request.query;
        const getOrderStatusById = Promise.resolve(Bookshelf.knex.raw(`call getOrderDetailtStatus(${orderId});`));
        const getOrderStatusDataDropDown = Promise.resolve(Bookshelf.knex.raw(`call getOrderStatusDropDownData();`));
        const getOrderStatusProgressLog = Promise.resolve(Bookshelf.knex.raw(`call getOrderProgressLog(${orderId}, "DateLog", 0, 1, 25, ${accountId});`));

        Promise.all([getOrderStatusById, getOrderStatusDataDropDown, getOrderStatusProgressLog])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.orderStatus = item[0][0][0];
                                    break;
                                case 1:
                                    data.initData = {
                                        progress: item[0][0],
                                        deliveryMethod: item[0][1],
                                        staffId: item[0][2],
                                        productType: item[0][3],
                                        defaultProgressSelect: item[0][4][0].defaultProgressSelect
                                    };
                                    break;
                                case 2:
                                    data.listProgressLog = {
                                        data: item[0][0],
                                        totalRecords: item[0][1][0].TotalRecords
                                    };
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });

        return reply;
    }

    updatOrderStatus(request, reply) {
        const orderStatus = request.payload;

        const updateOrderStatus = {
            DocDelMethod: orderStatus.deliveryMethod,
            RepId: orderStatus.repId,
            Filledby: orderStatus.filledBy,
            BrokerIdNum: orderStatus.referenceNumber,
            TrackingNumber: orderStatus.trackingNumber,
            CourierAcntNumber: orderStatus.courierAccountNumber,
            TrackingNumber2: orderStatus.additionalTrackingNumber,
            FaxBackReq: orderStatus.faxBackRequired,
            LoanType: orderStatus.LoanType,
            ProgressId: orderStatus.ProgressId,
            Service: orderStatus.Service,
            CustomerId: orderStatus.CustomerId,
            BrokerId: orderStatus.BrokerId
        };

        if (orderStatus.CreatedBy) updateOrderStatus.CreatedBy = orderStatus.CreatedBy;

        Order.where({ OrderId: orderStatus.OrderId })
            .save(updateOrderStatus, { method: "update" }).then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                }
            }).catch((error) => {
                reply(JSON.stringify(error));
            });
    }

    getListCustomerByBrokerId(request, reply) {
        const { BrokerId } = request.query;

        const getOrderStatusCustomerByClientId = Promise.resolve(Bookshelf.knex.raw(`select c.CustomerId, c.Email, c.Name from customers c where c.BrokerId = ${BrokerId} and c.IsActive = true;`));
        const getTotalRecordsOrderStatusCustomerByClientId = Promise.resolve(Bookshelf.knex.raw(`select count(c.CustomerId) as totalRecords from  customers c where c.BrokerId = ${BrokerId};`));

        Promise.all([getOrderStatusCustomerByClientId, getTotalRecordsOrderStatusCustomerByClientId])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.data = item[0];
                                    break;
                                case 1:
                                    data.totalRecords = item[0][0].totalRecords;
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getOrderDetailProductTypeByCustomerId(request, reply) {
        const { customerId } = request.query;
        let rawSql = ``;

        if (customerId === `0`) {
            rawSql = `select l.LoanType, l.LoanTypeId from loan_type l;`;
        } else {
            rawSql = `select l.LoanType, l.LoanTypeId from customer_product_type cpt join loan_type l on cpt.ProductType = l.LoanTypeId where cpt.CustomerId = ${customerId};`;
        }

        Bookshelf.knex.raw(rawSql)
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.listProductType = item;
                                    break;
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }
}

export default new OrderStatusController();
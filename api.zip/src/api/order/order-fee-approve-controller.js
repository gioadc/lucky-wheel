import Boom from "boom";
import Bookshelf from "../../db/database";
import { handleSingleQuote } from "../../helper/common-helper";

class OrderFeeApproveController {
    constructor() { }

    // Get all data for Order Detail Fee screen
    getOrdersFeeApproveData(request, reply) {
        const { sortColumn, sortDirection, page, itemPerPage, orderId, feeApproved } = request.query;
        const rawQuery = `call GetOrderFeeApproveGridView('${sortColumn}', ${sortDirection === "true" ? 1 : 0}, ${page}, ${itemPerPage}, ${orderId !== undefined && orderId !== "" ? handleSingleQuote(orderId) : null}, ${feeApproved ? `'${feeApproved}'` : null})`;
        console.log(rawQuery);

        Bookshelf.knex.raw(rawQuery)
            .then(result => {

                if (result === null || !result[0] || !result[0][0]) {
                    reply({isSuccess: false});
                    return;
                }

                const datasources = result[0][0];
                const totalRecords = result[0][1][0];

                reply({isSuccess: true, datasources, totalRecords: totalRecords.TotalRecords });
                return;
            }).catch(err => {
                reply(Boom.badRequest(err));
                return;
            });
    }

    changeOrderFeeApproveStatus(request, reply) {
        const { feeApprovalId, feeApproved, offerStatus, orderId, signerId, userId, offerAmount } = request.payload;
        const rawQuery = `call ChangeOrderFeeApproveStatus(${feeApprovalId}, '${feeApproved}', '${offerStatus}', ${orderId}, ${signerId}, ${userId})`;

        Bookshelf.knex.raw(rawQuery)
            .then(result => {
                const data = Array.isArray(result[0]) ? { isSuccess: false } : result[0][0];
                
                reply(data);
                return;
            }).catch(err => {
                reply(Boom.badRequest(err));
                return;
            });

    }

}

export default new OrderFeeApproveController();
import Boom from "boom";
import Bookshelf from "./../../db/database";
import Order from "./../../db/model/order";
import moment from "moment";

class OrderCustomerController {
    getInitDataForOrderDetailCustomer(request, reply) {
        const { orderId } = request.query;
        const getListLoanType = Promise.resolve(Bookshelf.knex.raw(`select lt.LoanTypeId, lt.LoanType from loan_type lt;`));
        const getListLanguage = Promise.resolve(Bookshelf.knex.raw(`select l.LanguageID, l.Language from \`language\` l;`));
        const getDefaultOrderCustomer = Promise.resolve(Bookshelf.knex.raw(
            `select o.OrderId, o.BrokerIdNum, o.LoanType, o.IsNonBorrowingSpouse, o.NonBorrowingSpouseFirst, o.NonBorrowingSpouseLast, o.FirstName, o.LastName, o.HomePhone, o.WorkPhone, o.BoWrkext,
		    o.CellPhone, o.CoFirstName, o.CoLastName, o.CoHomePhone, o.CoWorkPhone, o.CoBoWrkext, o.CoCellPhone, o.Address, o.City, o.State, o.Zip, o.AptDateTime, o.LanguageId, o.Email
            from \`order\` o where o.OrderId = ${orderId};`
        ));
        const getListState = Promise.resolve(Bookshelf.knex.raw(`SELECT s.Code, s.Description FROM state s;`));

        Promise.all([getListLoanType, getListLanguage, getDefaultOrderCustomer, getListState])
            .then(value => {
                const data = {};

                if (value !== null) {
                    value.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.listLoanType = item[0];
                                    break;
                                case 1:
                                    data.listLanguage = item[0];
                                    break;
                                case 2:
                                    data.orderCustomerValue = item[0][0];
                                    break;
                                case 3:
                                    data.listState = item[0];
                            }
                        }
                    });
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    updateOrderDetailCustomer(request, reply) {
        const orderDetailCustomer = request.payload;

        const newOrderCustomer = {
            Address: orderDetailCustomer.Address,
            AptDateTime: moment(orderDetailCustomer.AptDateTime).format("YYYY-MM-DD HH:mm:ss").toString(),
            BoWrkext: orderDetailCustomer.BoWrkext,
            BrokerIdNum: orderDetailCustomer.BrokerIdNum,
            CellPhone: orderDetailCustomer.CellPhone,
            City: orderDetailCustomer.City,
            CoBoWrkext: orderDetailCustomer.CoBoWrkext,
            CoCellPhone: orderDetailCustomer.CoCellPhone,
            CoFirstName: orderDetailCustomer.CoFirstName,
            CoHomePhone: orderDetailCustomer.CoHomePhone,
            CoLastName: orderDetailCustomer.CoLastName,
            CoWorkPhone: orderDetailCustomer.CoWorkPhone,
            FirstName: orderDetailCustomer.FirstName,
            HomePhone: orderDetailCustomer.HomePhone,
            IsNonBorrowingSpouse: orderDetailCustomer.IsNonBorrowingSpouse,
            LanguageId: orderDetailCustomer.LanguageId,
            LastName: orderDetailCustomer.LastName,
            LoanType: orderDetailCustomer.LoanType,
            NonBorrowingSpouseFirst: orderDetailCustomer.NonBorrowingSpouseFirst,
            NonBorrowingSpouseLast: orderDetailCustomer.NonBorrowingSpouseLast,
            State: orderDetailCustomer.State,
            WorkPhone: orderDetailCustomer.WorkPhone,
            Zip: orderDetailCustomer.Zip,
            Email: orderDetailCustomer.Email
        };

        Order.where({ OrderId: orderDetailCustomer.OrderId })
        .save(newOrderCustomer, { method: "update" })
        .then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });

    return reply;
    }
}

export default new OrderCustomerController();
import Boom from "boom";
import Bookshelf from "../../db/database";

class OrderCollectController {
    constructor() { }

    getOrderCollectById(request, reply) {
        const { orderId } = request.query;

        Bookshelf.knex.raw(`call GetOrderCollectById(${orderId})`)
        .then((result) => {
            if (result !== null) {
                reply({
                    data: result[0][0][0]
                });
                return;
            }
        })
        .catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
	}

}

export default new OrderCollectController();
import Boom from "boom";
import Bookshelf from "../../db/database";
import OrderFee from "../../db/model/order-fee";
import OrderFeeApprove from "../../db/model/order-fee-approve";
import moment from "moment";

class OrderFeeController {
    constructor() { }

    // Delete a fee of order
    deleteOrderFee(request, reply) {
        const feeId = request.query;

        OrderFee.where(feeId).destroy().then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error.message));
            return;
        });
    }

    addOrderFee(request, reply) {
        const fee = request.payload;
        const newFee = new OrderFee();
        // add a fee to db
        newFee.save({
            OrderID: fee.OrderID,
            FeeDescripID: fee.FeeDescripID,
            BrokerFee: fee.BrokerFee,
            SignerFee: fee.SignerFee,
            Date: moment().format("YYYY-MM-DD HH:mm:ss")
        }, { method: "insert" }).then(() => {
            reply(1);
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    // get fees of an order
    getOrderFee(request, reply) {
        const { orderId } = request.query;
        Bookshelf.knex.raw(`call GetOrderFees('${orderId}')`)
            .then((result) => {
                if (result !== null) {
                    reply(result[0][0]);
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    // Get all data for Order Detail Fee screen
    getOrdersFeeData(request, reply) {
        const { orderId } = request.query;

        const getOrderFees = Promise.resolve(Bookshelf.knex.raw(`call GetOrderFees(${orderId})`));
        const getAllFees = Promise.resolve(Bookshelf.knex.raw(`call GetAllFee()`));
        const getRequestedFees = Promise.resolve(
            Bookshelf.knex.raw(`call GetOrderRequestedFee(${orderId})`));
        const getFeeRequestReason = Promise.resolve(Bookshelf.knex.raw(`call GetAllReasonCodes()`));

        Promise.all([getOrderFees, getAllFees, getRequestedFees, getFeeRequestReason])
            .then(values => {
                const data = {};

                if (values !== null) {
                    values.forEach((item, index) => {
                        if (item !== null) {
                            switch (index) {
                                case 0:
                                    data.orderFeesData = {
                                        orderFees: item[0][0]
                                    };
                                    break;
                                case 1:
                                    data.feesData = {
                                        fees: item[0][0]
                                    };
                                    break;
                                case 2:
                                    data.requestedFeesData = {
                                        fees: item[0][0]
                                    };
                                    break;
                                case 3:
                                    data.feeRequestReasonData = {
                                        reasonList: item[0][0]
                                    };
                                    break;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(error => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    addOrderRequestedFee(request, reply) {
        const fee = request.payload;
        const newRequestFee = new OrderFeeApprove();
        // add a fee to db
        newRequestFee.save({
            OrderId: fee.orderId,
            FeeDescripId: fee.feeDescripId,
            UsersId: fee.userId,
            ReasonCode: fee.reasonCode,
            FeeReason: fee.reasonDescription,
            FeeAmount: fee.feeAmount,
            OriginalAmount: fee.originalAmount,
            FeeApproved: fee.status,
            DateStamp: moment().format("YYYY-MM-DD HH:mm:ss")
        }, { method: "insert" }).then(() => {
            reply({
                isSuccess: true
            });

            return;
        }).catch(error => {
            reply(Boom.badRequest(error));
            return;
        });
    }

    getOrderRequestedFee(request, reply) {
        const { orderId } = request.query;
        Bookshelf.knex.raw(`call GetOrderRequestedFee('${orderId}')`)
            .then((result) => {
                if (result !== null) {
                    reply(result[0][0]);
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    updateOrderRequestedFee(request, reply) {
        const fee = request.payload;

        const updatedFee = {
            UsersId: fee.userId,
            ReasonCode: fee.reasonCode,
            FeeReason: fee.reasonDescription,
            FeeAmount: fee.feeAmount,
            OriginalAmount: fee.originalAmount,
            FeeApproved: fee.status,
            DateStamp: moment().format("YYYY-MM-DD HH:mm:ss")
        };

        OrderFeeApprove.where({ OrderId: fee.orderId, FeeDescripId: fee.feeDescripId })
            .save(updatedFee, { method: "update" }).then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    processRequestFee(request, reply) {
        const { orderId, feeApprovalId, feeApproved, offerStatus, signerId, signerFee, feeDescripId, activity, userId, isOveride } = request.payload;

        Bookshelf.knex.raw(`
        call ChangeOrderFeeApproveStatus(${orderId}, ${feeApprovalId}, '${feeApproved}', '${offerStatus}', ${signerId}, ${signerFee}, ${feeDescripId}, '${activity}', ${userId}, ${isOveride || false});`)
        .then((result) => {
            if (result !== null) {
                reply(result[0][0][0]);
                return;
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
            return;
        });
    }

}

export default new OrderFeeController();
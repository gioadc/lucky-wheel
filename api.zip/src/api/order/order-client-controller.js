import Boom from "boom";
import Bookshelf from "./../../db/database";
import Order from "./../../db/model/order";

class OrderClientController {
    getOrderClientBranchDropdownDataByClientId(request, reply) {
        const { clientId } = request.query;

        Bookshelf.knex.raw(`select b.BrokerID as BranchID, b.Company as BranchName, b.City, b.State from broker b where b.GID = ${clientId};`)
            .then(value => {
                const data = {};
                if (value !== null) {
                    data.branches = value[0];
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getOrderClientAgentData(request, reply) {
        const {
            clientId,
            branchId,
            sortColumn,
            sortDirection,
            page,
            itemPerPage,
            searchString
        } = request.query;

        Bookshelf.knex.raw(`call getOrderClientAgentById(${clientId},${branchId === undefined ? 0 : branchId},'${searchString}','${sortColumn}',${sortDirection},${page},${itemPerPage});`)
            .then(value => {
                const data = {};

                if (value !== null) {
                    data.agents = value[0][0];
                    data.totalRecords = value[0][1][0].TotalRecords;
                }
                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getOrderClientById(request, reply) {
        const {
            orderId
        } = request.query;
        const rawSql = `select o.AgentId, o.OrderId, o.BrokerId, a.BranchID, a.FullName, a.Direct, a.Ext, a.Fax, a.Email, b.AdditionalContact,  b.AdditionalContactEmail, b.AdditionalContactExt, b.AdditionalContactPhone  from \`order\` o left join agent a on o.AgentId = a.AgentId 
                       left join broker b on b.BrokerID = o.BrokerId where o.OrderId = ${orderId};`;

        Bookshelf.knex.raw(rawSql)
            .then(value => {
                if (value !== null) reply({ defaultOrderClient: value[0][0] });
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    updateOrderDetailClient(request, reply) {
        const orderDetailClient = request.payload;

        const newData = {
            BrokerId: orderDetailClient.BrokerId,
            AgentId: orderDetailClient.AgentId
        };

        Order.where({ OrderId: orderDetailClient.OrderId })
            .save(newData, { method: "update" })
            .then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                }
            }).catch((error) => {
                reply(error);
            });

        return reply;
    }
}

export default new OrderClientController();
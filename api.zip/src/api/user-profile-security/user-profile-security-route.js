import UserProfileSecurityController from "./user-profile-security-controller";

const routes = [{
    path: "/user-profile-security/getUserProfile",
    method: "GET",
    config: { auth: false },
    handler: UserProfileSecurityController.getUserProfileSecurity
},
{
    path: "/user-profile-security/updateUserProfileSecurity",
    method: "POST",
    config: { auth: false },
    handler: UserProfileSecurityController.saveUserProfileSecurity
}
];

export default routes;
import CustomerController from "./customer-controller";

const routes = [
    {
        path: "/customer/getCustomers",
        method: "GET",
        config: { auth: false },
        handler: CustomerController.getCustomers
    },
    {
        path: "/customer/getCustomerById",
        method: "GET",
        config: { auth: false },
        handler: CustomerController.getCustomerById
    },
    {
        path: "/customer/deleteCustomer",
        method: "GET",
        config: { auth: false },
        handler: CustomerController.deleteCustomer
    },
    {
        path: "/customer/addCustomer",
        method: "POST",
        config: { auth: false },
        handler: CustomerController.addCustomer
    },
    {
        path: "/customer/updateCustomer",
        method: "POST",
        config: { auth: false },
        handler: CustomerController.updateCustomer
    },
    {
        path: "/customer/getAvailableSigner",
        method: "GET",
        config: { auth: false },
        handler: CustomerController.getAvailableSigner
    },
    {
        path: "/customer/getBlackListSigner",
        method: "GET",
        config: { auth: false },
        handler: CustomerController.getBlackListSigner
    },
    {
        path: "/customer/updateBlackListSigner",
        method: "POST",
        config: { auth: false },
        handler: CustomerController.updateBlackListSigner
    },
    {
        path: "/customer/updateWhiteListSigner",
        method: "POST",
        config: { auth: false },
        handler: CustomerController.updateWhiteListSigner
    },
    {
        path: "/customer/checkExistOrderAssociated",
        method: "GET",
        config: { auth: false },
        handler: CustomerController.checkExistOrderAssociated
    }
];

export default routes;
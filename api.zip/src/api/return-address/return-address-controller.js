import Boom from "boom";
import ReturnAddress from "../../db/model/return-addr";

class ReturnAddressController {
    constructor() { }

    addReturnAddress(request, reply) {
        const returnAddr = request.payload;

        new ReturnAddress().save(returnAddr,
            { method: "insert" }).then((result) => {
                if (result !== null) {
                    reply({ isSuccess: true });
                    return;
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
                return;
            });
    }

    deleteReturnAddress(request, reply) {
		const { raId } = request.query;

		ReturnAddress.where({ RaId: raId }).destroy().then((result) => {
			if (result !== null) {
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return reply;
    }

    // update default return address
    updateReturnAddress(request, reply) {
        const params = request.payload;

        const noneDefaultReturnAddress = {
            DefaultAddr: "N"
        };

        const defaultReturnAddress = {
            DefaultAddr: "Y"
        };

		ReturnAddress.where({ BrokerId: params.brokerId }).save(noneDefaultReturnAddress, { method: "update" }).then((upResult) => {
            if (upResult !== null) {
                ReturnAddress.where({ RaId: params.raId }).save(defaultReturnAddress, { method: "update" }).then((downResult) => {
                    if (downResult !== null) {
                        reply({ isSuccess: true });
                    }
                }).catch((error) => {
                    reply(Boom.badRequest(error));
                });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
	}
}

export default new ReturnAddressController();
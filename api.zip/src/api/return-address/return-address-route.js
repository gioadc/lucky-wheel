import ReturnAddressController from "./return-address-controller";

const routes = [{
    path: "/return-address/addReturnAddress",
    method: "POST",
    config: { auth: false },
    handler: ReturnAddressController.addReturnAddress
},
{
    path: "/return-address/deleteReturnAddress",
    method: "GET",
    config: { auth: false },
    handler: ReturnAddressController.deleteReturnAddress
},
{
    path: "/return-address/updateReturnAddress",
    method: "POST",
    config: { auth: false },
    handler: ReturnAddressController.updateReturnAddress
}];

export default routes;
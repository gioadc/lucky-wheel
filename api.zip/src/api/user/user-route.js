import UserController from "./user-controller";

const routes = [{
    path: "/user/checkExistUser",
    method: "GET",
    config: { auth: false },
    handler: UserController.checkExistUser
}, {
    path: "/user/resetPassword",
    method: "GET",
    config: { auth: false },
    handler: UserController.resetPassword
}, {
    path: "/user/resetPasswordByUserId",
    method: "GET",
    config: { auth: false },
    handler: UserController.resetPasswordByUserId
},
{
    path: "/user/getStaffInfo",
    method: "GET",
    config: {
        auth: false
    },
    handler: UserController.getStaffInfo
},
{
    path: "/user/saveStaffProfile",
    method: "POST",
    config: {
        auth: false,
        payload: {
            maxBytes: 5242880
        }
    },
    handler: UserController.saveStaffProfile
}, {
    path: "/user/generateDefaultLogin",
    method: "GET",
    config: { auth: false },
    handler: UserController.generateDefaultLogin
}, {
    path: "/user/addVendor",
    method: "POST",
    config: { auth: false },
    handler: UserController.addVendor
}, {
    path: "/user/addBranch",
    method: "POST",
    config: { auth: false },
    handler: UserController.addBranch
}, {
    path: "/user/getBillingInformationDefault",
    method: "GET",
    config: { auth: false },
    handler: UserController.getBillingInformationDefault
},
{
    path: "/user/updateBillingInformation",
    method: "POST",
    config: {
        auth: false,
        payload: {
            maxBytes: 5242880
        }
    },
    handler: UserController.updateBillingInformation
},
{
    path: "/user/getAdditionalInformationDefault",
    method: "GET",
    config: { auth: false },
    handler: UserController.getAdditionalInformationDefault
},
{
    path: "/user/updateAdditionalInformation",
    method: "POST",
    config: { auth: false },
    handler: UserController.updateAdditionalInformation
}];

export default routes;
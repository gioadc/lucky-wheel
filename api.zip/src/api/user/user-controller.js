import User from "../../db/model/users";
import Employees from "../../db/model/employees";
import ReturnAddress from "../../db/model/return-addr";
import Broker from "../../db/model/brokers";
import Signer from "../../db/model/signers";
import SecAnswers from "../../db/model/sec-answers";
import moment from "moment";
import Bookshelf from "../../db/database";
import { authConstant } from "../../server/constant";

import Boom from "boom";
import Jwt from "../../lib/jwt";
import RolePermission from "../../db/model/role-permission";
import UserRoles from "../../db/model/user-roles";
import Fee from "../../db/model/fees";
import { hasStringValue, hasValue, bookshelfError, bufferToBoolean, convertRowDataPackage } from "../../helper/common-helper";

import ClientDetail from "../../db/model/client-detail";
import BrokerDetail from "./../../db/model/broker-detail";
import Customer from "./../../db/model/customer";
import CustomerTrainingReq from "./../../db/model/customer-training-req";

class UserController {
	constructor() { }

	saveStaffProfile(request, reply) {
		const { profile, userId, accountId } = request.payload;

		if (!hasValue(profile) || !hasStringValue(userId) || !hasStringValue(accountId)) {
			reply(Boom.badRequest("Missing required values"));
			return;
		}

		const employee = {
			FirstName: profile.firstName,
			LastName: profile.lastName,
			Ext: profile.ext,
			ProfilePicture: Buffer.from(profile.img, "utf8")
		};

		const updateEmployee = (employee) => {
			Employees.where({ RepId: userId }).save(employee, { method: "update" }).then(() => {
				// finish, return to client
				reply({
					isSuccess: true
				});
				return;
			}).catch(error => reply(Boom.badRequest(error)));
		};

		if (hasStringValue(profile.newPassword) || hasStringValue(profile.currentPassword) || hasStringValue(profile.confirmPassword)) {
			// check current password first
			User.where({ UsersId: accountId }).fetch({ columns: ["HashSalt", "Password"] })
				.then((user) => {
					if (user === null) {
						reply(Boom.badRequest(`Can not find this user`));
						return;
					}

					const { HashSalt, Password } = user.attributes;

					if (Jwt.checkPassword(Password, HashSalt, profile.currentPassword)) {
						// current password is correct
						// then, update new password
						User.where({ UsersId: accountId }).save({
							Password: Jwt.hash(profile.newPassword, HashSalt)
						}, { method: "update" }).then((rs) => {
							// done update password => update employee
							updateEmployee(employee);
							return;
						});
					} else {
						reply(Boom.badRequest("Password is not matched."));
						return;
					}
				}).catch(error => reply(Boom.badRequest(error)));
		} else {
			// update only employee
			updateEmployee(employee);
		}
	}

	getStaffInfo(request, reply) {
		const { accountId, userId, userType } = request.query;

		User.where({
			UsersId: accountId
		}).fetch({ columns: ["UsersId", "UserName"] })
			.then((account) => {
				if (account === null) {
					reply(Boom.badRequest(authConstant.userNotFound));
					return;
				}

				const { UserName } = account.attributes;

				// get user information
				Employees.where({
					RepId: userId
				})
					.fetch({ columns: ["Email", "FirstName", "LastName", "Ext", "ProfilePicture"] })
					.then((profile) => {
						if (profile === null) {
							reply(Boom.badRequest(authConstant.userNotFound));
							return;
						}

						const { FirstName, LastName, Email, Ext, ProfilePicture } = profile.attributes;

						reply({
							firstName: FirstName,
							lastName: LastName,
							email: Email,
							ext: Ext,
							username: UserName,
							img: hasValue(ProfilePicture) ? ProfilePicture.toString() : ""
						});
						return;
					})
					.catch((error) => {
						reply(error);
						return;
					});
			});
	}

	checkExistUser(request, reply) {
		const { username } = request.query;
		User.where({ username }).count("*").then((count) => {
			const isExist = count > 0;
			reply({ isExist });
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return;
	}

	resetPassword(request, reply) {
		const { mappingUserId, roleName, type } = request.query;
		RolePermission.where({ roleName, type }).fetch().then((roleResult) => {
			if (roleResult && roleResult.attributes) {
				const roleId = roleResult.attributes.RoleId;
				const sql = `select u.usersId,hashSalt from users u join user_roles ur on u.usersid = ur.usersid
				where u.mappinguserid = ${mappingUserId} and ur.roleId= ${roleId} LIMIT 1`;
				Bookshelf.knex.raw(sql).then(result => {
					const usersId = result[0][0].usersId;
					const hashSalt = result[0][0].hashSalt;
					const hashedPassword = Jwt.hash("SIGNING", hashSalt);
					User.where({ usersId }).save({ Password: hashedPassword, LastUpdate: moment().format("YYYY-MM-DD HH:mm:ss") }, { method: "update" }).then(() => {
						reply({ isSuccess: true });
					}).catch((error) => {
						reply(Boom.badRequest(error));
					});
				}).catch((error) => {
					reply(Boom.badRequest(error));
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	resetPasswordByUserId(request, reply) {
		const {param} = request.query;
		const sql = `select users.UsersId, users.HashSalt from users where \`users\`.UsersId = ${param};`;

		Bookshelf.knex.raw(sql).then(result => {
			const UsersId = result[0][0].UsersId;
			const HashSalt = result[0][0].HashSalt;
			const hashedPassword = Jwt.hash("SIGNING", HashSalt);
			User.where({ UsersId }).save({ Password: hashedPassword, LastUpdate: moment().format("YYYY-MM-DD HH:mm:ss") }, { method: "update" }).then(() => {
				reply({ isSuccess: true });
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	generateDefaultLogin(request, reply) {
		const { userName, mappingUserId, roleName, type } = request.query;
		RolePermission.where({ roleName, type }).fetch().then((roleResult) => {
			if (roleResult && roleResult.attributes) {
				const roleId = roleResult.attributes.RoleId;
				const salt = Jwt.generateSalt();
				const hashedPassword = Jwt.hash("SIGNING", salt);
				new User().save({
					UserName: userName,
					Password: hashedPassword,
					MappingUserId: mappingUserId,
					HashSalt: salt,
					DateCreated: moment().format("YYYY-MM-DD HH:mm:ss"),
					TenantId: 1,
					isActive: 1
				}, { method: "insert" }).then((data) => {
					new UserRoles().save({ UsersId: data.attributes.id, RoleId: roleId }, { method: "insert" }).then((result) => {
						reply({ username: data.attributes.UserName, isSuccess: true });
					}).catch((error) => {
						reply(Boom.badRequest(error));
					});
				}).catch((error) => {
					reply(Boom.badRequest(error));
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	// add new vendor
	addVendor(request, reply) {
		const vendor = request.payload;
		const identify = {};
		const salt = Jwt.generateSalt();
		const hashedPassword = Jwt.hash(vendor.password, salt);

		// add signer
		new Signer().save({
			TenantId: 1, // default
			FirstName: vendor.firstName,
			LastName: vendor.lastName,
			Company: vendor.companyName,
			CompanyType: vendor.companyType,
			Email: vendor.email,
			TaxID: vendor.ssnTaxId,
			EmailOpt: vendor.emailOpt
		},
			{ method: "insert" }).then((result) => {
				if (result !== null) {
					identify.signerId = result.id; // save signerId
					// add user
					new User().save({
						TenantId: 1, // default
						UserName: vendor.userName,
						Password: hashedPassword,
						HashSalt: salt,
						MappingUserId: identify.signerId,
						DateCreated: moment().format("YYYY-MM-DD HH:mm:ss")
					},
						{ method: "insert" }).then((result) => {
							if (result !== null) {
								identify.userId = result.id; // save userId
								// add answer
								new SecAnswers().save({
									UserId: identify.userId,
									ChalId1: vendor.chalId1,
									Answer1: vendor.answer1,
									ChalId2: vendor.chalId2,
									Answer2: vendor.answer2,
									ChalId3: vendor.chalId3,
									Answer3: vendor.answer3
								},
									{ method: "insert" }).then((result) => {
										if (result !== null) {
											reply({
												signerId: identify.signerId,
												userId: identify.userId,
												answerId: result.id,
												isSuccess: true
											});
											return;
										}
									}).catch((error) => {
										reply(Boom.badRequest(error));
										return;
									});
								return;
							}
						}).catch((error) => {
							reply(Boom.badRequest(error));
							return;
						});
					return;
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
				return;
			});
	}

	// add new branch
	addBranch(request, reply) {
		const branch = request.payload;
		const identify = {};
		const salt = Jwt.generateSalt();
		const hashedPassword = Jwt.hash(branch.password, salt);

		new Broker().save({
			TenantId: 1, // default unknow
			GID: branch.GID,
			Company: branch.company,
			Phone: branch.phone,
			Address: branch.address,
			Suite: branch.suite,
			City: branch.city,
			State: branch.state,
			Zip: branch.zip,
			AdministratorFirst: branch.adminFirst,
			AdministratorLast: branch.adminLast,
			AdministratorExt: branch.adminExt,
			AdministratorEmail: branch.adminEmail,
			PrimaryContactFirst: branch.contactFirst,
			PrimaryContactLast: branch.contactLast,
			Email: branch.contactEmail,
			PrimaryContactExt: branch.contactExt,
			PrimaryContactFax: branch.contactFax,
			DefaultCourierID: branch.courierId,
			DefaultCourierAcnt: branch.courierAccount,
			IsAvailable: 1
		},
			{ method: "insert" }).then((brokerResult) => {
				if (brokerResult !== null) {
					identify.brokerId = brokerResult.id;
					new User().save({
						TenantId: 1, // default
						UserName: branch.userName,
						Password: hashedPassword,
						HashSalt: salt,
						MappingUserId: identify.brokerId,
						DateCreated: moment().format("YYYY-MM-DD HH:mm:ss")
					},
						{ method: "insert" }).then((userResult) => {
							// add list return address
							const listReturnAddr = branch.listReturnAddr.map((item) => {
								item.BrokerId = identify.brokerId;
								return item;
							});
							const ReturnAddressObj = Bookshelf.Collection.extend({
								model: ReturnAddress
							});
							const returnAddress = ReturnAddressObj.forge(listReturnAddr);

							returnAddress.invokeThen("save").then(() => {
								reply({
									brokerId: identify.brokerId,
									userId: userResult.id,
									isSuccess: true
								});
							}).catch(error => {
								reply(Boom.badRequest(error));
							});
						}).catch((error) => {
							reply(Boom.badRequest(error));
							return;
						});
					return;
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
				return;
			});
	}

	getBillingInformationDefault(request, reply) {
		const { accountId, userId, roleType } = request.query;

		if (!hasStringValue(accountId) || !hasStringValue(userId) || !hasStringValue(roleType)) {
			reply(Boom.badRequest(`Missing required values`));
			return;
		}

		const getClientBillingInformation = () => {
			const sql = `CALL GetClientBillingInformation(${userId});`;

			Bookshelf.knex.raw(sql)
				.then((result) => {
					const brokerDetails = result[0][0];
					const couriers = result[0][1];

					if (brokerDetails.length === 0) {
						reply(Boom.badRequest(`Broker ${userId} does not exist`));
						return;
					}

					reply({
						user: brokerDetails[0],
						couriers
					});
				}).catch(err => {
					reply(Boom.badRequest(bookshelfError(err)));
					return;
				});
		};

		switch (roleType) {
			case "Client":
				getClientBillingInformation(reply, accountId, userId);
				break;
			default:
				reply(Boom.badRequest(`Role type ${roleType} is not implemented.`));
				break;
		}
	}

	updateBillingInformation(request, reply) {
		const {
			firstName, lastName, contactPhone,
			contactFax, contactEmail, paymentTerm,
			accountPayableRepresentative, accountPayablePhoneNumber, faxNumber,
			emailAddress, courierMethod, account,
			extension, inv, paymentId
		} = request.payload;

		const {
			brokerId
		} = request.query;

		const brokerDetail = {
			APRep: accountPayableRepresentative,
			APRepPhone: accountPayablePhoneNumber,
			APExt: extension,
			APFax: faxNumber,
			APEmail: emailAddress,
			APFirst: firstName,
			APLast: lastName,
			APContactPhone: contactPhone,
			APContactFax: contactFax,
			APContactEmail: contactEmail,
			APTerms: paymentTerm,
			Inv: inv,
			PaymentMethodId: paymentId
		};

		const broker = {
			DefaultCourierID: courierMethod,
			DefaultCourierAcnt: account
		};

		const updateBrokerMore = Promise.resolve(ClientDetail.where({ BrokerId: brokerId }).save(brokerDetail, { method: "update" }));
		const updateBroker = Promise.resolve(Broker.where({ BrokerID: brokerId }).save(broker, { method: "update" }));

		Promise.all([updateBroker, updateBrokerMore])
			.then(() => {
				reply({
					isSuccess: true
				});
				return;
			})
			.catch((err) => {
				reply(Boom.badRequest(bookshelfError(err)));
				return;
			});
	}

	getAdditionalInformationDefault(request, reply) {
		const { accountId, userId, roleType } = request.query;

		if (!hasStringValue(accountId) || !hasStringValue(userId) || !hasStringValue(roleType)) {
			reply(Boom.badRequest(`Missing required values`));
			return;
		}

		const getClientAdditionalInformation = () => {
			const sql = `call GetClientAdditionalInformation(${userId});`;

			Bookshelf.knex.raw(sql)
				.then((result) => {
					const brokerDetails = result[0][0];
					const couriers = result[0][1];
					const training = result[0][2];
					const vendorExp = result[0][3][0];
					const trainingData = result[0][4];

					vendorExp.ReqRateExellent = bufferToBoolean(vendorExp.ReqRateExellent);
					vendorExp.ReqRateGood = bufferToBoolean(vendorExp.ReqRateGood);
					vendorExp.ReqRateNew = bufferToBoolean(vendorExp.ReqRateNew);
					vendorExp.ReqRateVeryGood = bufferToBoolean(vendorExp.ReqRateVeryGood);

					if (brokerDetails.length === 0) {
						reply(Boom.badRequest(`Broker ${userId} does not exist`));
						return;
					}

					const returnData = brokerDetails[0];
					returnData.SigningServiceUse = bufferToBoolean(brokerDetails[0].SigningServiceUse);
					returnData.OvernightDelivery = bufferToBoolean(brokerDetails[0].OvernightDelivery);
					returnData.SecureEmailDelivery = bufferToBoolean(brokerDetails[0].SecureEmailDelivery);
					returnData.DocLocationDelivery = bufferToBoolean(brokerDetails[0].DocLocationDelivery);
					returnData.UploadDocDelivery = bufferToBoolean(brokerDetails[0].UploadDocDelivery);
					returnData.SetApptTime = brokerDetails[0].SetApptTime ? Number(brokerDetails[0].SetApptTime) : null;

					reply({
						additionalInfoDefault: returnData,
						couriers,
						training,
						vendorExp,
						trainingData
					});
				}).catch(err => {
					reply(Boom.badRequest(`${err.code}: ${err.sqlMessage}`));
					return;
				});
		};

		switch (roleType) {
			case "Client":
				getClientAdditionalInformation(reply, accountId, userId);
		}
	}

	getUserBranchById(request, reply) {
		const { brokerId } = request.query;
		User.where({ MappingUserId: brokerId }).fetch({
			columns: [
				"UserName"
			]
		}).then((result) => {
			reply(result);
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	updateAdditionalInformation(request, reply) {
		const { data, brokerId } = request.payload;
		const brokerDetailData = data;
		const otherTableData = {
			vendorRequired: brokerDetailData.vendorRequired,
			courierData: brokerDetailData.DefaultCourier
		};

		delete brokerDetailData.DefaultCourier;
		delete brokerDetailData.vendorRequired;

		const customerSaveData = {
			ReqExperienceNumber: otherTableData.vendorRequired.experience || 0,
			ReqRateNew: otherTableData.vendorRequired.performance.New || false,
			ReqRateGood: otherTableData.vendorRequired.performance.Good || false,
			ReqRateVeryGood: otherTableData.vendorRequired.performance.VeryGood || false,
			ReqRateExellent: otherTableData.vendorRequired.performance.Exellent || false
		};

		const listTrainingId = [];
		if (otherTableData.vendorRequired.training) {
			otherTableData.vendorRequired.training.map(item => {
				listTrainingId.push({ CustomerId: brokerId, ProgramId: item.value });
			});
		}


		const updateTableBrokerDetail = Promise.resolve(BrokerDetail.where({ BrokerId: brokerId }).save(brokerDetailData, { method: "update" }));
		const updateTableBroker = Promise.resolve(Broker.where({ BrokerID: brokerId }).save({ DefaultCourierID: otherTableData.courierData }, { method: "update" }));

		Promise.all([updateTableBroker, updateTableBrokerDetail])
			.then(() => {
				if (brokerDetailData.isMultiCustomer === false) {
					const updateTableCustomer = Promise.resolve(Customer.where({ BrokerId: brokerId }).save(customerSaveData, { method: "update" }));
					const removeTrainingReqNoExistInNewList = Promise.resolve(CustomerTrainingReq.where({ CustomerId: brokerId }).destroy());
					Promise.all([updateTableCustomer, removeTrainingReqNoExistInNewList])
						.then(() => {

							const CustomerTrainingReqs = Bookshelf.Collection.extend({
								model: CustomerTrainingReq
							});

							const customerTrainingReqs = CustomerTrainingReqs.forge(listTrainingId);

							customerTrainingReqs.invokeThen("save").then(() => {
								reply({
									isSuccess: true
								});
							}).catch(err => {
								reply(Boom.badRequest(`${err.code}: ${err.sqlMessage}`));
							});

						}).catch(err => {
							reply(Boom.badRequest(`${err.code}: ${err.sqlMessage}`));
						});
				} else {
					reply({
						isSuccess: true
					});
				}
			}).catch(err => {
				reply(Boom.badRequest(`${err.code}: ${err.sqlMessage}`));
			});
	}
}

export default new UserController();
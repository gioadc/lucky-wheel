import Bookshelf from "../../db/database";
import Boom from "boom";
import ClientDetail from "../../db/model/client-detail";
import ClientDonotuse from "../../db/model/client-donotuse";
import { handleSingleQuote, bufferToBoolean } from "../../helper/common-helper";
class ClientDetailController {
	constructor() { }
	//specifics
	getClientSpecifics(request, reply) {
		const { brokerId } = request.query;
		const { tenantId } = request.query;

		ClientDetail.where({ brokerId }).fetch().then((result) => {
			if (result !== null) {
				if (result.attributes.DateCompleted) {
					result.attributes.DateCompleted = (new Date((new Date((new Date(result.attributes.DateCompleted)).toISOString())).getTime() - ((new Date(result.attributes.DateCompleted)).getTimezoneOffset() * 60000))).toISOString().slice(0, 19).replace("T", " ");
				}
				if (result.attributes.DateSensitive) {
					result.attributes.DateSensitive = JSON.parse(JSON.stringify(result.attributes.DateSensitive)).data[0];
				}
				if (result.attributes.SigningServiceUse) {
					result.attributes.SigningServiceUse = JSON.parse(JSON.stringify(result.attributes.SigningServiceUse)).data[0];
				}
				reply(result);
			} else {
				const newClientDetail = new ClientDetail({ TenantId: tenantId, BrokerId: brokerId });
				newClientDetail.save(null, { method: "insert" }).then((response) => {
					if (response !== null) {
						reply({ TenantId: tenantId, BrokerId: brokerId });
					}
				}).catch((error) => {
					reply(Boom.badRequest(error));
				});
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});

		return;
	}

	updateClientSpecifics(request, reply) {
		const specific = request.payload;
		const dateTimeNow = (new Date((new Date((new Date(new Date())).toISOString())).getTime() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, 19).replace("T", " ");
		specific.DateCompleted = dateTimeNow;
		specific.DocLocationDelivery = specific.DocLocationDelivery ? bufferToBoolean(specific.DocLocationDelivery) : false;
		specific.OvernightDelivery = specific.OvernightDelivery ? bufferToBoolean(specific.OvernightDelivery) : false;
		specific.SecureEmailDelivery = specific.SecureEmailDelivery ? bufferToBoolean(specific.SecureEmailDelivery) : false;
		specific.UploadDocDelivery = specific.UploadDocDelivery ? bufferToBoolean(specific.UploadDocDelivery) : false;

		ClientDetail.where({ BrokerId: specific.BrokerId }).save(
			specific
			, { method: "update" }).then((result) => {
				if (result !== null) {
					reply({ isSuccess: true });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
	}

	addClientSpecifics(request, reply) {
		const specific = request.payload;
		specific.TenantId = 1;
		new ClientDetail(specific).save(null, { method: "insert" }).then((result) => {
			if (result !== null) {
				reply(specific);
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}

	//recent orders
	getRecentOrders(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			recentDay,
			brokerId
		} = request.query;
		Bookshelf.knex.raw(`call GetRecentOrdersByBrokerId('${sortColumn}',${sortDirection},${page},
			${itemPerPage},${recentDay},${brokerId})`)
			.then((result) => {
				if (result !== null) {
					reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		return reply;
	}

	//do not use
	getAvailableSigner(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			whereText,
			brokerId
		} = request.query;
		Bookshelf.knex.raw(`call GetAvailableSigner('${sortColumn}',${sortDirection},${page},
			${itemPerPage},'${handleSingleQuote(whereText)}',${brokerId})`)
			.then((result) => {
				if (result !== null) {
					reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		return reply;
	}

	getBlackListSigner(request, reply) {
		const {
			sortColumn,
			sortDirection,
			page,
			itemPerPage,
			brokerId
		} = request.query;
		Bookshelf.knex.raw(`call GetBlackListSigner('${sortColumn}',${sortDirection},${page},
			${itemPerPage},'${brokerId}')`)
			.then((result) => {
				if (result !== null) {
					reply({ data: result[0][0], totalRecords: result[0][1][0].TotalRecords });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		return reply;
	}

	updateBlackListSigner(request, reply) {
		const data = request.payload;
		const dateTimeNow = (new Date((new Date((new Date(new Date())).toISOString())).getTime() - ((new Date()).getTimezoneOffset() * 60000))).toISOString().slice(0, 19).replace("T", " ");
		const brokerId = data.brokerId;
		const blackList = data.blackList;
		let count = 0;
		blackList.forEach(element => {
			const newDoNotUse = new ClientDonotuse({ Timestamp: dateTimeNow, Comment: element.Comment, SignerId: element.SignerId, BrokerId: brokerId });
			newDoNotUse.save(null, { method: "insert" }).then((result) => {
				count++;
				if (result !== null && count === blackList.length) {
					reply({ isSuccess: true });
				}
			}).catch((error) => {
				reply(Boom.badRequest(error));
			});
		});
	}

	updateWhiteListSigner(request, reply) {
		const data = request.payload;
		const whiteList = data.whiteList;
		ClientDonotuse.where("Id", "in", whiteList).destroy().then((result) => {
			if (result !== null) {
				reply({ isSuccess: true });
			}
		}).catch((error) => {
			reply(Boom.badRequest(error));
		});
	}
}

export default new ClientDetailController();
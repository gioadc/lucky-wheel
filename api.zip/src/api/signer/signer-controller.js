import Boom from "boom";
import Signers from "../../db/model/signers";
import { isBuffer, bufferToBoolean } from "../../helper/common-helper";
import Bookshelf from "../../db/database";


class SignerController {

    getSignerById(request, reply) {
        const SignerId = request.query;

        Signers.where(SignerId).fetch().then((result) => {
            if (result !== null) {
                const signer = result.attributes;

                Object.keys(signer).forEach((key) => {
                    const value = signer[key];

                    if (isBuffer(value)) {
                        signer[key] = bufferToBoolean(value);
                    }
                    if (key === "ProfilePicture") {
                        signer[key] = value ? value.toString() : "";
                    }
                });
                reply({ isSuccess: true, signer });
            }
            reply({ isSuccess: false, message: "No record found!" });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    //get saved data for vendor registation location page
    getSignerLocationDataById(request, reply) {
        const SignerId = request.query;
        const columns = ["WeekdayStreet", "WeekdaySuite", "WeekdayCity", "WeekdayState", "WeekdayZip",
            "WeekendStreet", "WeekendSuite", "WeekendCity", "WeekendState", "WeekendZip"];

        Signers.where(SignerId).fetch({ columns }).then((result) => {
            if (result !== null) {
                const signer = result.attributes;

                reply({ isSuccess: true, signer });
            }
            reply({ isSuccess: false, message: "No record found!" });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }
    //get saved data for vendor registation phone number page
    getSignerPhoneDataById(request, reply) {
        const SignerId = request.query;
        const columns = ["HomePhone", "Fax", "Mobile", "CarrierID", "WorkPhone",
            "Ext", "CallWork", "TextOpt"];

        Signers.where(SignerId).fetch({ columns }).then((result) => {
            if (result !== null) {
                const signer = result.attributes;
                const callWork = signer.CallWork;
                const textOpt = signer.TextOpt;

                signer.CallWork = bufferToBoolean(callWork);
                signer.TextOpt = bufferToBoolean(textOpt);

                reply({ isSuccess: true, signer });
            }
            reply({ isSuccess: false, message: "No record found!" });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    // add new signer
    addSigner(request, reply) {
        const signer = request.payload;

        new Signers().save({
            TenantId: 1, // default unknow
            FirstName: signer.firstName,
            LastName: signer.lastName,
            Company: signer.companyName,
            CompanyType: signer.companyType,
            Email: signer.email,
            TaxID: signer.ssnTaxId,
            EmailOpt: signer.emailOpt
        },
            { method: "insert" }).then((result) => {
                if (result !== null) {
                    reply({
                        signerId: result.id,
                        isSuccess: true
                    });
                }
            }).catch((error) => {
                reply(Boom.badRequest(error));
            });
    }

    updateSigner(request, reply) {
        const signer = request.payload;

        Signers.where({ SignerId: signer.SignerId }).save(signer, { method: "update" }).then((result) => {
            if (result !== null) {
                reply({ isSuccess: true });
            }
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getInitSignerQuestionaires(request, reply) {
        const SignerId = request.query;
        const getSignerById = Promise.resolve(Signers.where(SignerId).fetch());
        const getAllStates = Promise.resolve(Bookshelf.knex.raw(`call GetAllState`));
        const getAllLanguage = Promise.resolve(Bookshelf.knex.raw(`select LanguageID, Language from language order by Language;`));

            Promise.all([getSignerById, getAllStates, getAllLanguage])
			.then(values => {
                const data = {};

				if (values !== null) {
					values.forEach((item, index) => {
						if (item !== null) {
							switch (index) {
								case 0: {
                                    const signer = item.attributes;
                                    Object.keys(signer).forEach((key) => {
                                        const value = signer[key];
                                        if (isBuffer(value)) {
                                            signer[key] = bufferToBoolean(value);
                                        }
                                    });
                                    data.signer = signer;
                                    break;
                                }
								case 1:
									data.listStates = item;
                                    break;
                                case 2:
                                    data.listLanguage = item;
                            }
                        }
                    });
                }

                reply(data);
            }).catch(err => {
                reply(Boom.badRequest(err));
            });
    }

    getSignerExperienceDataById(request, reply) {
        const SignerId = request.query;
        const columns = [
            "SignerId", "CommissionNum", "NotaryExp",
            "AnivDate", "NotarizedDocs", "NotarizedTime",
            "ExperiencedDocs", "ClientRef1", "PhoneRef1",
            "ClientRef2", "PhoneRef2", "ClientRef3", "PhoneRef3"
        ];

        Signers.where(SignerId).fetch({ columns }).then((result) => {
            if (result !== null) {
                const signer = result.attributes;

                if (isBuffer(signer.NotarizedDocs)) {
                    signer.NotarizedDocs = bufferToBoolean(signer.NotarizedDocs);
                }

                reply({ isSuccess: true, signer });
            }

            reply({ isSuccess: false, message: "No record found!" });
        }).catch((error) => {
            reply(Boom.badRequest(error));
        });
    }

    getSignerServiceDataById(request, reply) {
        const { signerId } = request.query;

        // get all data via stored procedure
        Bookshelf.knex.raw(`CALL GetSignerServiceData(${signerId});`).then(result => {
            if (result !== null) {
                const signer = result[0][0][0];

                if (Array.isArray(result[0][1])) {
                    signer.CoverageArea = result[0][1];
                } else {
                    signer.CoverageArea = [];
                }
                reply({isSuccess: true, signer});
            }
            reply({ isSuccess: false, message: "No record found!" });
        }).catch(error => {
            reply(Boom.badRequest(error));
        });
    }

    saveSignerProfilePicture(request, reply) {
        const { image, signerId } = request.payload;
        const signer = {
            signerId,
            ProfilePicture: Buffer.from(image, "utf8")
        };

        Signers.where({ signerId }).save(signer, { method: "update" }).then(() => {
            // finish, return to client
            reply({
                isSuccess: true
            });
        }).catch(error => reply(Boom.badRequest(error)));
    }

}

export default new SignerController();
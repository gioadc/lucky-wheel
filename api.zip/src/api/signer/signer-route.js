import SignerController from "./signer-controller";
import SignerProfileController from "./signer-profile-controller";
const routes = [
    //get user address official
    {
        path: "/signer/getUserAddress",
        method: "GET",
        config: { auth: false },
        handler: SignerProfileController.getUserAddress
    },
    //get user address that waiting to admin approve
    {
        path: "/signer/getUserAddressPending",
        method: "GET",
        config: { auth: false },
        handler: SignerProfileController.getUserAddressPending
    },
    //set new user address then waiting to admin approve
    {
        path: "/signer/updateUserAddressPending",
        method: "POST",
        config: { auth: false },
        handler: SignerProfileController.updateUserAddressPending
    },
    //get signer by signerId
    {
        path: "/signer/getSignerById",
        method: "GET",
        config: { auth: false },
        handler: SignerController.getSignerById
    },
    {
        path: "/signer/getSignerLocationDataById",
        method: "GET",
        config: { auth: false },
        handler: SignerController.getSignerLocationDataById
    },
    {
        path: "/signer/getSignerPhoneDataById",
        method: "GET",
        config: { auth: false },
        handler: SignerController.getSignerPhoneDataById
    },
    {
        path: "/signer/addSigner",
        method: "POST",
        config: { auth: false },
        handler: SignerController.addSigner
    },
    {
        path: "/signer/updateSigner",
        method: "POST",
        config: { auth: false },
        handler: SignerController.updateSigner
    },
    //get init for tab questionaires
    {
        path: "/signer/getInitSignerQuestionaires",
        method: "GET",
        config: { auth: false },
        handler: SignerController.getInitSignerQuestionaires
    },
    //get User Additional Info
    {
        path: "/signer/getUserAdditionalInfo",
        method: "GET",
        config: { auth: false },
        handler: SignerProfileController.getUserAdditionalInfo
    },
    //set new user additional info
    {
        path: "/signer/updateUserAdditionalInfo",
        method: "POST",
        config: { auth: false },
        handler: SignerProfileController.updateUserAdditionalInfo
    },
    //get Signer data for Service information tab
    {
        path: "/signer/getSignerServiceDataById",
        method: "GET",
        config: { auth: false },
        handler: SignerController.getSignerServiceDataById
    },
    //set new user additional info list
    {
        path: "/signer/getUserAdditionalInfoList",
        method: "GET",
        config: { auth: false },
        handler: SignerProfileController.getUserAdditionalInfoList
    },
    {
        path: "/signer/saveSignerProfilePicture",
        method: "POST",
        config: { auth: false },
        handler: SignerController.saveSignerProfilePicture
    }
];

export default routes;
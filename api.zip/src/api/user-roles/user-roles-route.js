import UserRolesController from "./user-roles-controller";

const routes = [{
    path: "/userRoles/addUserRole",
    method: "POST",
    config: { auth: false },
    handler: UserRolesController.addUserRole
}];

export default routes;